public class RingBufferException extends Exception {

	public RingBufferException(String msg) {
		super(msg);
	}

}
