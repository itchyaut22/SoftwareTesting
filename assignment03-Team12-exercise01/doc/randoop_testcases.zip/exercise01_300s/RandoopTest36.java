package exercise01_300s;

import junit.framework.*;

public class RandoopTest36 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test1");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Spliterator var7 = var1.spliterator();
    java.util.Iterator var8 = var1.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var9 = var1.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);

  }

  public void test2() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test2");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    java.util.Spliterator var9 = var1.spliterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    boolean var14 = var12.isEmpty();
    java.util.Iterator var15 = var12.iterator();
    java.util.Spliterator var16 = var12.spliterator();
    var1.enqueue((java.lang.Object)var16);
    exercise01.RingBuffer.RingBufferIterator var18 = var1.new RingBufferIterator();
    boolean var19 = var18.hasNext();
    boolean var20 = var18.hasNext();
    boolean var21 = var18.hasNext();
    java.lang.Object var22 = var18.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var18.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var22);

  }

  public void test3() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test3");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    java.util.Spliterator var4 = var1.spliterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    int var7 = var6.size();
    java.util.Iterator var8 = var6.iterator();
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var10 = var1.spliterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    java.util.Spliterator var14 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    java.util.Spliterator var17 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var12.new RingBufferIterator();
    boolean var19 = var12.isEmpty();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    java.util.Spliterator var22 = var21.spliterator();
    java.util.Spliterator var23 = var21.spliterator();
    java.util.Spliterator var24 = var21.spliterator();
    java.util.Spliterator var25 = var21.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var21.new RingBufferIterator();
    boolean var27 = var26.hasNext();
    boolean var28 = var26.hasNext();
    var12.enqueue((java.lang.Object)var26);
    java.lang.Object var30 = var12.dequeue();
    var1.enqueue(var30);
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var34 = var33.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var33.new RingBufferIterator();
    int var36 = var33.size();
    exercise01.RingBuffer.RingBufferIterator var37 = var33.new RingBufferIterator();
    java.util.Spliterator var38 = var33.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var33.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var39);
    java.util.Spliterator var41 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test4() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test4");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(2);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    java.util.Iterator var3 = var1.iterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(10);
    int var6 = var5.size();
    boolean var7 = var5.isEmpty();
    java.util.Iterator var8 = var5.iterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var5.new RingBufferIterator();
    java.util.Spliterator var10 = var5.spliterator();
    int var11 = var5.size();
    java.util.Iterator var12 = var5.iterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    int var15 = var1.size();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    int var18 = var17.size();
    java.util.Spliterator var19 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var17.new RingBufferIterator();
    boolean var21 = var17.isEmpty();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(0);
    int var24 = var23.size();
    java.util.Iterator var25 = var23.iterator();
    boolean var26 = var23.isEmpty();
    boolean var27 = var23.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var28 = var23.new RingBufferIterator();
    int var29 = var23.size();
    java.util.Spliterator var30 = var23.spliterator();
    var17.enqueue((java.lang.Object)var23);
    java.util.Spliterator var32 = var23.spliterator();
    java.util.Iterator var33 = var23.iterator();
    java.util.Iterator var34 = var23.iterator();
    var1.enqueue((java.lang.Object)var34);
    boolean var36 = var1.isEmpty();
    java.util.Iterator var37 = var1.iterator();
    boolean var38 = var1.isEmpty();
    java.util.Spliterator var39 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var40 = var1.new RingBufferIterator();
    java.lang.Object var41 = var40.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test5() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test5");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    int var8 = var6.size();
    var1.enqueue((java.lang.Object)var8);
    java.util.Iterator var10 = var1.iterator();
    java.lang.Object var11 = var1.dequeue();
    java.util.Spliterator var12 = var1.spliterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var13 = var1.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0+ "'", var11.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test6() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test6");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    int var8 = var7.size();
    int var9 = var7.size();
    int var10 = var7.size();
    java.util.Iterator var11 = var7.iterator();
    var1.enqueue((java.lang.Object)var7);
    boolean var13 = var1.isEmpty();
    java.util.Spliterator var14 = var1.spliterator();
    java.lang.Object var15 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var16 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);

  }

  public void test7() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test7");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Spliterator var10 = var1.spliterator();
    int var11 = var1.size();
    java.util.Spliterator var12 = var1.spliterator();
    boolean var13 = var1.isEmpty();
    boolean var14 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test8() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test8");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(1);
    boolean var8 = var7.isEmpty();
    var1.enqueue((java.lang.Object)var7);
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    java.util.Spliterator var11 = var1.spliterator();
    java.util.Spliterator var12 = var1.spliterator();
    boolean var13 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test9() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test9");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    boolean var6 = var1.isEmpty();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(10);
    int var9 = var8.size();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var8);
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(0);
    java.util.Iterator var14 = var13.iterator();
    int var15 = var13.size();
    int var16 = var13.size();
    int var17 = var13.size();
    java.util.Spliterator var18 = var13.spliterator();
    java.util.Iterator var19 = var13.iterator();
    var1.enqueue((java.lang.Object)var19);
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(0);
    java.util.Iterator var23 = var22.iterator();
    int var24 = var22.size();
    int var25 = var22.size();
    java.util.Spliterator var26 = var22.spliterator();
    java.util.Iterator var27 = var22.iterator();
    var1.enqueue((java.lang.Object)var22);
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(100);
    java.util.Iterator var31 = var30.iterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var30.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var30.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var33);
    boolean var35 = var33.hasNext();
    boolean var36 = var33.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);

  }

  public void test10() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test10");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    java.util.Spliterator var6 = var1.spliterator();
    int var7 = var1.size();
    int var8 = var1.size();
    java.util.Iterator var9 = var1.iterator();
    int var10 = var1.size();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    java.util.Spliterator var14 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    java.util.Iterator var19 = var18.iterator();
    int var20 = var18.size();
    int var21 = var18.size();
    java.util.Spliterator var22 = var18.spliterator();
    java.util.Spliterator var23 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var18.new RingBufferIterator();
    java.util.Spliterator var25 = var18.spliterator();
    var12.enqueue((java.lang.Object)var25);
    java.util.Iterator var27 = var12.iterator();
    int var28 = var12.size();
    boolean var29 = var12.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var30 = var12.new RingBufferIterator();
    java.util.Spliterator var31 = var12.spliterator();
    java.lang.Object var32 = var12.dequeue();
    var1.enqueue((java.lang.Object)var12);
    java.util.Spliterator var34 = var12.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test11() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test11");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var8 = var1.dequeue();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var11 = var10.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var11);
    int var13 = var1.size();
    java.util.Iterator var14 = var1.iterator();
    java.util.Iterator var15 = var1.iterator();
    java.util.Iterator var16 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test12() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test12");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    java.util.Iterator var6 = var1.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var7 = var1.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test13() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test13");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    int var2 = var1.size();
    int var3 = var1.size();
    int var4 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    int var6 = var1.size();
    java.util.Iterator var7 = var1.iterator();
    java.util.Iterator var8 = var1.iterator();
    int var9 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    java.util.Spliterator var15 = var14.spliterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var14.new RingBufferIterator();
    java.util.Spliterator var17 = var14.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    var12.enqueue((java.lang.Object)var14);
    exercise01.RingBuffer.RingBufferIterator var20 = var14.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var14.new RingBufferIterator();
    boolean var22 = var14.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var23 = var14.new RingBufferIterator();
    java.util.Iterator var24 = var14.iterator();
    int var25 = var14.size();
    boolean var26 = var14.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.enqueue((java.lang.Object)var26);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test14() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test14");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    boolean var4 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    boolean var6 = var5.hasNext();
    boolean var7 = var5.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test15() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test15");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    java.util.Iterator var5 = var4.iterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var4.new RingBufferIterator();
    int var7 = var4.size();
    var1.enqueue((java.lang.Object)var4);
    java.util.Spliterator var9 = var1.spliterator();
    java.util.Spliterator var10 = var1.spliterator();
    boolean var11 = var1.isEmpty();
    boolean var12 = var1.isEmpty();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(10);
    int var15 = var14.size();
    boolean var16 = var14.isEmpty();
    java.util.Iterator var17 = var14.iterator();
    java.util.Spliterator var18 = var14.spliterator();
    java.util.Iterator var19 = var14.iterator();
    boolean var20 = var14.isEmpty();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(0);
    int var23 = var22.size();
    java.util.Iterator var24 = var22.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var22.new RingBufferIterator();
    boolean var26 = var22.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var27 = var22.new RingBufferIterator();
    boolean var28 = var27.hasNext();
    var14.enqueue((java.lang.Object)var28);
    int var30 = var14.size();
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    java.util.Iterator var33 = var32.iterator();
    int var34 = var32.size();
    int var35 = var32.size();
    java.util.Spliterator var36 = var32.spliterator();
    java.util.Iterator var37 = var32.iterator();
    exercise01.RingBuffer.RingBufferIterator var38 = var32.new RingBufferIterator();
    java.util.Spliterator var39 = var32.spliterator();
    java.util.Iterator var40 = var32.iterator();
    var14.enqueue((java.lang.Object)var40);
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(100);
    java.util.Iterator var44 = var43.iterator();
    java.util.Spliterator var45 = var43.spliterator();
    int var46 = var43.size();
    exercise01.RingBuffer var48 = new exercise01.RingBuffer(0);
    java.util.Spliterator var49 = var48.spliterator();
    exercise01.RingBuffer.RingBufferIterator var50 = var48.new RingBufferIterator();
    java.util.Spliterator var51 = var48.spliterator();
    int var52 = var48.size();
    int var53 = var48.size();
    boolean var54 = var48.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var55 = var48.new RingBufferIterator();
    var43.enqueue((java.lang.Object)var55);
    var14.enqueue((java.lang.Object)var55);
    int var58 = var14.size();
    exercise01.RingBuffer.RingBufferIterator var59 = var14.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var59);
    boolean var61 = var1.isEmpty();
    java.util.Spliterator var62 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test16() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test16");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    int var8 = var6.size();
    var1.enqueue((java.lang.Object)var8);
    boolean var10 = var1.isEmpty();
    java.lang.Object var11 = var1.dequeue();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(0);
    java.util.Spliterator var14 = var13.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    java.util.Spliterator var16 = var13.spliterator();
    int var17 = var13.size();
    int var18 = var13.size();
    boolean var19 = var13.isEmpty();
    int var20 = var13.size();
    java.util.Spliterator var21 = var13.spliterator();
    java.util.Iterator var22 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var13.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var23);
    exercise01.RingBuffer.RingBufferIterator var25 = var1.new RingBufferIterator();
    java.util.Spliterator var26 = var1.spliterator();
    java.util.Iterator var27 = var1.iterator();
    int var28 = var1.size();
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(10);
    int var31 = var30.size();
    java.util.Spliterator var32 = var30.spliterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var30.new RingBufferIterator();
    int var34 = var30.size();
    var30.enqueue((java.lang.Object)10);
    java.lang.Object var37 = var30.dequeue();
    java.util.Spliterator var38 = var30.spliterator();
    java.util.Iterator var39 = var30.iterator();
    boolean var40 = var30.isEmpty();
    var1.enqueue((java.lang.Object)var40);
    boolean var42 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0+ "'", var11.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var37 + "' != '" + 10+ "'", var37.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);

  }

  public void test17() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test17");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    java.util.Iterator var5 = var4.iterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var4.new RingBufferIterator();
    int var7 = var4.size();
    var1.enqueue((java.lang.Object)var4);
    java.util.Spliterator var9 = var1.spliterator();
    java.lang.Object var10 = var1.dequeue();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    boolean var14 = var12.isEmpty();
    java.util.Iterator var15 = var12.iterator();
    java.util.Spliterator var16 = var12.spliterator();
    java.util.Iterator var17 = var12.iterator();
    boolean var18 = var12.isEmpty();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(0);
    int var21 = var20.size();
    java.util.Iterator var22 = var20.iterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var20.new RingBufferIterator();
    boolean var24 = var20.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var25 = var20.new RingBufferIterator();
    boolean var26 = var25.hasNext();
    var12.enqueue((java.lang.Object)var26);
    int var28 = var12.size();
    java.util.Spliterator var29 = var12.spliterator();
    int var30 = var12.size();
    int var31 = var12.size();
    var1.enqueue((java.lang.Object)var31);
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(0);
    java.util.Spliterator var35 = var34.spliterator();
    exercise01.RingBuffer.RingBufferIterator var36 = var34.new RingBufferIterator();
    java.util.Spliterator var37 = var34.spliterator();
    int var38 = var34.size();
    int var39 = var34.size();
    boolean var40 = var34.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var41 = var34.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var41);
    boolean var43 = var1.isEmpty();
    int var44 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 2);

  }

  public void test18() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test18");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    int var3 = var1.size();
    int var4 = var1.size();
    int var5 = var1.size();
    java.util.Spliterator var6 = var1.spliterator();
    java.util.Iterator var7 = var1.iterator();
    java.util.Iterator var8 = var1.iterator();
    boolean var9 = var1.isEmpty();
    int var10 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test19() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test19");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    java.util.Spliterator var9 = var1.spliterator();
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(100);
    java.util.Iterator var12 = var11.iterator();
    java.util.Spliterator var13 = var11.spliterator();
    int var14 = var11.size();
    java.util.Iterator var15 = var11.iterator();
    java.util.Spliterator var16 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var11.new RingBufferIterator();
    boolean var18 = var11.isEmpty();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(100);
    java.util.Iterator var21 = var20.iterator();
    java.util.Spliterator var22 = var20.spliterator();
    int var23 = var20.size();
    java.util.Iterator var24 = var20.iterator();
    java.util.Spliterator var25 = var20.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var20.new RingBufferIterator();
    boolean var27 = var20.isEmpty();
    var11.enqueue((java.lang.Object)var27);
    exercise01.RingBuffer.RingBufferIterator var29 = var11.new RingBufferIterator();
    int var30 = var11.size();
    var1.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(0);
    java.util.Iterator var34 = var33.iterator();
    int var35 = var33.size();
    int var36 = var33.size();
    java.util.Spliterator var37 = var33.spliterator();
    exercise01.RingBuffer.RingBufferIterator var38 = var33.new RingBufferIterator();
    int var39 = var33.size();
    java.util.Iterator var40 = var33.iterator();
    java.util.Spliterator var41 = var33.spliterator();
    java.util.Iterator var42 = var33.iterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var33.new RingBufferIterator();
    boolean var44 = var43.hasNext();
    var11.enqueue((java.lang.Object)var43);
    boolean var46 = var11.isEmpty();
    java.util.Spliterator var47 = var11.spliterator();
    java.util.Spliterator var48 = var11.spliterator();
    boolean var49 = var11.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test20() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test20");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    java.util.Iterator var9 = var1.iterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    int var14 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    java.util.Spliterator var17 = var12.spliterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer.RingBufferIterator var19 = var12.new RingBufferIterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(0);
    java.util.Spliterator var24 = var23.spliterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var23.new RingBufferIterator();
    java.util.Spliterator var26 = var23.spliterator();
    var21.enqueue((java.lang.Object)var23);
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(100);
    java.util.Spliterator var30 = var29.spliterator();
    var21.enqueue((java.lang.Object)var30);
    java.util.Spliterator var32 = var21.spliterator();
    var12.enqueue((java.lang.Object)var21);
    java.util.Spliterator var34 = var12.spliterator();
    boolean var35 = var12.isEmpty();
    java.util.Spliterator var36 = var12.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test21() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test21");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    boolean var22 = var9.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var23 = var9.new RingBufferIterator();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(0);
    int var26 = var25.size();
    java.util.Iterator var27 = var25.iterator();
    var9.enqueue((java.lang.Object)var25);
    java.util.Iterator var29 = var9.iterator();
    java.util.Spliterator var30 = var9.spliterator();
    java.lang.Object var31 = var9.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test22() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test22");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    boolean var12 = var1.isEmpty();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(10);
    int var15 = var14.size();
    boolean var16 = var14.isEmpty();
    java.util.Iterator var17 = var14.iterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var14.new RingBufferIterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    int var22 = var21.size();
    java.util.Iterator var23 = var21.iterator();
    boolean var24 = var21.isEmpty();
    boolean var25 = var21.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var26 = var21.new RingBufferIterator();
    var14.enqueue((java.lang.Object)var21);
    exercise01.RingBuffer.RingBufferIterator var28 = var21.new RingBufferIterator();
    java.util.Iterator var29 = var21.iterator();
    boolean var30 = var21.isEmpty();
    boolean var31 = var21.isEmpty();
    var1.enqueue((java.lang.Object)var21);
    java.util.Iterator var33 = var21.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test23() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test23");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    int var8 = var6.size();
    var1.enqueue((java.lang.Object)var8);
    boolean var10 = var1.isEmpty();
    java.lang.Object var11 = var1.dequeue();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(0);
    java.util.Spliterator var14 = var13.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    java.util.Spliterator var16 = var13.spliterator();
    int var17 = var13.size();
    int var18 = var13.size();
    boolean var19 = var13.isEmpty();
    int var20 = var13.size();
    java.util.Spliterator var21 = var13.spliterator();
    java.util.Iterator var22 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var13.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var23);
    exercise01.RingBuffer.RingBufferIterator var25 = var1.new RingBufferIterator();
    java.util.Spliterator var26 = var1.spliterator();
    java.util.Iterator var27 = var1.iterator();
    java.util.Spliterator var28 = var1.spliterator();
    java.lang.Object var29 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0+ "'", var11.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test24() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test24");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    boolean var5 = var1.isEmpty();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    java.util.Iterator var8 = var1.iterator();
    boolean var9 = var1.isEmpty();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    java.util.Spliterator var14 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    boolean var16 = var12.isEmpty();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    int var19 = var18.size();
    java.util.Iterator var20 = var18.iterator();
    boolean var21 = var18.isEmpty();
    boolean var22 = var18.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var23 = var18.new RingBufferIterator();
    int var24 = var18.size();
    java.util.Spliterator var25 = var18.spliterator();
    var12.enqueue((java.lang.Object)var18);
    exercise01.RingBuffer.RingBufferIterator var27 = var12.new RingBufferIterator();
    java.lang.Object var28 = var27.next();
    var1.enqueue((java.lang.Object)var27);
    boolean var30 = var1.isEmpty();
    boolean var31 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test25() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test25");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    int var8 = var7.size();
    java.util.Spliterator var9 = var7.spliterator();
    int var10 = var7.size();
    java.util.Spliterator var11 = var7.spliterator();
    java.util.Iterator var12 = var7.iterator();
    boolean var13 = var7.isEmpty();
    int var14 = var7.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var7.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var7.new RingBufferIterator();
    java.util.Iterator var17 = var7.iterator();
    java.util.Spliterator var18 = var7.spliterator();
    var1.enqueue((java.lang.Object)var7);
    boolean var20 = var1.isEmpty();
    java.util.Iterator var21 = var1.iterator();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(10);
    int var24 = var23.size();
    java.util.Spliterator var25 = var23.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var23.new RingBufferIterator();
    int var27 = var23.size();
    java.util.Spliterator var28 = var23.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var23.new RingBufferIterator();
    boolean var30 = var23.isEmpty();
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    java.util.Spliterator var33 = var32.spliterator();
    java.util.Spliterator var34 = var32.spliterator();
    java.util.Spliterator var35 = var32.spliterator();
    java.util.Spliterator var36 = var32.spliterator();
    exercise01.RingBuffer.RingBufferIterator var37 = var32.new RingBufferIterator();
    boolean var38 = var37.hasNext();
    boolean var39 = var37.hasNext();
    var23.enqueue((java.lang.Object)var37);
    java.lang.Object var41 = var23.dequeue();
    exercise01.RingBuffer.RingBufferIterator var42 = var23.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var23.new RingBufferIterator();
    int var44 = var23.size();
    java.util.Iterator var45 = var23.iterator();
    exercise01.RingBuffer var47 = new exercise01.RingBuffer(100);
    java.util.Spliterator var48 = var47.spliterator();
    boolean var49 = var47.isEmpty();
    int var50 = var47.size();
    java.util.Iterator var51 = var47.iterator();
    java.util.Iterator var52 = var47.iterator();
    exercise01.RingBuffer var54 = new exercise01.RingBuffer(100);
    java.util.Iterator var55 = var54.iterator();
    java.util.Spliterator var56 = var54.spliterator();
    java.util.Spliterator var57 = var54.spliterator();
    exercise01.RingBuffer var59 = new exercise01.RingBuffer(0);
    int var60 = var59.size();
    java.util.Iterator var61 = var59.iterator();
    var54.enqueue((java.lang.Object)var59);
    exercise01.RingBuffer.RingBufferIterator var63 = var59.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var64 = var59.new RingBufferIterator();
    int var65 = var59.size();
    int var66 = var59.size();
    var47.enqueue((java.lang.Object)var59);
    exercise01.RingBuffer.RingBufferIterator var68 = var59.new RingBufferIterator();
    var23.enqueue((java.lang.Object)var68);
    var1.enqueue((java.lang.Object)var68);
    boolean var71 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var72 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var73 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == false);

  }

  public void test26() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test26");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    java.lang.Object var9 = var1.dequeue();
    java.util.Iterator var10 = var1.iterator();
    java.util.Iterator var11 = var1.iterator();
    int var12 = var1.size();
    int var13 = var1.size();
    java.util.Spliterator var14 = var1.spliterator();
    int var15 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (-1.0f)+ "'", var9.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);

  }

  public void test27() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test27");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Spliterator var4 = var1.spliterator();
    java.util.Iterator var5 = var1.iterator();
    java.util.Spliterator var6 = var1.spliterator();
    int var7 = var1.size();
    java.util.Iterator var8 = var1.iterator();
    int var9 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var11 = var10.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test28() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test28");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Iterator var22 = var9.iterator();
    boolean var23 = var9.isEmpty();
    java.util.Iterator var24 = var9.iterator();
    java.util.Iterator var25 = var9.iterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(1);
    java.util.Spliterator var28 = var27.spliterator();
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(0);
    java.util.Iterator var31 = var30.iterator();
    int var32 = var30.size();
    int var33 = var30.size();
    int var34 = var30.size();
    java.util.Spliterator var35 = var30.spliterator();
    var27.enqueue((java.lang.Object)var30);
    int var37 = var27.size();
    exercise01.RingBuffer.RingBufferIterator var38 = var27.new RingBufferIterator();
    java.lang.Object var39 = var27.dequeue();
    int var40 = var27.size();
    java.util.Iterator var41 = var27.iterator();
    var9.enqueue((java.lang.Object)var41);
    boolean var43 = var9.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test29() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test29");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    java.util.Spliterator var6 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    boolean var8 = var1.isEmpty();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    java.util.Spliterator var11 = var10.spliterator();
    java.util.Spliterator var12 = var10.spliterator();
    java.util.Spliterator var13 = var10.spliterator();
    java.util.Spliterator var14 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var10.new RingBufferIterator();
    boolean var16 = var15.hasNext();
    boolean var17 = var15.hasNext();
    var1.enqueue((java.lang.Object)var15);
    java.lang.Object var19 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var20 = var1.new RingBufferIterator();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(2);
    exercise01.RingBuffer.RingBufferIterator var23 = var22.new RingBufferIterator();
    java.util.Iterator var24 = var22.iterator();
    java.util.Iterator var25 = var22.iterator();
    var1.enqueue((java.lang.Object)var25);
    exercise01.RingBuffer.RingBufferIterator var27 = var1.new RingBufferIterator();
    boolean var28 = var1.isEmpty();
    boolean var29 = var1.isEmpty();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(10);
    int var32 = var31.size();
    java.util.Spliterator var33 = var31.spliterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var31.new RingBufferIterator();
    exercise01.RingBuffer var36 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(0);
    java.util.Spliterator var39 = var38.spliterator();
    exercise01.RingBuffer.RingBufferIterator var40 = var38.new RingBufferIterator();
    java.util.Spliterator var41 = var38.spliterator();
    var36.enqueue((java.lang.Object)var38);
    var31.enqueue((java.lang.Object)var36);
    exercise01.RingBuffer.RingBufferIterator var44 = var36.new RingBufferIterator();
    int var45 = var36.size();
    exercise01.RingBuffer.RingBufferIterator var46 = var36.new RingBufferIterator();
    boolean var47 = var36.isEmpty();
    var1.enqueue((java.lang.Object)var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);

  }

  public void test30() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test30");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    boolean var9 = var1.isEmpty();
    boolean var10 = var1.isEmpty();
    int var11 = var1.size();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(10);
    int var16 = var15.size();
    java.util.Spliterator var17 = var15.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var15.new RingBufferIterator();
    boolean var19 = var15.isEmpty();
    java.util.Iterator var20 = var15.iterator();
    boolean var21 = var15.isEmpty();
    java.util.Iterator var22 = var15.iterator();
    boolean var23 = var15.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var24 = var15.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var15);
    java.util.Spliterator var26 = var15.spliterator();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(1);
    java.util.Spliterator var29 = var28.spliterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(0);
    int var32 = var31.size();
    var28.enqueue((java.lang.Object)var32);
    java.lang.Object var34 = var28.dequeue();
    java.util.Spliterator var35 = var28.spliterator();
    exercise01.RingBuffer.RingBufferIterator var36 = var28.new RingBufferIterator();
    java.util.Iterator var37 = var28.iterator();
    boolean var38 = var28.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var39 = var28.new RingBufferIterator();
    java.util.Spliterator var40 = var28.spliterator();
    boolean var41 = var28.isEmpty();
    var15.enqueue((java.lang.Object)var41);
    exercise01.RingBuffer.RingBufferIterator var43 = var15.new RingBufferIterator();
    boolean var44 = var43.hasNext();
    boolean var45 = var43.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + 0+ "'", var34.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);

  }

  public void test31() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test31");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    java.util.Spliterator var5 = var1.spliterator();
    boolean var6 = var1.isEmpty();
    int var7 = var1.size();
    int var8 = var1.size();
    java.util.Spliterator var9 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test32() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test32");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var6.new RingBufferIterator();
    java.util.Spliterator var9 = var6.spliterator();
    int var10 = var6.size();
    int var11 = var6.size();
    boolean var12 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var6.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var13);
    int var15 = var1.size();
    boolean var16 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var17 = var1.new RingBufferIterator();
    int var18 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var19 = var1.new RingBufferIterator();
    java.lang.Object var20 = var19.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var21 = var19.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test33() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test33");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    int var3 = var1.size();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    boolean var9 = var8.hasNext();
    boolean var10 = var8.hasNext();
    boolean var11 = var8.hasNext();
    boolean var12 = var8.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test34() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test34");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var14 = var6.spliterator();
    int var15 = var6.size();
    java.util.Iterator var16 = var6.iterator();
    int var17 = var6.size();
    boolean var18 = var6.isEmpty();
    boolean var19 = var6.isEmpty();
    java.util.Iterator var20 = var6.iterator();
    java.util.Iterator var21 = var6.iterator();
    java.util.Spliterator var22 = var6.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test35() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test35");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    exercise01.RingBuffer.RingBufferIterator var14 = var6.new RingBufferIterator();
    int var15 = var6.size();
    exercise01.RingBuffer.RingBufferIterator var16 = var6.new RingBufferIterator();
    boolean var17 = var6.isEmpty();
    boolean var18 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var19 = var6.new RingBufferIterator();
    boolean var20 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var21 = var6.new RingBufferIterator();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(0);
    java.util.Iterator var24 = var23.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var23.new RingBufferIterator();
    int var26 = var23.size();
    java.util.Iterator var27 = var23.iterator();
    java.util.Iterator var28 = var23.iterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var23.new RingBufferIterator();
    boolean var30 = var23.isEmpty();
    java.util.Iterator var31 = var23.iterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var23.new RingBufferIterator();
    var6.enqueue((java.lang.Object)var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);

  }

  public void test36() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test36");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var14 = var6.spliterator();
    int var15 = var6.size();
    int var16 = var6.size();
    exercise01.RingBuffer.RingBufferIterator var17 = var6.new RingBufferIterator();
    java.util.Spliterator var18 = var6.spliterator();
    int var19 = var6.size();
    boolean var20 = var6.isEmpty();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(100);
    java.util.Iterator var23 = var22.iterator();
    java.util.Spliterator var24 = var22.spliterator();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(0);
    java.util.Spliterator var27 = var26.spliterator();
    int var28 = var26.size();
    java.util.Spliterator var29 = var26.spliterator();
    java.util.Iterator var30 = var26.iterator();
    var22.enqueue((java.lang.Object)var26);
    java.lang.Object var32 = var22.dequeue();
    exercise01.RingBuffer.RingBufferIterator var33 = var22.new RingBufferIterator();
    java.util.Spliterator var34 = var22.spliterator();
    boolean var35 = var22.isEmpty();
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(10);
    int var38 = var37.size();
    boolean var39 = var37.isEmpty();
    java.util.Iterator var40 = var37.iterator();
    exercise01.RingBuffer.RingBufferIterator var41 = var37.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var42 = var37.new RingBufferIterator();
    int var43 = var37.size();
    exercise01.RingBuffer var45 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var47 = new exercise01.RingBuffer(0);
    java.util.Spliterator var48 = var47.spliterator();
    exercise01.RingBuffer.RingBufferIterator var49 = var47.new RingBufferIterator();
    java.util.Spliterator var50 = var47.spliterator();
    var45.enqueue((java.lang.Object)var47);
    exercise01.RingBuffer var53 = new exercise01.RingBuffer(100);
    java.util.Spliterator var54 = var53.spliterator();
    var45.enqueue((java.lang.Object)var54);
    java.util.Iterator var56 = var45.iterator();
    var37.enqueue((java.lang.Object)var45);
    boolean var58 = var45.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var59 = var45.new RingBufferIterator();
    java.util.Iterator var60 = var45.iterator();
    int var61 = var45.size();
    exercise01.RingBuffer.RingBufferIterator var62 = var45.new RingBufferIterator();
    var22.enqueue((java.lang.Object)var62);
    boolean var64 = var62.hasNext();
    boolean var65 = var62.hasNext();
    var6.enqueue((java.lang.Object)var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);

  }

  public void test37() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test37");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    int var3 = var1.size();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    java.util.Spliterator var7 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    int var11 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    int var13 = var1.size();
    java.util.Spliterator var14 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test38() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test38");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    java.util.Spliterator var6 = var1.spliterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer.RingBufferIterator var9 = var8.new RingBufferIterator();
    java.util.Iterator var10 = var8.iterator();
    var1.enqueue((java.lang.Object)var8);
    java.lang.Object var12 = var1.dequeue();
    java.util.Iterator var13 = var1.iterator();
    int var14 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var1.new RingBufferIterator();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(0);
    java.util.Iterator var18 = var17.iterator();
    int var19 = var17.size();
    int var20 = var17.size();
    int var21 = var17.size();
    java.util.Iterator var22 = var17.iterator();
    int var23 = var17.size();
    var1.enqueue((java.lang.Object)var23);
    exercise01.RingBuffer.RingBufferIterator var25 = var1.new RingBufferIterator();
    boolean var26 = var25.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);

  }

  public void test39() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test39");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    int var6 = var1.size();
    int var7 = var1.size();
    java.util.Iterator var8 = var1.iterator();
    java.util.Spliterator var9 = var1.spliterator();
    int var10 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    boolean var13 = var12.hasNext();
    boolean var14 = var12.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var12.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);

  }

  public void test40() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test40");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    int var7 = var1.size();
    java.util.Iterator var8 = var1.iterator();
    java.util.Iterator var9 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    boolean var14 = var12.isEmpty();
    java.util.Iterator var15 = var12.iterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var12.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var12.new RingBufferIterator();
    var12.enqueue((java.lang.Object)(-1.0f));
    java.util.Iterator var20 = var12.iterator();
    java.lang.Object var21 = var12.dequeue();
    exercise01.RingBuffer.RingBufferIterator var22 = var12.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var12);
    java.util.Spliterator var24 = var1.spliterator();
    int var25 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var26 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (-1.0f)+ "'", var21.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);

  }

  public void test41() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test41");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var3.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var9 = var1.dequeue();
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Iterator var14 = var11.iterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var11.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var11.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var16);
    java.util.Spliterator var18 = var1.spliterator();
    int var19 = var1.size();
    int var20 = var1.size();
    int var21 = var1.size();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(10);
    int var24 = var23.size();
    boolean var25 = var23.isEmpty();
    java.util.Iterator var26 = var23.iterator();
    boolean var27 = var23.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var28 = var23.new RingBufferIterator();
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(10);
    int var31 = var30.size();
    boolean var32 = var30.isEmpty();
    java.util.Iterator var33 = var30.iterator();
    java.util.Spliterator var34 = var30.spliterator();
    java.util.Iterator var35 = var30.iterator();
    boolean var36 = var30.isEmpty();
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(0);
    int var39 = var38.size();
    java.util.Iterator var40 = var38.iterator();
    exercise01.RingBuffer.RingBufferIterator var41 = var38.new RingBufferIterator();
    boolean var42 = var38.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var43 = var38.new RingBufferIterator();
    boolean var44 = var43.hasNext();
    var30.enqueue((java.lang.Object)var44);
    int var46 = var30.size();
    java.util.Spliterator var47 = var30.spliterator();
    var23.enqueue((java.lang.Object)var47);
    java.lang.Object var49 = var23.dequeue();
    boolean var50 = var23.isEmpty();
    var1.enqueue((java.lang.Object)var50);
    exercise01.RingBuffer var53 = new exercise01.RingBuffer(0);
    java.util.Iterator var54 = var53.iterator();
    exercise01.RingBuffer.RingBufferIterator var55 = var53.new RingBufferIterator();
    int var56 = var53.size();
    java.util.Iterator var57 = var53.iterator();
    int var58 = var53.size();
    int var59 = var53.size();
    exercise01.RingBuffer.RingBufferIterator var60 = var53.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var61 = var53.new RingBufferIterator();
    boolean var62 = var53.isEmpty();
    java.util.Iterator var63 = var53.iterator();
    var1.enqueue((java.lang.Object)var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test42() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest36.test42");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    int var8 = var6.size();
    var1.enqueue((java.lang.Object)var8);
    boolean var10 = var1.isEmpty();
    java.lang.Object var11 = var1.dequeue();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(0);
    java.util.Spliterator var14 = var13.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    java.util.Spliterator var16 = var13.spliterator();
    int var17 = var13.size();
    int var18 = var13.size();
    boolean var19 = var13.isEmpty();
    int var20 = var13.size();
    java.util.Spliterator var21 = var13.spliterator();
    java.util.Iterator var22 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var13.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var23);
    boolean var25 = var1.isEmpty();
    java.util.Iterator var26 = var1.iterator();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(0);
    int var29 = var28.size();
    int var30 = var28.size();
    int var31 = var28.size();
    java.util.Iterator var32 = var28.iterator();
    java.util.Spliterator var33 = var28.spliterator();
    java.util.Spliterator var34 = var28.spliterator();
    var1.enqueue((java.lang.Object)var28);
    int var36 = var28.size();
    exercise01.RingBuffer.RingBufferIterator var37 = var28.new RingBufferIterator();
    int var38 = var28.size();
    int var39 = var28.size();
    boolean var40 = var28.isEmpty();
    java.util.Spliterator var41 = var28.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0+ "'", var11.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

}
