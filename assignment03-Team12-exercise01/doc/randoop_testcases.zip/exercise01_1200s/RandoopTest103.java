package exercise01_1200s;

import junit.framework.*;

public class RandoopTest103 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test1");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    java.util.Iterator var9 = var1.iterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    int var14 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    java.util.Spliterator var17 = var12.spliterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer.RingBufferIterator var19 = var12.new RingBufferIterator();
    java.util.Spliterator var20 = var12.spliterator();
    boolean var21 = var12.isEmpty();
    java.util.Spliterator var22 = var12.spliterator();
    java.util.Iterator var23 = var12.iterator();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(10);
    int var26 = var25.size();
    java.util.Spliterator var27 = var25.spliterator();
    exercise01.RingBuffer.RingBufferIterator var28 = var25.new RingBufferIterator();
    int var29 = var25.size();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(0);
    int var32 = var31.size();
    java.util.Iterator var33 = var31.iterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var31.new RingBufferIterator();
    boolean var35 = var34.hasNext();
    boolean var36 = var34.hasNext();
    var25.enqueue((java.lang.Object)var36);
    java.lang.Object var38 = var25.dequeue();
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(10);
    int var41 = var40.size();
    boolean var42 = var40.isEmpty();
    java.util.Iterator var43 = var40.iterator();
    exercise01.RingBuffer.RingBufferIterator var44 = var40.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var45 = var40.new RingBufferIterator();
    java.util.Iterator var46 = var40.iterator();
    int var47 = var40.size();
    exercise01.RingBuffer var49 = new exercise01.RingBuffer(0);
    java.util.Spliterator var50 = var49.spliterator();
    exercise01.RingBuffer.RingBufferIterator var51 = var49.new RingBufferIterator();
    java.util.Spliterator var52 = var49.spliterator();
    exercise01.RingBuffer.RingBufferIterator var53 = var49.new RingBufferIterator();
    boolean var54 = var53.hasNext();
    var40.enqueue((java.lang.Object)var53);
    java.util.Spliterator var56 = var40.spliterator();
    var25.enqueue((java.lang.Object)var40);
    boolean var58 = var40.isEmpty();
    java.util.Iterator var59 = var40.iterator();
    int var60 = var40.size();
    var12.enqueue((java.lang.Object)var40);
    java.util.Spliterator var62 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var63 = var12.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + false+ "'", var38.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);

  }

  public void test2() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test2");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Iterator var22 = var9.iterator();
    java.lang.Object var23 = var9.dequeue();
    java.lang.Object var24 = var9.dequeue();
    java.util.Spliterator var25 = var9.spliterator();
    boolean var26 = var9.isEmpty();
    int var27 = var9.size();
    java.util.Iterator var28 = var9.iterator();
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(10);
    int var31 = var30.size();
    java.util.Spliterator var32 = var30.spliterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var30.new RingBufferIterator();
    int var34 = var30.size();
    exercise01.RingBuffer var36 = new exercise01.RingBuffer(0);
    java.util.Iterator var37 = var36.iterator();
    int var38 = var36.size();
    int var39 = var36.size();
    java.util.Spliterator var40 = var36.spliterator();
    java.util.Spliterator var41 = var36.spliterator();
    exercise01.RingBuffer.RingBufferIterator var42 = var36.new RingBufferIterator();
    java.util.Spliterator var43 = var36.spliterator();
    var30.enqueue((java.lang.Object)var43);
    exercise01.RingBuffer.RingBufferIterator var45 = var30.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var46 = var30.new RingBufferIterator();
    java.util.Spliterator var47 = var30.spliterator();
    var9.enqueue((java.lang.Object)var47);
    exercise01.RingBuffer var50 = new exercise01.RingBuffer(10);
    int var51 = var50.size();
    java.util.Spliterator var52 = var50.spliterator();
    exercise01.RingBuffer.RingBufferIterator var53 = var50.new RingBufferIterator();
    exercise01.RingBuffer var55 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var57 = new exercise01.RingBuffer(0);
    java.util.Spliterator var58 = var57.spliterator();
    exercise01.RingBuffer.RingBufferIterator var59 = var57.new RingBufferIterator();
    java.util.Spliterator var60 = var57.spliterator();
    var55.enqueue((java.lang.Object)var57);
    var50.enqueue((java.lang.Object)var55);
    java.util.Spliterator var63 = var55.spliterator();
    int var64 = var55.size();
    int var65 = var55.size();
    exercise01.RingBuffer.RingBufferIterator var66 = var55.new RingBufferIterator();
    boolean var67 = var55.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var68 = var55.new RingBufferIterator();
    exercise01.RingBuffer var70 = new exercise01.RingBuffer(0);
    java.util.Spliterator var71 = var70.spliterator();
    exercise01.RingBuffer.RingBufferIterator var72 = var70.new RingBufferIterator();
    java.util.Spliterator var73 = var70.spliterator();
    int var74 = var70.size();
    int var75 = var70.size();
    boolean var76 = var70.isEmpty();
    int var77 = var70.size();
    java.util.Spliterator var78 = var70.spliterator();
    java.util.Iterator var79 = var70.iterator();
    java.util.Iterator var80 = var70.iterator();
    java.util.Spliterator var81 = var70.spliterator();
    var55.enqueue((java.lang.Object)var70);
    var9.enqueue((java.lang.Object)var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);

  }

  public void test3() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test3");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var6.new RingBufferIterator();
    java.util.Spliterator var9 = var6.spliterator();
    int var10 = var6.size();
    int var11 = var6.size();
    boolean var12 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var6.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var13);
    int var15 = var1.size();
    boolean var16 = var1.isEmpty();
    int var17 = var1.size();
    int var18 = var1.size();
    boolean var19 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);

  }

  public void test4() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test4");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.util.Iterator var8 = var1.iterator();
    int var9 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    int var11 = var1.size();
    boolean var12 = var1.isEmpty();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(10);
    int var15 = var14.size();
    java.util.Spliterator var16 = var14.spliterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var14.new RingBufferIterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    java.util.Spliterator var22 = var21.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var21.new RingBufferIterator();
    java.util.Spliterator var24 = var21.spliterator();
    var19.enqueue((java.lang.Object)var21);
    var14.enqueue((java.lang.Object)var19);
    exercise01.RingBuffer.RingBufferIterator var27 = var19.new RingBufferIterator();
    int var28 = var19.size();
    exercise01.RingBuffer.RingBufferIterator var29 = var19.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var29);
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    int var33 = var32.size();
    int var34 = var32.size();
    int var35 = var32.size();
    exercise01.RingBuffer.RingBufferIterator var36 = var32.new RingBufferIterator();
    int var37 = var32.size();
    boolean var38 = var32.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var39 = var32.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var40 = var32.new RingBufferIterator();
    boolean var41 = var32.isEmpty();
    var1.enqueue((java.lang.Object)var32);
    exercise01.RingBuffer.RingBufferIterator var43 = var32.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var44 = var43.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);

  }

  public void test5() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test5");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var6.new RingBufferIterator();
    java.util.Spliterator var9 = var6.spliterator();
    int var10 = var6.size();
    int var11 = var6.size();
    boolean var12 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var6.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var13);
    int var15 = var1.size();
    boolean var16 = var1.isEmpty();
    java.util.Iterator var17 = var1.iterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(10);
    int var20 = var19.size();
    java.util.Spliterator var21 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var19.new RingBufferIterator();
    int var23 = var19.size();
    var19.enqueue((java.lang.Object)10);
    java.util.Iterator var26 = var19.iterator();
    int var27 = var19.size();
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(10);
    int var30 = var29.size();
    java.util.Spliterator var31 = var29.spliterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var29.new RingBufferIterator();
    int var33 = var29.size();
    var29.enqueue((java.lang.Object)10);
    int var36 = var29.size();
    java.util.Spliterator var37 = var29.spliterator();
    java.lang.Object var38 = var29.dequeue();
    var19.enqueue((java.lang.Object)var29);
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(0);
    java.util.Spliterator var42 = var41.spliterator();
    java.util.Spliterator var43 = var41.spliterator();
    java.util.Spliterator var44 = var41.spliterator();
    java.util.Spliterator var45 = var41.spliterator();
    int var46 = var41.size();
    java.util.Iterator var47 = var41.iterator();
    var29.enqueue((java.lang.Object)var41);
    int var49 = var41.size();
    var1.enqueue((java.lang.Object)var41);
    java.util.Spliterator var51 = var1.spliterator();
    boolean var52 = var1.isEmpty();
    java.util.Iterator var53 = var1.iterator();
    boolean var54 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + 10+ "'", var38.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);

  }

  public void test6() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test6");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    java.util.Spliterator var6 = var1.spliterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(10);
    int var9 = var8.size();
    boolean var10 = var8.isEmpty();
    java.util.Iterator var11 = var8.iterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var8.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var8.new RingBufferIterator();
    int var14 = var8.size();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    java.util.Spliterator var19 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var18.new RingBufferIterator();
    java.util.Spliterator var21 = var18.spliterator();
    var16.enqueue((java.lang.Object)var18);
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(100);
    java.util.Spliterator var25 = var24.spliterator();
    var16.enqueue((java.lang.Object)var25);
    java.util.Iterator var27 = var16.iterator();
    var8.enqueue((java.lang.Object)var16);
    exercise01.RingBuffer.RingBufferIterator var29 = var8.new RingBufferIterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(10);
    int var32 = var31.size();
    java.util.Spliterator var33 = var31.spliterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var31.new RingBufferIterator();
    java.util.Spliterator var35 = var31.spliterator();
    var8.enqueue((java.lang.Object)var31);
    int var37 = var31.size();
    java.util.Spliterator var38 = var31.spliterator();
    var1.enqueue((java.lang.Object)var31);
    java.util.Spliterator var40 = var1.spliterator();
    boolean var41 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test7() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test7");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    int var3 = var1.size();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Spliterator var6 = var1.spliterator();
    int var7 = var1.size();
    java.util.Iterator var8 = var1.iterator();
    boolean var9 = var1.isEmpty();
    boolean var10 = var1.isEmpty();
    java.util.Spliterator var11 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var1.new RingBufferIterator();
    java.util.Iterator var14 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test8() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test8");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    java.util.Iterator var7 = var1.iterator();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    java.util.Iterator var10 = var9.iterator();
    java.util.Spliterator var11 = var9.spliterator();
    java.util.Spliterator var12 = var9.spliterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    int var15 = var14.size();
    java.util.Iterator var16 = var14.iterator();
    var9.enqueue((java.lang.Object)var14);
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    java.util.Spliterator var19 = var14.spliterator();
    var1.enqueue((java.lang.Object)var19);
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(10);
    int var23 = var22.size();
    boolean var24 = var22.isEmpty();
    java.util.Iterator var25 = var22.iterator();
    java.util.Spliterator var26 = var22.spliterator();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(0);
    int var29 = var28.size();
    int var30 = var28.size();
    int var31 = var28.size();
    java.util.Iterator var32 = var28.iterator();
    var22.enqueue((java.lang.Object)var28);
    java.util.Spliterator var34 = var22.spliterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var22.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var36 = var22.new RingBufferIterator();
    int var37 = var22.size();
    java.util.Spliterator var38 = var22.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var22.new RingBufferIterator();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(0);
    java.util.Spliterator var42 = var41.spliterator();
    int var43 = var41.size();
    java.util.Spliterator var44 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var45 = var41.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var46 = var41.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var41.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var48 = var41.new RingBufferIterator();
    java.util.Spliterator var49 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var50 = var41.new RingBufferIterator();
    java.util.Iterator var51 = var41.iterator();
    var22.enqueue((java.lang.Object)var41);
    exercise01.RingBuffer.RingBufferIterator var53 = var22.new RingBufferIterator();
    java.lang.Object var54 = var22.dequeue();
    var1.enqueue((java.lang.Object)var22);
    exercise01.RingBuffer.RingBufferIterator var56 = var22.new RingBufferIterator();
    java.lang.Object var57 = var56.next();
    boolean var58 = var56.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);

  }

  public void test9() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test9");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    java.util.Iterator var5 = var4.iterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var4.new RingBufferIterator();
    int var7 = var4.size();
    var1.enqueue((java.lang.Object)var4);
    java.util.Spliterator var9 = var1.spliterator();
    java.lang.Object var10 = var1.dequeue();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    boolean var14 = var12.isEmpty();
    java.util.Iterator var15 = var12.iterator();
    java.util.Spliterator var16 = var12.spliterator();
    java.util.Iterator var17 = var12.iterator();
    boolean var18 = var12.isEmpty();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(0);
    int var21 = var20.size();
    java.util.Iterator var22 = var20.iterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var20.new RingBufferIterator();
    boolean var24 = var20.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var25 = var20.new RingBufferIterator();
    boolean var26 = var25.hasNext();
    var12.enqueue((java.lang.Object)var26);
    int var28 = var12.size();
    java.util.Spliterator var29 = var12.spliterator();
    int var30 = var12.size();
    int var31 = var12.size();
    var1.enqueue((java.lang.Object)var31);
    java.lang.Object var33 = var1.dequeue();
    int var34 = var1.size();
    boolean var35 = var1.isEmpty();
    boolean var36 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + 1+ "'", var33.equals(1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test10() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test10");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(2);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    java.util.Iterator var3 = var1.iterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(10);
    int var6 = var5.size();
    boolean var7 = var5.isEmpty();
    java.util.Iterator var8 = var5.iterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var5.new RingBufferIterator();
    java.util.Spliterator var10 = var5.spliterator();
    int var11 = var5.size();
    java.util.Iterator var12 = var5.iterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    int var15 = var1.size();
    int var16 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var17 = var1.new RingBufferIterator();
    java.util.Iterator var18 = var1.iterator();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(10);
    int var21 = var20.size();
    boolean var22 = var20.isEmpty();
    java.util.Iterator var23 = var20.iterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var20.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var20.new RingBufferIterator();
    int var26 = var20.size();
    exercise01.RingBuffer.RingBufferIterator var27 = var20.new RingBufferIterator();
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(10);
    int var30 = var29.size();
    java.util.Spliterator var31 = var29.spliterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var29.new RingBufferIterator();
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var36 = new exercise01.RingBuffer(0);
    java.util.Spliterator var37 = var36.spliterator();
    exercise01.RingBuffer.RingBufferIterator var38 = var36.new RingBufferIterator();
    java.util.Spliterator var39 = var36.spliterator();
    var34.enqueue((java.lang.Object)var36);
    var29.enqueue((java.lang.Object)var34);
    var20.enqueue((java.lang.Object)var29);
    java.lang.Object var43 = var29.dequeue();
    boolean var44 = var29.isEmpty();
    exercise01.RingBuffer var46 = new exercise01.RingBuffer(0);
    java.util.Iterator var47 = var46.iterator();
    int var48 = var46.size();
    int var49 = var46.size();
    java.util.Spliterator var50 = var46.spliterator();
    java.util.Iterator var51 = var46.iterator();
    exercise01.RingBuffer.RingBufferIterator var52 = var46.new RingBufferIterator();
    java.util.Spliterator var53 = var46.spliterator();
    exercise01.RingBuffer.RingBufferIterator var54 = var46.new RingBufferIterator();
    java.util.Iterator var55 = var46.iterator();
    boolean var56 = var46.isEmpty();
    java.util.Spliterator var57 = var46.spliterator();
    var29.enqueue((java.lang.Object)var46);
    exercise01.RingBuffer var60 = new exercise01.RingBuffer(10);
    int var61 = var60.size();
    boolean var62 = var60.isEmpty();
    java.util.Iterator var63 = var60.iterator();
    java.util.Spliterator var64 = var60.spliterator();
    exercise01.RingBuffer var66 = new exercise01.RingBuffer(1);
    boolean var67 = var66.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var68 = var66.new RingBufferIterator();
    java.util.Spliterator var69 = var66.spliterator();
    var60.enqueue((java.lang.Object)var66);
    java.util.Iterator var71 = var60.iterator();
    var29.enqueue((java.lang.Object)var71);
    boolean var73 = var29.isEmpty();
    java.util.Iterator var74 = var29.iterator();
    var1.enqueue((java.lang.Object)var29);
    java.util.Spliterator var76 = var29.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);

  }

  public void test11() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test11");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var3.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var3);
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    java.util.Iterator var11 = var10.iterator();
    int var12 = var10.size();
    int var13 = var10.size();
    java.util.Spliterator var14 = var10.spliterator();
    java.util.Iterator var15 = var10.iterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var10.new RingBufferIterator();
    java.util.Spliterator var17 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var10.new RingBufferIterator();
    java.util.Iterator var19 = var10.iterator();
    boolean var20 = var10.isEmpty();
    java.util.Iterator var21 = var10.iterator();
    var1.enqueue((java.lang.Object)var21);
    java.util.Spliterator var23 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var1.new RingBufferIterator();
    int var25 = var1.size();
    java.lang.Object var26 = var1.dequeue();
    java.util.Spliterator var27 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);

  }

  public void test12() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test12");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    int var8 = var6.size();
    var1.enqueue((java.lang.Object)var8);
    java.lang.Object var10 = var1.dequeue();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(0);
    java.util.Iterator var13 = var12.iterator();
    int var14 = var12.size();
    int var15 = var12.size();
    java.util.Spliterator var16 = var12.spliterator();
    java.util.Iterator var17 = var12.iterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var12.new RingBufferIterator();
    java.util.Spliterator var19 = var12.spliterator();
    java.util.Iterator var20 = var12.iterator();
    var1.enqueue((java.lang.Object)var20);
    java.util.Spliterator var22 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var1.new RingBufferIterator();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(10);
    int var27 = var26.size();
    java.util.Spliterator var28 = var26.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var26.new RingBufferIterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(0);
    java.util.Spliterator var34 = var33.spliterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var33.new RingBufferIterator();
    java.util.Spliterator var36 = var33.spliterator();
    var31.enqueue((java.lang.Object)var33);
    var26.enqueue((java.lang.Object)var31);
    exercise01.RingBuffer.RingBufferIterator var39 = var31.new RingBufferIterator();
    int var40 = var31.size();
    exercise01.RingBuffer.RingBufferIterator var41 = var31.new RingBufferIterator();
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(0);
    int var44 = var43.size();
    java.util.Spliterator var45 = var43.spliterator();
    int var46 = var43.size();
    java.util.Spliterator var47 = var43.spliterator();
    java.util.Iterator var48 = var43.iterator();
    boolean var49 = var43.isEmpty();
    java.util.Spliterator var50 = var43.spliterator();
    boolean var51 = var43.isEmpty();
    var31.enqueue((java.lang.Object)var51);
    exercise01.RingBuffer var54 = new exercise01.RingBuffer(100);
    java.util.Iterator var55 = var54.iterator();
    java.util.Spliterator var56 = var54.spliterator();
    int var57 = var54.size();
    java.util.Iterator var58 = var54.iterator();
    java.util.Spliterator var59 = var54.spliterator();
    exercise01.RingBuffer.RingBufferIterator var60 = var54.new RingBufferIterator();
    boolean var61 = var54.isEmpty();
    exercise01.RingBuffer var63 = new exercise01.RingBuffer(100);
    java.util.Iterator var64 = var63.iterator();
    java.util.Spliterator var65 = var63.spliterator();
    int var66 = var63.size();
    java.util.Iterator var67 = var63.iterator();
    java.util.Spliterator var68 = var63.spliterator();
    exercise01.RingBuffer.RingBufferIterator var69 = var63.new RingBufferIterator();
    boolean var70 = var63.isEmpty();
    var54.enqueue((java.lang.Object)var70);
    exercise01.RingBuffer.RingBufferIterator var72 = var54.new RingBufferIterator();
    var31.enqueue((java.lang.Object)var54);
    java.lang.Object var74 = var31.dequeue();
    var1.enqueue((java.lang.Object)var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + 0+ "'", var10.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);

  }

  public void test13() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test13");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    java.util.Iterator var8 = var1.iterator();
    java.util.Iterator var9 = var1.iterator();
    java.util.Spliterator var10 = var1.spliterator();
    boolean var11 = var1.isEmpty();
    java.util.Spliterator var12 = var1.spliterator();
    int var13 = var1.size();
    int var14 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);

  }

  public void test14() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test14");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Iterator var22 = var9.iterator();
    java.lang.Object var23 = var9.dequeue();
    java.lang.Object var24 = var9.dequeue();
    int var25 = var9.size();
    boolean var26 = var9.isEmpty();
    int var27 = var9.size();
    exercise01.RingBuffer.RingBufferIterator var28 = var9.new RingBufferIterator();
    boolean var29 = var28.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var28.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test15() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test15");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    boolean var22 = var9.isEmpty();
    java.util.Spliterator var23 = var9.spliterator();
    int var24 = var9.size();
    exercise01.RingBuffer.RingBufferIterator var25 = var9.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var9.new RingBufferIterator();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(1);
    java.util.Spliterator var29 = var28.spliterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(0);
    java.util.Iterator var32 = var31.iterator();
    int var33 = var31.size();
    int var34 = var31.size();
    int var35 = var31.size();
    java.util.Spliterator var36 = var31.spliterator();
    var28.enqueue((java.lang.Object)var31);
    boolean var38 = var28.isEmpty();
    java.util.Spliterator var39 = var28.spliterator();
    boolean var40 = var28.isEmpty();
    boolean var41 = var28.isEmpty();
    var9.enqueue((java.lang.Object)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test16() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test16");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    int var7 = var6.size();
    int var8 = var6.size();
    int var9 = var6.size();
    exercise01.RingBuffer.RingBufferIterator var10 = var6.new RingBufferIterator();
    boolean var11 = var10.hasNext();
    var1.enqueue((java.lang.Object)var10);
    boolean var13 = var1.isEmpty();
    boolean var14 = var1.isEmpty();
    boolean var15 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var16 = var1.new RingBufferIterator();
    java.util.Iterator var17 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var1.new RingBufferIterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(10);
    int var22 = var21.size();
    java.util.Spliterator var23 = var21.spliterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var21.new RingBufferIterator();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(0);
    java.util.Spliterator var29 = var28.spliterator();
    exercise01.RingBuffer.RingBufferIterator var30 = var28.new RingBufferIterator();
    java.util.Spliterator var31 = var28.spliterator();
    var26.enqueue((java.lang.Object)var28);
    var21.enqueue((java.lang.Object)var26);
    java.util.Spliterator var34 = var26.spliterator();
    java.util.Iterator var35 = var26.iterator();
    java.util.Iterator var36 = var26.iterator();
    exercise01.RingBuffer.RingBufferIterator var37 = var26.new RingBufferIterator();
    java.util.Iterator var38 = var26.iterator();
    java.util.Spliterator var39 = var26.spliterator();
    var1.enqueue((java.lang.Object)var26);
    exercise01.RingBuffer var42 = new exercise01.RingBuffer(0);
    int var43 = var42.size();
    java.util.Spliterator var44 = var42.spliterator();
    int var45 = var42.size();
    java.util.Spliterator var46 = var42.spliterator();
    java.util.Iterator var47 = var42.iterator();
    boolean var48 = var42.isEmpty();
    int var49 = var42.size();
    java.util.Iterator var50 = var42.iterator();
    boolean var51 = var42.isEmpty();
    java.util.Iterator var52 = var42.iterator();
    java.util.Iterator var53 = var42.iterator();
    java.util.Spliterator var54 = var42.spliterator();
    java.util.Iterator var55 = var42.iterator();
    java.util.Spliterator var56 = var42.spliterator();
    int var57 = var42.size();
    java.util.Iterator var58 = var42.iterator();
    var1.enqueue((java.lang.Object)var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);

  }

  public void test17() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test17");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(0);
    int var10 = var9.size();
    java.util.Iterator var11 = var9.iterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var9.new RingBufferIterator();
    boolean var13 = var9.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var14 = var9.new RingBufferIterator();
    boolean var15 = var14.hasNext();
    var1.enqueue((java.lang.Object)var15);
    int var17 = var1.size();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    java.util.Iterator var20 = var19.iterator();
    int var21 = var19.size();
    int var22 = var19.size();
    java.util.Spliterator var23 = var19.spliterator();
    java.util.Iterator var24 = var19.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var19.new RingBufferIterator();
    java.util.Spliterator var26 = var19.spliterator();
    java.util.Iterator var27 = var19.iterator();
    var1.enqueue((java.lang.Object)var27);
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(100);
    java.util.Iterator var31 = var30.iterator();
    java.util.Spliterator var32 = var30.spliterator();
    int var33 = var30.size();
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(0);
    java.util.Spliterator var36 = var35.spliterator();
    exercise01.RingBuffer.RingBufferIterator var37 = var35.new RingBufferIterator();
    java.util.Spliterator var38 = var35.spliterator();
    int var39 = var35.size();
    int var40 = var35.size();
    boolean var41 = var35.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var42 = var35.new RingBufferIterator();
    var30.enqueue((java.lang.Object)var42);
    var1.enqueue((java.lang.Object)var42);
    java.lang.Object var45 = var1.dequeue();
    java.util.Spliterator var46 = var1.spliterator();
    java.util.Iterator var47 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var48 = var1.new RingBufferIterator();
    boolean var49 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + false+ "'", var45.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test18() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test18");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Iterator var22 = var9.iterator();
    java.lang.Object var23 = var9.dequeue();
    boolean var24 = var9.isEmpty();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(10);
    int var27 = var26.size();
    java.util.Spliterator var28 = var26.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var26.new RingBufferIterator();
    int var30 = var26.size();
    var26.enqueue((java.lang.Object)10);
    java.lang.Object var33 = var26.dequeue();
    var26.enqueue((java.lang.Object)"hi!");
    java.lang.Object var36 = var26.dequeue();
    exercise01.RingBuffer.RingBufferIterator var37 = var26.new RingBufferIterator();
    boolean var38 = var26.isEmpty();
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var41 = var40.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var42 = var40.new RingBufferIterator();
    int var43 = var40.size();
    java.util.Iterator var44 = var40.iterator();
    java.util.Spliterator var45 = var40.spliterator();
    java.util.Spliterator var46 = var40.spliterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var40.new RingBufferIterator();
    java.util.Iterator var48 = var40.iterator();
    java.util.Spliterator var49 = var40.spliterator();
    java.util.Spliterator var50 = var40.spliterator();
    java.util.Spliterator var51 = var40.spliterator();
    java.util.Spliterator var52 = var40.spliterator();
    var26.enqueue((java.lang.Object)var40);
    var9.enqueue((java.lang.Object)var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var33 + "' != '" + 10+ "'", var33.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + "hi!"+ "'", var36.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test19() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test19");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(0);
    java.util.Spliterator var6 = var5.spliterator();
    int var7 = var5.size();
    java.util.Spliterator var8 = var5.spliterator();
    java.util.Iterator var9 = var5.iterator();
    var1.enqueue((java.lang.Object)var5);
    java.lang.Object var11 = var1.dequeue();
    java.util.Spliterator var12 = var1.spliterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(10);
    int var15 = var14.size();
    boolean var16 = var14.isEmpty();
    java.util.Iterator var17 = var14.iterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var14.new RingBufferIterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    int var22 = var21.size();
    java.util.Iterator var23 = var21.iterator();
    boolean var24 = var21.isEmpty();
    boolean var25 = var21.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var26 = var21.new RingBufferIterator();
    var14.enqueue((java.lang.Object)var21);
    exercise01.RingBuffer.RingBufferIterator var28 = var21.new RingBufferIterator();
    java.util.Iterator var29 = var21.iterator();
    boolean var30 = var21.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var31 = var21.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var21);
    exercise01.RingBuffer.RingBufferIterator var33 = var21.new RingBufferIterator();
    java.util.Iterator var34 = var21.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test20() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test20");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    java.util.Spliterator var8 = var1.spliterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    java.util.Spliterator var11 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var10.new RingBufferIterator();
    java.util.Iterator var13 = var10.iterator();
    java.util.Iterator var14 = var10.iterator();
    java.util.Spliterator var15 = var10.spliterator();
    boolean var16 = var10.isEmpty();
    boolean var17 = var10.isEmpty();
    int var18 = var10.size();
    java.util.Iterator var19 = var10.iterator();
    var1.enqueue((java.lang.Object)var19);
    java.lang.Object var21 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var22 = var1.new RingBufferIterator();
    int var23 = var1.size();
    java.util.Iterator var24 = var1.iterator();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(0);
    int var27 = var26.size();
    java.util.Spliterator var28 = var26.spliterator();
    int var29 = var26.size();
    java.util.Spliterator var30 = var26.spliterator();
    java.util.Iterator var31 = var26.iterator();
    boolean var32 = var26.isEmpty();
    int var33 = var26.size();
    java.util.Iterator var34 = var26.iterator();
    boolean var35 = var26.isEmpty();
    java.util.Iterator var36 = var26.iterator();
    java.util.Iterator var37 = var26.iterator();
    var1.enqueue((java.lang.Object)var37);
    exercise01.RingBuffer.RingBufferIterator var39 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (short)1+ "'", var21.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test21() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test21");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    boolean var2 = var1.isEmpty();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    boolean var5 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    boolean var7 = var1.isEmpty();
    int var8 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);

  }

  public void test22() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test22");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    java.util.Iterator var9 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    boolean var11 = var10.hasNext();
    boolean var12 = var10.hasNext();
    boolean var13 = var10.hasNext();
    boolean var14 = var10.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test23() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test23");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(0);
    int var10 = var9.size();
    java.util.Iterator var11 = var9.iterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var9.new RingBufferIterator();
    boolean var13 = var9.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var14 = var9.new RingBufferIterator();
    boolean var15 = var14.hasNext();
    var1.enqueue((java.lang.Object)var15);
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    java.util.Spliterator var19 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var18.new RingBufferIterator();
    java.util.Spliterator var21 = var18.spliterator();
    int var22 = var18.size();
    int var23 = var18.size();
    exercise01.RingBuffer.RingBufferIterator var24 = var18.new RingBufferIterator();
    boolean var25 = var24.hasNext();
    boolean var26 = var24.hasNext();
    var1.enqueue((java.lang.Object)var24);
    java.lang.Object var28 = var1.dequeue();
    java.util.Spliterator var29 = var1.spliterator();
    boolean var30 = var1.isEmpty();
    java.util.Iterator var31 = var1.iterator();
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(10);
    int var34 = var33.size();
    java.util.Spliterator var35 = var33.spliterator();
    exercise01.RingBuffer.RingBufferIterator var36 = var33.new RingBufferIterator();
    int var37 = var33.size();
    var33.enqueue((java.lang.Object)10);
    int var40 = var33.size();
    java.util.Spliterator var41 = var33.spliterator();
    boolean var42 = var33.isEmpty();
    java.util.Iterator var43 = var33.iterator();
    exercise01.RingBuffer.RingBufferIterator var44 = var33.new RingBufferIterator();
    exercise01.RingBuffer var46 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var47 = var46.new RingBufferIterator();
    int var48 = var46.size();
    exercise01.RingBuffer.RingBufferIterator var49 = var46.new RingBufferIterator();
    java.util.Iterator var50 = var46.iterator();
    boolean var51 = var46.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var52 = var46.new RingBufferIterator();
    boolean var53 = var46.isEmpty();
    var33.enqueue((java.lang.Object)var46);
    java.lang.Object var55 = var33.dequeue();
    var1.enqueue((java.lang.Object)var33);
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(100);
    java.util.Iterator var59 = var58.iterator();
    java.util.Spliterator var60 = var58.spliterator();
    int var61 = var58.size();
    exercise01.RingBuffer var63 = new exercise01.RingBuffer(0);
    java.util.Spliterator var64 = var63.spliterator();
    exercise01.RingBuffer.RingBufferIterator var65 = var63.new RingBufferIterator();
    java.util.Spliterator var66 = var63.spliterator();
    int var67 = var63.size();
    int var68 = var63.size();
    boolean var69 = var63.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var70 = var63.new RingBufferIterator();
    var58.enqueue((java.lang.Object)var70);
    int var72 = var58.size();
    exercise01.RingBuffer var74 = new exercise01.RingBuffer(10);
    int var75 = var74.size();
    boolean var76 = var74.isEmpty();
    java.util.Spliterator var77 = var74.spliterator();
    exercise01.RingBuffer var79 = new exercise01.RingBuffer(0);
    int var80 = var79.size();
    java.util.Iterator var81 = var79.iterator();
    boolean var82 = var79.isEmpty();
    boolean var83 = var79.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var84 = var79.new RingBufferIterator();
    int var85 = var79.size();
    var74.enqueue((java.lang.Object)var85);
    boolean var87 = var74.isEmpty();
    java.lang.Object var88 = var74.dequeue();
    java.util.Spliterator var89 = var74.spliterator();
    java.util.Iterator var90 = var74.iterator();
    java.util.Iterator var91 = var74.iterator();
    boolean var92 = var74.isEmpty();
    var58.enqueue((java.lang.Object)var74);
    int var94 = var58.size();
    java.lang.Object var95 = var58.dequeue();
    var33.enqueue(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var28 + "' != '" + false+ "'", var28.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + 10+ "'", var55.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var88 + "' != '" + 0+ "'", var88.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);

  }

  public void test24() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test24");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    boolean var2 = var1.isEmpty();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    int var5 = var4.size();
    java.util.Iterator var6 = var4.iterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var4.new RingBufferIterator();
    boolean var8 = var7.hasNext();
    boolean var9 = var7.hasNext();
    var1.enqueue((java.lang.Object)var7);
    boolean var11 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    boolean var13 = var1.isEmpty();
    java.util.Spliterator var14 = var1.spliterator();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(100);
    java.util.Spliterator var17 = var16.spliterator();
    boolean var18 = var16.isEmpty();
    int var19 = var16.size();
    exercise01.RingBuffer.RingBufferIterator var20 = var16.new RingBufferIterator();
    int var21 = var16.size();
    var1.enqueue((java.lang.Object)var21);
    java.util.Iterator var23 = var1.iterator();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(1);
    java.util.Spliterator var26 = var25.spliterator();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(0);
    int var29 = var28.size();
    var25.enqueue((java.lang.Object)var29);
    java.lang.Object var31 = var25.dequeue();
    java.util.Spliterator var32 = var25.spliterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var25.new RingBufferIterator();
    java.util.Iterator var34 = var25.iterator();
    boolean var35 = var25.isEmpty();
    java.util.Spliterator var36 = var25.spliterator();
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(10);
    int var39 = var38.size();
    boolean var40 = var38.isEmpty();
    java.util.Iterator var41 = var38.iterator();
    boolean var42 = var38.isEmpty();
    boolean var43 = var38.isEmpty();
    java.util.Iterator var44 = var38.iterator();
    boolean var45 = var38.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var46 = var38.new RingBufferIterator();
    var25.enqueue((java.lang.Object)var46);
    java.util.Spliterator var48 = var25.spliterator();
    var1.enqueue((java.lang.Object)var48);
    int var50 = var1.size();
    int var51 = var1.size();
    java.util.Iterator var52 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + 0+ "'", var31.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test25() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test25");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    java.util.Spliterator var9 = var1.spliterator();
    int var10 = var1.size();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(0);
    java.util.Iterator var13 = var12.iterator();
    int var14 = var12.size();
    int var15 = var12.size();
    java.util.Spliterator var16 = var12.spliterator();
    java.util.Iterator var17 = var12.iterator();
    java.util.Spliterator var18 = var12.spliterator();
    java.util.Spliterator var19 = var12.spliterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer.RingBufferIterator var21 = var1.new RingBufferIterator();
    int var22 = var1.size();
    boolean var23 = var1.isEmpty();
    boolean var24 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test26() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test26");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(0);
    java.util.Spliterator var6 = var5.spliterator();
    int var7 = var5.size();
    java.util.Spliterator var8 = var5.spliterator();
    java.util.Iterator var9 = var5.iterator();
    var1.enqueue((java.lang.Object)var5);
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    java.util.Spliterator var12 = var1.spliterator();
    java.util.Iterator var13 = var1.iterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(100);
    java.util.Iterator var16 = var15.iterator();
    var15.enqueue((java.lang.Object)0L);
    boolean var19 = var15.isEmpty();
    var1.enqueue((java.lang.Object)var19);
    java.lang.Object var21 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test27() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test27");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    int var2 = var1.size();
    int var3 = var1.size();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(10);
    int var6 = var5.size();
    java.util.Spliterator var7 = var5.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var5.new RingBufferIterator();
    int var9 = var5.size();
    var5.enqueue((java.lang.Object)10);
    java.lang.Object var12 = var5.dequeue();
    java.util.Spliterator var13 = var5.spliterator();
    java.util.Iterator var14 = var5.iterator();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(10);
    int var17 = var16.size();
    boolean var18 = var16.isEmpty();
    java.util.Iterator var19 = var16.iterator();
    java.util.Spliterator var20 = var16.spliterator();
    var5.enqueue((java.lang.Object)var20);
    var1.enqueue((java.lang.Object)var5);
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(0);
    java.util.Spliterator var25 = var24.spliterator();
    java.util.Spliterator var26 = var24.spliterator();
    java.util.Spliterator var27 = var24.spliterator();
    java.util.Iterator var28 = var24.iterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var24.new RingBufferIterator();
    java.util.Iterator var30 = var24.iterator();
    boolean var31 = var24.isEmpty();
    boolean var32 = var24.isEmpty();
    var5.enqueue((java.lang.Object)var24);
    java.util.Iterator var34 = var5.iterator();
    java.util.Spliterator var35 = var5.spliterator();
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(100);
    java.util.Spliterator var38 = var37.spliterator();
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(0);
    java.util.Iterator var41 = var40.iterator();
    exercise01.RingBuffer.RingBufferIterator var42 = var40.new RingBufferIterator();
    int var43 = var40.size();
    var37.enqueue((java.lang.Object)var40);
    java.util.Spliterator var45 = var37.spliterator();
    java.lang.Object var46 = var37.dequeue();
    var5.enqueue(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10+ "'", var12.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test28() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test28");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    int var3 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    java.util.Iterator var5 = var1.iterator();
    boolean var6 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    boolean var8 = var1.isEmpty();
    java.util.Spliterator var9 = var1.spliterator();
    boolean var10 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    java.util.Iterator var12 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test29() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test29");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    boolean var2 = var1.isEmpty();
    int var3 = var1.size();
    boolean var4 = var1.isEmpty();
    boolean var5 = var1.isEmpty();
    java.util.Iterator var6 = var1.iterator();
    java.util.Spliterator var7 = var1.spliterator();
    java.util.Spliterator var8 = var1.spliterator();
    java.util.Spliterator var9 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(100);
    java.util.Spliterator var13 = var12.spliterator();
    boolean var14 = var12.isEmpty();
    var12.enqueue((java.lang.Object)(byte)1);
    boolean var17 = var12.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var18 = var12.new RingBufferIterator();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(10);
    int var21 = var20.size();
    boolean var22 = var20.isEmpty();
    java.util.Iterator var23 = var20.iterator();
    boolean var24 = var20.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var25 = var20.new RingBufferIterator();
    java.util.Spliterator var26 = var20.spliterator();
    boolean var27 = var20.isEmpty();
    int var28 = var20.size();
    java.util.Spliterator var29 = var20.spliterator();
    boolean var30 = var20.isEmpty();
    var12.enqueue((java.lang.Object)var20);
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(10);
    boolean var34 = var33.isEmpty();
    exercise01.RingBuffer var36 = new exercise01.RingBuffer(0);
    int var37 = var36.size();
    java.util.Iterator var38 = var36.iterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var36.new RingBufferIterator();
    boolean var40 = var39.hasNext();
    boolean var41 = var39.hasNext();
    var33.enqueue((java.lang.Object)var39);
    boolean var43 = var33.isEmpty();
    boolean var44 = var33.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var45 = var33.new RingBufferIterator();
    exercise01.RingBuffer var47 = new exercise01.RingBuffer(10);
    int var48 = var47.size();
    java.util.Spliterator var49 = var47.spliterator();
    exercise01.RingBuffer.RingBufferIterator var50 = var47.new RingBufferIterator();
    exercise01.RingBuffer var52 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var54 = new exercise01.RingBuffer(0);
    java.util.Spliterator var55 = var54.spliterator();
    exercise01.RingBuffer.RingBufferIterator var56 = var54.new RingBufferIterator();
    java.util.Spliterator var57 = var54.spliterator();
    var52.enqueue((java.lang.Object)var54);
    var47.enqueue((java.lang.Object)var52);
    exercise01.RingBuffer.RingBufferIterator var60 = var52.new RingBufferIterator();
    boolean var61 = var60.hasNext();
    java.lang.Object var62 = var60.next();
    boolean var63 = var60.hasNext();
    var33.enqueue((java.lang.Object)var60);
    var12.enqueue((java.lang.Object)var33);
    boolean var66 = var12.isEmpty();
    var1.enqueue((java.lang.Object)var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);

  }

  public void test30() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test30");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    java.util.Iterator var7 = var1.iterator();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    java.util.Iterator var10 = var9.iterator();
    java.util.Spliterator var11 = var9.spliterator();
    java.util.Spliterator var12 = var9.spliterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    int var15 = var14.size();
    java.util.Iterator var16 = var14.iterator();
    var9.enqueue((java.lang.Object)var14);
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    java.util.Spliterator var19 = var14.spliterator();
    var1.enqueue((java.lang.Object)var19);
    java.util.Spliterator var21 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var1.new RingBufferIterator();
    java.util.Spliterator var23 = var1.spliterator();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(10);
    int var26 = var25.size();
    boolean var27 = var25.isEmpty();
    java.util.Iterator var28 = var25.iterator();
    boolean var29 = var25.isEmpty();
    boolean var30 = var25.isEmpty();
    java.util.Iterator var31 = var25.iterator();
    boolean var32 = var25.isEmpty();
    boolean var33 = var25.isEmpty();
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(0);
    java.util.Iterator var36 = var35.iterator();
    exercise01.RingBuffer.RingBufferIterator var37 = var35.new RingBufferIterator();
    int var38 = var35.size();
    int var39 = var35.size();
    exercise01.RingBuffer.RingBufferIterator var40 = var35.new RingBufferIterator();
    int var41 = var35.size();
    var25.enqueue((java.lang.Object)var35);
    int var43 = var35.size();
    int var44 = var35.size();
    java.util.Iterator var45 = var35.iterator();
    int var46 = var35.size();
    java.util.Spliterator var47 = var35.spliterator();
    java.util.Spliterator var48 = var35.spliterator();
    var1.enqueue((java.lang.Object)var48);
    java.util.Iterator var50 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var51 = var1.new RingBufferIterator();
    boolean var52 = var51.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);

  }

  public void test31() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test31");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var3.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var9 = var1.dequeue();
    boolean var10 = var1.isEmpty();
    boolean var11 = var1.isEmpty();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(100);
    java.util.Iterator var14 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    java.util.Spliterator var20 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var19.new RingBufferIterator();
    java.util.Spliterator var22 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var19.new RingBufferIterator();
    var17.enqueue((java.lang.Object)var19);
    java.lang.Object var25 = var17.dequeue();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    java.util.Spliterator var28 = var27.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var27.new RingBufferIterator();
    java.util.Iterator var30 = var27.iterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var27.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var27.new RingBufferIterator();
    var17.enqueue((java.lang.Object)var32);
    java.util.Spliterator var34 = var17.spliterator();
    var13.enqueue((java.lang.Object)var17);
    var1.enqueue((java.lang.Object)var13);
    java.util.Spliterator var37 = var13.spliterator();
    java.util.Iterator var38 = var13.iterator();
    java.util.Spliterator var39 = var13.spliterator();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(0);
    java.util.Spliterator var42 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var41.new RingBufferIterator();
    java.util.Spliterator var44 = var41.spliterator();
    int var45 = var41.size();
    exercise01.RingBuffer.RingBufferIterator var46 = var41.new RingBufferIterator();
    int var47 = var41.size();
    var13.enqueue((java.lang.Object)var47);
    int var49 = var13.size();
    java.util.Spliterator var50 = var13.spliterator();
    exercise01.RingBuffer.RingBufferIterator var51 = var13.new RingBufferIterator();
    java.lang.Object var52 = var13.dequeue();
    java.lang.Object var53 = var13.dequeue();
    int var54 = var13.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + 0+ "'", var53.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);

  }

  public void test32() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test32");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var3.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var9 = var1.dequeue();
    boolean var10 = var1.isEmpty();
    boolean var11 = var1.isEmpty();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(100);
    java.util.Iterator var14 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    java.util.Spliterator var20 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var19.new RingBufferIterator();
    java.util.Spliterator var22 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var19.new RingBufferIterator();
    var17.enqueue((java.lang.Object)var19);
    java.lang.Object var25 = var17.dequeue();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    java.util.Spliterator var28 = var27.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var27.new RingBufferIterator();
    java.util.Iterator var30 = var27.iterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var27.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var27.new RingBufferIterator();
    var17.enqueue((java.lang.Object)var32);
    java.util.Spliterator var34 = var17.spliterator();
    var13.enqueue((java.lang.Object)var17);
    var1.enqueue((java.lang.Object)var13);
    java.util.Spliterator var37 = var13.spliterator();
    java.util.Iterator var38 = var13.iterator();
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(10);
    int var41 = var40.size();
    boolean var42 = var40.isEmpty();
    java.util.Spliterator var43 = var40.spliterator();
    exercise01.RingBuffer var45 = new exercise01.RingBuffer(0);
    int var46 = var45.size();
    java.util.Iterator var47 = var45.iterator();
    boolean var48 = var45.isEmpty();
    boolean var49 = var45.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var50 = var45.new RingBufferIterator();
    int var51 = var45.size();
    var40.enqueue((java.lang.Object)var51);
    boolean var53 = var40.isEmpty();
    java.lang.Object var54 = var40.dequeue();
    java.util.Spliterator var55 = var40.spliterator();
    java.util.Iterator var56 = var40.iterator();
    java.util.Spliterator var57 = var40.spliterator();
    var13.enqueue((java.lang.Object)var40);
    exercise01.RingBuffer.RingBufferIterator var59 = var40.new RingBufferIterator();
    exercise01.RingBuffer var61 = new exercise01.RingBuffer(10);
    int var62 = var61.size();
    int var63 = var61.size();
    exercise01.RingBuffer.RingBufferIterator var64 = var61.new RingBufferIterator();
    int var65 = var61.size();
    java.util.Spliterator var66 = var61.spliterator();
    exercise01.RingBuffer.RingBufferIterator var67 = var61.new RingBufferIterator();
    var40.enqueue((java.lang.Object)var67);
    int var69 = var40.size();
    exercise01.RingBuffer.RingBufferIterator var70 = var40.new RingBufferIterator();
    boolean var71 = var70.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var54 + "' != '" + 0+ "'", var54.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);

  }

  public void test33() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test33");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Spliterator var4 = var1.spliterator();
    int var5 = var1.size();
    int var6 = var1.size();
    boolean var7 = var1.isEmpty();
    boolean var8 = var1.isEmpty();
    java.util.Iterator var9 = var1.iterator();
    int var10 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    boolean var12 = var11.hasNext();
    boolean var13 = var11.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);

  }

  public void test34() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test34");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    var1.enqueue((java.lang.Object)"hi!");
    java.lang.Object var11 = var1.dequeue();
    int var12 = var1.size();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    java.util.Iterator var15 = var14.iterator();
    int var16 = var14.size();
    int var17 = var14.size();
    int var18 = var14.size();
    java.util.Iterator var19 = var14.iterator();
    java.util.Spliterator var20 = var14.spliterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var14.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var21);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var21.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "hi!"+ "'", var11.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test35() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test35");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Spliterator var22 = var9.spliterator();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(0);
    java.util.Spliterator var27 = var26.spliterator();
    exercise01.RingBuffer.RingBufferIterator var28 = var26.new RingBufferIterator();
    java.util.Spliterator var29 = var26.spliterator();
    var24.enqueue((java.lang.Object)var26);
    java.lang.Object var31 = var24.dequeue();
    java.util.Iterator var32 = var24.iterator();
    java.util.Iterator var33 = var24.iterator();
    boolean var34 = var24.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var35 = var24.new RingBufferIterator();
    var9.enqueue((java.lang.Object)var24);
    java.util.Spliterator var37 = var9.spliterator();
    java.util.Spliterator var38 = var9.spliterator();
    java.util.Spliterator var39 = var9.spliterator();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(0);
    int var42 = var41.size();
    java.util.Iterator var43 = var41.iterator();
    boolean var44 = var41.isEmpty();
    boolean var45 = var41.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var46 = var41.new RingBufferIterator();
    int var47 = var41.size();
    java.util.Spliterator var48 = var41.spliterator();
    int var49 = var41.size();
    int var50 = var41.size();
    java.util.Spliterator var51 = var41.spliterator();
    boolean var52 = var41.isEmpty();
    java.util.Iterator var53 = var41.iterator();
    boolean var54 = var41.isEmpty();
    java.util.Spliterator var55 = var41.spliterator();
    java.util.Spliterator var56 = var41.spliterator();
    java.util.Iterator var57 = var41.iterator();
    var9.enqueue((java.lang.Object)var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test36() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test36");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    java.util.Iterator var4 = var1.iterator();
    java.util.Iterator var5 = var1.iterator();
    java.util.Iterator var6 = var1.iterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Iterator var9 = var8.iterator();
    int var10 = var8.size();
    int var11 = var8.size();
    java.util.Spliterator var12 = var8.spliterator();
    java.util.Iterator var13 = var8.iterator();
    java.util.Spliterator var14 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var8.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var8.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var8.new RingBufferIterator();
    boolean var18 = var17.hasNext();
    var1.enqueue((java.lang.Object)var17);
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    java.util.Spliterator var22 = var21.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var21.new RingBufferIterator();
    java.util.Iterator var24 = var21.iterator();
    boolean var25 = var21.isEmpty();
    boolean var26 = var21.isEmpty();
    boolean var27 = var21.isEmpty();
    java.util.Iterator var28 = var21.iterator();
    int var29 = var21.size();
    var1.enqueue((java.lang.Object)var21);
    exercise01.RingBuffer.RingBufferIterator var31 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var1.new RingBufferIterator();
    boolean var33 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);

  }

  public void test37() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test37");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Spliterator var6 = var1.spliterator();
    java.util.Spliterator var7 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    boolean var9 = var8.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var8.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);

  }

  public void test38() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test38");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    int var5 = var4.size();
    var1.enqueue((java.lang.Object)var5);
    java.lang.Object var7 = var1.dequeue();
    java.util.Spliterator var8 = var1.spliterator();
    boolean var9 = var1.isEmpty();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    boolean var14 = var12.isEmpty();
    java.util.Iterator var15 = var12.iterator();
    boolean var16 = var12.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var17 = var12.new RingBufferIterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(10);
    int var20 = var19.size();
    boolean var21 = var19.isEmpty();
    java.util.Iterator var22 = var19.iterator();
    java.util.Spliterator var23 = var19.spliterator();
    java.util.Iterator var24 = var19.iterator();
    boolean var25 = var19.isEmpty();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    int var28 = var27.size();
    java.util.Iterator var29 = var27.iterator();
    exercise01.RingBuffer.RingBufferIterator var30 = var27.new RingBufferIterator();
    boolean var31 = var27.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var32 = var27.new RingBufferIterator();
    boolean var33 = var32.hasNext();
    var19.enqueue((java.lang.Object)var33);
    int var35 = var19.size();
    java.util.Spliterator var36 = var19.spliterator();
    var12.enqueue((java.lang.Object)var36);
    java.util.Spliterator var38 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var12.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var39);
    boolean var41 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var42 = var1.new RingBufferIterator();
    java.lang.Object var43 = var42.next();
    boolean var44 = var42.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);

  }

  public void test39() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test39");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Iterator var22 = var9.iterator();
    boolean var23 = var9.isEmpty();
    java.lang.Object var24 = var9.dequeue();
    exercise01.RingBuffer.RingBufferIterator var25 = var9.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var9.new RingBufferIterator();
    java.util.Iterator var27 = var9.iterator();
    java.lang.Object var28 = var9.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test40() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test40");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    java.util.Iterator var9 = var1.iterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    int var14 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    java.util.Spliterator var17 = var12.spliterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(100);
    java.util.Spliterator var21 = var20.spliterator();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(0);
    java.util.Iterator var24 = var23.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var23.new RingBufferIterator();
    int var26 = var23.size();
    var20.enqueue((java.lang.Object)var23);
    java.util.Spliterator var28 = var23.spliterator();
    var1.enqueue((java.lang.Object)var28);
    java.util.Iterator var30 = var1.iterator();
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    java.util.Iterator var33 = var32.iterator();
    int var34 = var32.size();
    int var35 = var32.size();
    java.util.Spliterator var36 = var32.spliterator();
    java.util.Iterator var37 = var32.iterator();
    java.util.Spliterator var38 = var32.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var32.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var40 = var32.new RingBufferIterator();
    int var41 = var32.size();
    var1.enqueue((java.lang.Object)var32);
    java.lang.Object var43 = var1.dequeue();
    exercise01.RingBuffer var45 = new exercise01.RingBuffer(10);
    int var46 = var45.size();
    boolean var47 = var45.isEmpty();
    java.util.Iterator var48 = var45.iterator();
    exercise01.RingBuffer.RingBufferIterator var49 = var45.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var50 = var45.new RingBufferIterator();
    var45.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var53 = var45.new RingBufferIterator();
    boolean var54 = var45.isEmpty();
    java.lang.Object var55 = var45.dequeue();
    var1.enqueue((java.lang.Object)var45);
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(10);
    int var59 = var58.size();
    boolean var60 = var58.isEmpty();
    java.util.Iterator var61 = var58.iterator();
    java.util.Spliterator var62 = var58.spliterator();
    var58.enqueue((java.lang.Object)(short)1);
    int var65 = var58.size();
    exercise01.RingBuffer.RingBufferIterator var66 = var58.new RingBufferIterator();
    exercise01.RingBuffer var68 = new exercise01.RingBuffer(0);
    java.util.Iterator var69 = var68.iterator();
    int var70 = var68.size();
    int var71 = var68.size();
    java.util.Spliterator var72 = var68.spliterator();
    exercise01.RingBuffer.RingBufferIterator var73 = var68.new RingBufferIterator();
    int var74 = var68.size();
    java.util.Spliterator var75 = var68.spliterator();
    exercise01.RingBuffer.RingBufferIterator var76 = var68.new RingBufferIterator();
    var58.enqueue((java.lang.Object)var76);
    boolean var78 = var58.isEmpty();
    java.util.Spliterator var79 = var58.spliterator();
    java.util.Iterator var80 = var58.iterator();
    exercise01.RingBuffer var82 = new exercise01.RingBuffer(0);
    int var83 = var82.size();
    java.util.Iterator var84 = var82.iterator();
    boolean var85 = var82.isEmpty();
    boolean var86 = var82.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var87 = var82.new RingBufferIterator();
    int var88 = var82.size();
    java.util.Spliterator var89 = var82.spliterator();
    int var90 = var82.size();
    int var91 = var82.size();
    int var92 = var82.size();
    exercise01.RingBuffer.RingBufferIterator var93 = var82.new RingBufferIterator();
    var58.enqueue((java.lang.Object)var82);
    boolean var95 = var58.isEmpty();
    var45.enqueue((java.lang.Object)var58);
    java.util.Spliterator var97 = var45.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1.0f)+ "'", var55.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var95 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test41() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test41");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    int var8 = var1.size();
    java.lang.Object var9 = var1.dequeue();
    boolean var10 = var1.isEmpty();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(0);
    java.util.Spliterator var13 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var12.new RingBufferIterator();
    java.util.Spliterator var15 = var12.spliterator();
    int var16 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var17 = var12.new RingBufferIterator();
    java.util.Iterator var18 = var12.iterator();
    boolean var19 = var12.isEmpty();
    int var20 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var21 = var12.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var12.new RingBufferIterator();
    boolean var23 = var12.isEmpty();
    java.util.Spliterator var24 = var12.spliterator();
    java.util.Iterator var25 = var12.iterator();
    var1.enqueue((java.lang.Object)var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + (short)1+ "'", var9.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);

  }

  public void test42() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test42");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    int var2 = var1.size();
    java.util.Iterator var3 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    int var7 = var1.size();
    java.util.Iterator var8 = var1.iterator();
    java.util.Iterator var9 = var1.iterator();
    int var10 = var1.size();
    boolean var11 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test43() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test43");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    java.util.Spliterator var6 = var1.spliterator();
    boolean var7 = var1.isEmpty();
    int var8 = var1.size();
    int var9 = var1.size();
    int var10 = var1.size();
    java.util.Spliterator var11 = var1.spliterator();
    java.util.Iterator var12 = var1.iterator();
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    boolean var15 = var14.hasNext();
    boolean var16 = var14.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test44() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test44");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(0);
    java.util.Spliterator var6 = var5.spliterator();
    int var7 = var5.size();
    java.util.Spliterator var8 = var5.spliterator();
    java.util.Iterator var9 = var5.iterator();
    var1.enqueue((java.lang.Object)var5);
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(100);
    java.util.Spliterator var13 = var12.spliterator();
    boolean var14 = var12.isEmpty();
    int var15 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var16 = var12.new RingBufferIterator();
    java.util.Spliterator var17 = var12.spliterator();
    var1.enqueue((java.lang.Object)var12);
    java.util.Spliterator var19 = var1.spliterator();
    java.lang.Object var20 = var1.dequeue();
    java.util.Iterator var21 = var1.iterator();
    java.lang.Object var22 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test45() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test45");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    boolean var6 = var1.isEmpty();
    boolean var7 = var1.isEmpty();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(0);
    int var10 = var9.size();
    java.util.Spliterator var11 = var9.spliterator();
    int var12 = var9.size();
    java.util.Spliterator var13 = var9.spliterator();
    java.util.Iterator var14 = var9.iterator();
    boolean var15 = var9.isEmpty();
    int var16 = var9.size();
    exercise01.RingBuffer.RingBufferIterator var17 = var9.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var9.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var18);
    int var20 = var1.size();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(0);
    java.util.Iterator var23 = var22.iterator();
    int var24 = var22.size();
    int var25 = var22.size();
    java.util.Spliterator var26 = var22.spliterator();
    java.util.Iterator var27 = var22.iterator();
    int var28 = var22.size();
    int var29 = var22.size();
    java.util.Iterator var30 = var22.iterator();
    boolean var31 = var22.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var32 = var22.new RingBufferIterator();
    java.util.Spliterator var33 = var22.spliterator();
    java.util.Spliterator var34 = var22.spliterator();
    var1.enqueue((java.lang.Object)var22);
    java.util.Spliterator var36 = var1.spliterator();
    boolean var37 = var1.isEmpty();
    java.lang.Object var38 = var1.dequeue();
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(0);
    java.util.Spliterator var41 = var40.spliterator();
    int var42 = var40.size();
    java.util.Spliterator var43 = var40.spliterator();
    exercise01.RingBuffer.RingBufferIterator var44 = var40.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var45 = var40.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var46 = var40.new RingBufferIterator();
    boolean var47 = var40.isEmpty();
    boolean var48 = var40.isEmpty();
    boolean var49 = var40.isEmpty();
    var1.enqueue((java.lang.Object)var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);

  }

  public void test46() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test46");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    int var9 = var1.size();
    boolean var10 = var1.isEmpty();
    java.util.Iterator var11 = var1.iterator();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);

  }

  public void test47() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test47");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    java.util.Spliterator var6 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    boolean var8 = var1.isEmpty();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    boolean var11 = var10.isEmpty();
    java.util.Iterator var12 = var10.iterator();
    java.util.Iterator var13 = var10.iterator();
    java.util.Spliterator var14 = var10.spliterator();
    var1.enqueue((java.lang.Object)var14);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    int var18 = var17.size();
    boolean var19 = var17.isEmpty();
    java.util.Iterator var20 = var17.iterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var17.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var17.new RingBufferIterator();
    var17.enqueue((java.lang.Object)(-1.0f));
    java.util.Iterator var25 = var17.iterator();
    boolean var26 = var17.isEmpty();
    int var27 = var17.size();
    int var28 = var17.size();
    java.lang.Object var29 = var17.dequeue();
    var1.enqueue((java.lang.Object)var17);
    int var31 = var17.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + (-1.0f)+ "'", var29.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test48() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test48");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var14 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var6.new RingBufferIterator();
    int var16 = var6.size();
    int var17 = var6.size();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(100);
    java.util.Spliterator var20 = var19.spliterator();
    boolean var21 = var19.isEmpty();
    int var22 = var19.size();
    java.util.Iterator var23 = var19.iterator();
    int var24 = var19.size();
    boolean var25 = var19.isEmpty();
    java.util.Iterator var26 = var19.iterator();
    java.util.Spliterator var27 = var19.spliterator();
    boolean var28 = var19.isEmpty();
    java.util.Iterator var29 = var19.iterator();
    var6.enqueue((java.lang.Object)var29);
    boolean var31 = var6.isEmpty();
    java.lang.Object var32 = var6.dequeue();
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(1);
    boolean var35 = var34.isEmpty();
    int var36 = var34.size();
    exercise01.RingBuffer.RingBufferIterator var37 = var34.new RingBufferIterator();
    exercise01.RingBuffer var39 = new exercise01.RingBuffer(10);
    int var40 = var39.size();
    boolean var41 = var39.isEmpty();
    java.util.Iterator var42 = var39.iterator();
    boolean var43 = var39.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var44 = var39.new RingBufferIterator();
    exercise01.RingBuffer var46 = new exercise01.RingBuffer(10);
    int var47 = var46.size();
    boolean var48 = var46.isEmpty();
    java.util.Iterator var49 = var46.iterator();
    java.util.Spliterator var50 = var46.spliterator();
    java.util.Iterator var51 = var46.iterator();
    boolean var52 = var46.isEmpty();
    exercise01.RingBuffer var54 = new exercise01.RingBuffer(0);
    int var55 = var54.size();
    java.util.Iterator var56 = var54.iterator();
    exercise01.RingBuffer.RingBufferIterator var57 = var54.new RingBufferIterator();
    boolean var58 = var54.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var59 = var54.new RingBufferIterator();
    boolean var60 = var59.hasNext();
    var46.enqueue((java.lang.Object)var60);
    int var62 = var46.size();
    java.util.Spliterator var63 = var46.spliterator();
    var39.enqueue((java.lang.Object)var63);
    java.util.Iterator var65 = var39.iterator();
    boolean var66 = var39.isEmpty();
    java.util.Iterator var67 = var39.iterator();
    var34.enqueue((java.lang.Object)var39);
    java.util.Iterator var69 = var34.iterator();
    java.util.Iterator var70 = var34.iterator();
    int var71 = var34.size();
    java.lang.Object var72 = var34.dequeue();
    var6.enqueue((java.lang.Object)var34);
    exercise01.RingBuffer.RingBufferIterator var74 = var6.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);

  }

  public void test49() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test49");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    java.util.Spliterator var12 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var10.new RingBufferIterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(0);
    java.util.Spliterator var18 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var17.new RingBufferIterator();
    java.util.Spliterator var20 = var17.spliterator();
    var15.enqueue((java.lang.Object)var17);
    var10.enqueue((java.lang.Object)var15);
    var1.enqueue((java.lang.Object)var10);
    java.lang.Object var24 = var10.dequeue();
    exercise01.RingBuffer.RingBufferIterator var25 = var10.new RingBufferIterator();
    java.util.Iterator var26 = var10.iterator();
    java.util.Iterator var27 = var10.iterator();
    int var28 = var10.size();
    exercise01.RingBuffer.RingBufferIterator var29 = var10.new RingBufferIterator();
    int var30 = var10.size();
    int var31 = var10.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);

  }

  public void test50() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test50");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(1);
    boolean var8 = var7.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var9 = var7.new RingBufferIterator();
    java.util.Spliterator var10 = var7.spliterator();
    var1.enqueue((java.lang.Object)var7);
    java.util.Iterator var12 = var1.iterator();
    int var13 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    java.util.Iterator var15 = var1.iterator();
    java.util.Iterator var16 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test51() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test51");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    boolean var7 = var1.isEmpty();
    java.util.Spliterator var8 = var1.spliterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    boolean var12 = var10.isEmpty();
    java.util.Iterator var13 = var10.iterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var10.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var10.new RingBufferIterator();
    int var16 = var10.size();
    exercise01.RingBuffer.RingBufferIterator var17 = var10.new RingBufferIterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(10);
    int var20 = var19.size();
    java.util.Spliterator var21 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var19.new RingBufferIterator();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(0);
    java.util.Spliterator var27 = var26.spliterator();
    exercise01.RingBuffer.RingBufferIterator var28 = var26.new RingBufferIterator();
    java.util.Spliterator var29 = var26.spliterator();
    var24.enqueue((java.lang.Object)var26);
    var19.enqueue((java.lang.Object)var24);
    var10.enqueue((java.lang.Object)var19);
    int var33 = var19.size();
    boolean var34 = var19.isEmpty();
    java.util.Iterator var35 = var19.iterator();
    int var36 = var19.size();
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(0);
    java.util.Iterator var39 = var38.iterator();
    int var40 = var38.size();
    int var41 = var38.size();
    java.util.Spliterator var42 = var38.spliterator();
    java.util.Iterator var43 = var38.iterator();
    boolean var44 = var38.isEmpty();
    int var45 = var38.size();
    exercise01.RingBuffer.RingBufferIterator var46 = var38.new RingBufferIterator();
    java.util.Spliterator var47 = var38.spliterator();
    var19.enqueue((java.lang.Object)var38);
    boolean var49 = var38.isEmpty();
    var1.enqueue((java.lang.Object)var38);
    exercise01.RingBuffer.RingBufferIterator var51 = var1.new RingBufferIterator();
    int var52 = var1.size();
    exercise01.RingBuffer var54 = new exercise01.RingBuffer(10);
    int var55 = var54.size();
    boolean var56 = var54.isEmpty();
    java.util.Iterator var57 = var54.iterator();
    java.util.Spliterator var58 = var54.spliterator();
    exercise01.RingBuffer var60 = new exercise01.RingBuffer(1);
    boolean var61 = var60.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var62 = var60.new RingBufferIterator();
    java.util.Spliterator var63 = var60.spliterator();
    var54.enqueue((java.lang.Object)var60);
    java.util.Iterator var65 = var54.iterator();
    boolean var66 = var54.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var67 = var54.new RingBufferIterator();
    exercise01.RingBuffer var69 = new exercise01.RingBuffer(10);
    int var70 = var69.size();
    boolean var71 = var69.isEmpty();
    java.util.Iterator var72 = var69.iterator();
    java.util.Spliterator var73 = var69.spliterator();
    java.util.Iterator var74 = var69.iterator();
    java.util.Iterator var75 = var69.iterator();
    exercise01.RingBuffer var77 = new exercise01.RingBuffer(100);
    java.util.Iterator var78 = var77.iterator();
    java.util.Spliterator var79 = var77.spliterator();
    java.util.Spliterator var80 = var77.spliterator();
    exercise01.RingBuffer var82 = new exercise01.RingBuffer(0);
    int var83 = var82.size();
    java.util.Iterator var84 = var82.iterator();
    var77.enqueue((java.lang.Object)var82);
    exercise01.RingBuffer.RingBufferIterator var86 = var82.new RingBufferIterator();
    java.util.Spliterator var87 = var82.spliterator();
    var69.enqueue((java.lang.Object)var87);
    exercise01.RingBuffer.RingBufferIterator var89 = var69.new RingBufferIterator();
    boolean var90 = var69.isEmpty();
    var54.enqueue((java.lang.Object)var69);
    exercise01.RingBuffer.RingBufferIterator var92 = var54.new RingBufferIterator();
    java.util.Spliterator var93 = var54.spliterator();
    exercise01.RingBuffer.RingBufferIterator var94 = var54.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var94);
    exercise01.RingBuffer.RingBufferIterator var96 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);

  }

  public void test52() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test52");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    int var22 = var9.size();
    int var23 = var9.size();
    int var24 = var9.size();
    java.util.Spliterator var25 = var9.spliterator();
    java.util.Spliterator var26 = var9.spliterator();
    int var27 = var9.size();
    java.util.Spliterator var28 = var9.spliterator();
    boolean var29 = var9.isEmpty();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(0);
    java.util.Iterator var32 = var31.iterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var31.new RingBufferIterator();
    int var34 = var31.size();
    java.util.Iterator var35 = var31.iterator();
    int var36 = var31.size();
    int var37 = var31.size();
    exercise01.RingBuffer.RingBufferIterator var38 = var31.new RingBufferIterator();
    boolean var39 = var31.isEmpty();
    var9.enqueue((java.lang.Object)var31);
    exercise01.RingBuffer var42 = new exercise01.RingBuffer(0);
    java.util.Iterator var43 = var42.iterator();
    int var44 = var42.size();
    int var45 = var42.size();
    java.util.Spliterator var46 = var42.spliterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var42.new RingBufferIterator();
    int var48 = var42.size();
    java.util.Iterator var49 = var42.iterator();
    java.util.Spliterator var50 = var42.spliterator();
    java.util.Iterator var51 = var42.iterator();
    exercise01.RingBuffer.RingBufferIterator var52 = var42.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var53 = var42.new RingBufferIterator();
    java.util.Spliterator var54 = var42.spliterator();
    var9.enqueue((java.lang.Object)var42);
    java.util.Spliterator var56 = var42.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test53() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test53");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    java.util.Iterator var3 = var1.iterator();
    int var4 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    boolean var6 = var5.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);

  }

  public void test54() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test54");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    boolean var9 = var1.isEmpty();
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(10);
    int var12 = var11.size();
    boolean var13 = var11.isEmpty();
    java.util.Iterator var14 = var11.iterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var11.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var11.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var11.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var11.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var18);
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(0);
    java.util.Spliterator var24 = var23.spliterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var23.new RingBufferIterator();
    java.util.Spliterator var26 = var23.spliterator();
    var21.enqueue((java.lang.Object)var23);
    java.lang.Object var28 = var21.dequeue();
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var31 = var30.new RingBufferIterator();
    var21.enqueue((java.lang.Object)var31);
    int var33 = var21.size();
    int var34 = var21.size();
    int var35 = var21.size();
    java.util.Spliterator var36 = var21.spliterator();
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(1);
    java.util.Spliterator var39 = var38.spliterator();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(0);
    int var42 = var41.size();
    var38.enqueue((java.lang.Object)var42);
    java.lang.Object var44 = var38.dequeue();
    java.util.Spliterator var45 = var38.spliterator();
    exercise01.RingBuffer.RingBufferIterator var46 = var38.new RingBufferIterator();
    java.util.Iterator var47 = var38.iterator();
    int var48 = var38.size();
    var21.enqueue((java.lang.Object)var38);
    java.util.Spliterator var50 = var21.spliterator();
    var1.enqueue((java.lang.Object)var50);
    java.util.Spliterator var52 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var53 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var54 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var44 + "' != '" + 0+ "'", var44.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test55() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test55");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var14 = var6.spliterator();
    java.lang.Object var15 = var6.dequeue();
    java.util.Iterator var16 = var6.iterator();
    java.util.Iterator var17 = var6.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test56() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test56");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    java.util.Iterator var7 = var1.iterator();
    boolean var8 = var1.isEmpty();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    java.util.Iterator var11 = var10.iterator();
    int var12 = var10.size();
    int var13 = var10.size();
    java.util.Spliterator var14 = var10.spliterator();
    java.util.Spliterator var15 = var10.spliterator();
    int var16 = var10.size();
    java.util.Spliterator var17 = var10.spliterator();
    var1.enqueue((java.lang.Object)var10);
    int var19 = var1.size();
    java.util.Iterator var20 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var1.new RingBufferIterator();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(100);
    java.util.Iterator var24 = var23.iterator();
    java.util.Spliterator var25 = var23.spliterator();
    int var26 = var23.size();
    java.util.Iterator var27 = var23.iterator();
    exercise01.RingBuffer.RingBufferIterator var28 = var23.new RingBufferIterator();
    int var29 = var23.size();
    int var30 = var23.size();
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var33 = var32.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var32.new RingBufferIterator();
    int var35 = var32.size();
    java.util.Iterator var36 = var32.iterator();
    java.util.Spliterator var37 = var32.spliterator();
    java.util.Spliterator var38 = var32.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var32.new RingBufferIterator();
    java.util.Iterator var40 = var32.iterator();
    var23.enqueue((java.lang.Object)var32);
    java.util.Spliterator var42 = var32.spliterator();
    var1.enqueue((java.lang.Object)var32);
    java.util.Iterator var44 = var1.iterator();
    java.lang.Object var45 = var1.dequeue();
    boolean var46 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);

  }

  public void test57() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test57");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    int var2 = var1.size();
    int var3 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(100);
    java.util.Spliterator var9 = var8.spliterator();
    boolean var10 = var8.isEmpty();
    int var11 = var8.size();
    java.util.Iterator var12 = var8.iterator();
    java.util.Spliterator var13 = var8.spliterator();
    var1.enqueue((java.lang.Object)var13);
    java.util.Iterator var15 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var1.new RingBufferIterator();
    java.lang.Object var17 = var16.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var18 = var16.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test58() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test58");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    java.util.Iterator var9 = var1.iterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    int var14 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    java.util.Spliterator var17 = var12.spliterator();
    var1.enqueue((java.lang.Object)var12);
    java.util.Spliterator var19 = var12.spliterator();
    boolean var20 = var12.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var21 = var12.new RingBufferIterator();
    java.util.Iterator var22 = var12.iterator();
    java.util.Iterator var23 = var12.iterator();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(10);
    int var26 = var25.size();
    java.util.Spliterator var27 = var25.spliterator();
    exercise01.RingBuffer.RingBufferIterator var28 = var25.new RingBufferIterator();
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    java.util.Spliterator var33 = var32.spliterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var32.new RingBufferIterator();
    java.util.Spliterator var35 = var32.spliterator();
    var30.enqueue((java.lang.Object)var32);
    var25.enqueue((java.lang.Object)var30);
    java.util.Spliterator var38 = var30.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var30.new RingBufferIterator();
    int var40 = var30.size();
    exercise01.RingBuffer.RingBufferIterator var41 = var30.new RingBufferIterator();
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(0);
    java.util.Iterator var44 = var43.iterator();
    int var45 = var43.size();
    int var46 = var43.size();
    java.util.Spliterator var47 = var43.spliterator();
    java.util.Spliterator var48 = var43.spliterator();
    int var49 = var43.size();
    java.util.Iterator var50 = var43.iterator();
    boolean var51 = var43.isEmpty();
    java.util.Iterator var52 = var43.iterator();
    var30.enqueue((java.lang.Object)var52);
    java.util.Spliterator var54 = var30.spliterator();
    java.util.Spliterator var55 = var30.spliterator();
    java.lang.Object var56 = var30.dequeue();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(10);
    int var59 = var58.size();
    java.util.Spliterator var60 = var58.spliterator();
    exercise01.RingBuffer.RingBufferIterator var61 = var58.new RingBufferIterator();
    int var62 = var58.size();
    var58.enqueue((java.lang.Object)10);
    int var65 = var58.size();
    boolean var66 = var58.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var67 = var58.new RingBufferIterator();
    var30.enqueue((java.lang.Object)var58);
    java.util.Iterator var69 = var30.iterator();
    exercise01.RingBuffer var71 = new exercise01.RingBuffer(10);
    int var72 = var71.size();
    boolean var73 = var71.isEmpty();
    java.util.Iterator var74 = var71.iterator();
    exercise01.RingBuffer.RingBufferIterator var75 = var71.new RingBufferIterator();
    java.util.Spliterator var76 = var71.spliterator();
    exercise01.RingBuffer var78 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer.RingBufferIterator var79 = var78.new RingBufferIterator();
    java.util.Iterator var80 = var78.iterator();
    var71.enqueue((java.lang.Object)var78);
    exercise01.RingBuffer.RingBufferIterator var82 = var71.new RingBufferIterator();
    boolean var83 = var82.hasNext();
    boolean var84 = var82.hasNext();
    boolean var85 = var82.hasNext();
    var30.enqueue((java.lang.Object)var82);
    var12.enqueue((java.lang.Object)var82);
    java.lang.Object var88 = var82.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);

  }

  public void test59() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test59");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    boolean var3 = var1.isEmpty();
    boolean var4 = var1.isEmpty();
    java.util.Iterator var5 = var1.iterator();
    java.util.Iterator var6 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    boolean var8 = var7.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);

  }

  public void test60() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test60");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    boolean var2 = var1.isEmpty();
    boolean var3 = var1.isEmpty();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(10);
    int var6 = var5.size();
    boolean var7 = var5.isEmpty();
    java.util.Iterator var8 = var5.iterator();
    java.util.Spliterator var9 = var5.spliterator();
    java.util.Iterator var10 = var5.iterator();
    java.util.Iterator var11 = var5.iterator();
    java.util.Spliterator var12 = var5.spliterator();
    var1.enqueue((java.lang.Object)var5);
    int var14 = var1.size();
    java.util.Iterator var15 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var1.new RingBufferIterator();
    java.util.Spliterator var17 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test61() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test61");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    java.util.Spliterator var9 = var1.spliterator();
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(100);
    java.util.Iterator var12 = var11.iterator();
    java.util.Spliterator var13 = var11.spliterator();
    int var14 = var11.size();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(0);
    java.util.Spliterator var17 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var16.new RingBufferIterator();
    java.util.Spliterator var19 = var16.spliterator();
    int var20 = var16.size();
    int var21 = var16.size();
    boolean var22 = var16.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var23 = var16.new RingBufferIterator();
    var11.enqueue((java.lang.Object)var23);
    var1.enqueue((java.lang.Object)var11);
    int var26 = var1.size();
    java.util.Spliterator var27 = var1.spliterator();
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer.RingBufferIterator var30 = var29.new RingBufferIterator();
    java.util.Iterator var31 = var29.iterator();
    int var32 = var29.size();
    boolean var33 = var29.isEmpty();
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(0);
    java.util.Iterator var36 = var35.iterator();
    int var37 = var35.size();
    int var38 = var35.size();
    java.util.Spliterator var39 = var35.spliterator();
    java.util.Iterator var40 = var35.iterator();
    int var41 = var35.size();
    int var42 = var35.size();
    java.util.Iterator var43 = var35.iterator();
    exercise01.RingBuffer.RingBufferIterator var44 = var35.new RingBufferIterator();
    java.util.Iterator var45 = var35.iterator();
    java.util.Iterator var46 = var35.iterator();
    var29.enqueue((java.lang.Object)var46);
    boolean var48 = var29.isEmpty();
    java.util.Iterator var49 = var29.iterator();
    var1.enqueue((java.lang.Object)var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test62() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test62");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Spliterator var4 = var1.spliterator();
    int var5 = var1.size();
    int var6 = var1.size();
    boolean var7 = var1.isEmpty();
    boolean var8 = var1.isEmpty();
    int var9 = var1.size();
    boolean var10 = var1.isEmpty();
    java.util.Spliterator var11 = var1.spliterator();
    int var12 = var1.size();
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    boolean var15 = var14.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var16 = var14.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);

  }

  public void test63() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test63");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    boolean var2 = var1.isEmpty();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    java.util.Spliterator var8 = var7.spliterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var7.new RingBufferIterator();
    java.util.Spliterator var10 = var7.spliterator();
    int var11 = var7.size();
    exercise01.RingBuffer.RingBufferIterator var12 = var7.new RingBufferIterator();
    java.util.Iterator var13 = var7.iterator();
    boolean var14 = var7.isEmpty();
    java.util.Spliterator var15 = var7.spliterator();
    java.util.Iterator var16 = var7.iterator();
    var1.enqueue((java.lang.Object)var7);
    java.lang.Object var18 = var1.dequeue();
    java.util.Spliterator var19 = var1.spliterator();
    boolean var20 = var1.isEmpty();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(1);
    boolean var23 = var22.isEmpty();
    int var24 = var22.size();
    exercise01.RingBuffer.RingBufferIterator var25 = var22.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var22.new RingBufferIterator();
    int var27 = var22.size();
    boolean var28 = var22.isEmpty();
    boolean var29 = var22.isEmpty();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(1);
    boolean var32 = var31.isEmpty();
    java.util.Spliterator var33 = var31.spliterator();
    var22.enqueue((java.lang.Object)var33);
    exercise01.RingBuffer.RingBufferIterator var35 = var22.new RingBufferIterator();
    java.lang.Object var36 = var22.dequeue();
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(100);
    java.util.Iterator var39 = var38.iterator();
    java.util.Spliterator var40 = var38.spliterator();
    exercise01.RingBuffer var42 = new exercise01.RingBuffer(100);
    java.util.Spliterator var43 = var42.spliterator();
    java.util.Spliterator var44 = var42.spliterator();
    exercise01.RingBuffer.RingBufferIterator var45 = var42.new RingBufferIterator();
    java.util.Iterator var46 = var42.iterator();
    var38.enqueue((java.lang.Object)var42);
    int var48 = var42.size();
    exercise01.RingBuffer.RingBufferIterator var49 = var42.new RingBufferIterator();
    var22.enqueue((java.lang.Object)var42);
    exercise01.RingBuffer var52 = new exercise01.RingBuffer(1);
    java.util.Spliterator var53 = var52.spliterator();
    exercise01.RingBuffer var55 = new exercise01.RingBuffer(0);
    int var56 = var55.size();
    var52.enqueue((java.lang.Object)var56);
    java.lang.Object var58 = var52.dequeue();
    java.util.Spliterator var59 = var52.spliterator();
    exercise01.RingBuffer.RingBufferIterator var60 = var52.new RingBufferIterator();
    java.util.Spliterator var61 = var52.spliterator();
    exercise01.RingBuffer.RingBufferIterator var62 = var52.new RingBufferIterator();
    exercise01.RingBuffer var64 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var66 = new exercise01.RingBuffer(0);
    java.util.Spliterator var67 = var66.spliterator();
    exercise01.RingBuffer.RingBufferIterator var68 = var66.new RingBufferIterator();
    java.util.Spliterator var69 = var66.spliterator();
    var64.enqueue((java.lang.Object)var66);
    java.lang.Object var71 = var64.dequeue();
    exercise01.RingBuffer.RingBufferIterator var72 = var64.new RingBufferIterator();
    int var73 = var64.size();
    var52.enqueue((java.lang.Object)var64);
    java.util.Spliterator var75 = var52.spliterator();
    int var76 = var52.size();
    exercise01.RingBuffer.RingBufferIterator var77 = var52.new RingBufferIterator();
    int var78 = var52.size();
    java.util.Spliterator var79 = var52.spliterator();
    var42.enqueue((java.lang.Object)var52);
    var1.enqueue((java.lang.Object)var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + 0+ "'", var58.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);

  }

  public void test64() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test64");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    int var9 = var8.size();
    java.util.Iterator var10 = var8.iterator();
    boolean var11 = var8.isEmpty();
    boolean var12 = var8.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var8.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var8);
    boolean var15 = var1.isEmpty();
    java.util.Iterator var16 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var1.new RingBufferIterator();
    boolean var18 = var17.hasNext();
    boolean var19 = var17.hasNext();
    boolean var20 = var17.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);

  }

  public void test65() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test65");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    boolean var2 = var1.isEmpty();
    int var3 = var1.size();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Spliterator var7 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test66() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test66");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    var1.enqueue((java.lang.Object)"hi!");
    java.lang.Object var11 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    boolean var13 = var1.isEmpty();
    java.util.Spliterator var14 = var1.spliterator();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(10);
    int var17 = var16.size();
    java.util.Spliterator var18 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var16.new RingBufferIterator();
    int var20 = var16.size();
    var16.enqueue((java.lang.Object)10);
    int var23 = var16.size();
    int var24 = var16.size();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(100);
    java.util.Spliterator var27 = var26.spliterator();
    java.util.Spliterator var28 = var26.spliterator();
    var16.enqueue((java.lang.Object)var28);
    boolean var30 = var16.isEmpty();
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(100);
    java.util.Iterator var33 = var32.iterator();
    java.util.Spliterator var34 = var32.spliterator();
    java.util.Spliterator var35 = var32.spliterator();
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(0);
    int var38 = var37.size();
    java.util.Iterator var39 = var37.iterator();
    var32.enqueue((java.lang.Object)var37);
    exercise01.RingBuffer.RingBufferIterator var41 = var37.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var42 = var37.new RingBufferIterator();
    java.util.Spliterator var43 = var37.spliterator();
    int var44 = var37.size();
    java.util.Iterator var45 = var37.iterator();
    java.util.Spliterator var46 = var37.spliterator();
    var16.enqueue((java.lang.Object)var46);
    int var48 = var16.size();
    java.lang.Object var49 = var16.dequeue();
    exercise01.RingBuffer.RingBufferIterator var50 = var16.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var50);
    java.util.Iterator var52 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var53 = var1.new RingBufferIterator();
    java.lang.Object var54 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "hi!"+ "'", var11.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + 10+ "'", var49.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test67() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test67");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    int var3 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    java.util.Spliterator var5 = var1.spliterator();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    java.util.Iterator var8 = var7.iterator();
    int var9 = var7.size();
    int var10 = var7.size();
    int var11 = var7.size();
    int var12 = var7.size();
    exercise01.RingBuffer.RingBufferIterator var13 = var7.new RingBufferIterator();
    java.util.Spliterator var14 = var7.spliterator();
    var1.enqueue((java.lang.Object)var14);
    java.lang.Object var16 = var1.dequeue();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(0);
    java.util.Spliterator var21 = var20.spliterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var20.new RingBufferIterator();
    java.util.Spliterator var23 = var20.spliterator();
    int var24 = var20.size();
    exercise01.RingBuffer.RingBufferIterator var25 = var20.new RingBufferIterator();
    java.util.Iterator var26 = var20.iterator();
    var18.enqueue((java.lang.Object)var26);
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(10);
    int var30 = var29.size();
    boolean var31 = var29.isEmpty();
    java.util.Iterator var32 = var29.iterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var29.new RingBufferIterator();
    java.util.Spliterator var34 = var29.spliterator();
    var18.enqueue((java.lang.Object)var34);
    boolean var36 = var18.isEmpty();
    java.util.Spliterator var37 = var18.spliterator();
    var1.enqueue((java.lang.Object)var18);
    java.lang.Object var39 = var18.dequeue();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(10);
    int var42 = var41.size();
    java.util.Spliterator var43 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var44 = var41.new RingBufferIterator();
    exercise01.RingBuffer var46 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var48 = new exercise01.RingBuffer(0);
    java.util.Spliterator var49 = var48.spliterator();
    exercise01.RingBuffer.RingBufferIterator var50 = var48.new RingBufferIterator();
    java.util.Spliterator var51 = var48.spliterator();
    var46.enqueue((java.lang.Object)var48);
    var41.enqueue((java.lang.Object)var46);
    exercise01.RingBuffer.RingBufferIterator var54 = var46.new RingBufferIterator();
    int var55 = var46.size();
    exercise01.RingBuffer.RingBufferIterator var56 = var46.new RingBufferIterator();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(0);
    int var59 = var58.size();
    java.util.Spliterator var60 = var58.spliterator();
    int var61 = var58.size();
    java.util.Spliterator var62 = var58.spliterator();
    java.util.Iterator var63 = var58.iterator();
    boolean var64 = var58.isEmpty();
    java.util.Spliterator var65 = var58.spliterator();
    boolean var66 = var58.isEmpty();
    var46.enqueue((java.lang.Object)var66);
    exercise01.RingBuffer var69 = new exercise01.RingBuffer(100);
    java.util.Iterator var70 = var69.iterator();
    java.util.Spliterator var71 = var69.spliterator();
    int var72 = var69.size();
    java.util.Iterator var73 = var69.iterator();
    java.util.Spliterator var74 = var69.spliterator();
    exercise01.RingBuffer.RingBufferIterator var75 = var69.new RingBufferIterator();
    boolean var76 = var69.isEmpty();
    exercise01.RingBuffer var78 = new exercise01.RingBuffer(100);
    java.util.Iterator var79 = var78.iterator();
    java.util.Spliterator var80 = var78.spliterator();
    int var81 = var78.size();
    java.util.Iterator var82 = var78.iterator();
    java.util.Spliterator var83 = var78.spliterator();
    exercise01.RingBuffer.RingBufferIterator var84 = var78.new RingBufferIterator();
    boolean var85 = var78.isEmpty();
    var69.enqueue((java.lang.Object)var85);
    exercise01.RingBuffer.RingBufferIterator var87 = var69.new RingBufferIterator();
    var46.enqueue((java.lang.Object)var69);
    java.lang.Object var89 = var46.dequeue();
    var18.enqueue(var89);
    exercise01.RingBuffer.RingBufferIterator var91 = var18.new RingBufferIterator();
    int var92 = var18.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 2);

  }

  public void test68() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test68");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    int var7 = var3.size();
    exercise01.RingBuffer.RingBufferIterator var8 = var3.new RingBufferIterator();
    java.util.Iterator var9 = var3.iterator();
    var1.enqueue((java.lang.Object)var9);
    boolean var11 = var1.isEmpty();
    java.util.Iterator var12 = var1.iterator();
    boolean var13 = var1.isEmpty();
    java.util.Iterator var14 = var1.iterator();
    boolean var15 = var1.isEmpty();
    int var16 = var1.size();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    java.util.Spliterator var19 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var18.new RingBufferIterator();
    java.util.Spliterator var21 = var18.spliterator();
    java.util.Iterator var22 = var18.iterator();
    java.util.Spliterator var23 = var18.spliterator();
    var1.enqueue((java.lang.Object)var18);
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(10);
    int var27 = var26.size();
    boolean var28 = var26.isEmpty();
    java.util.Iterator var29 = var26.iterator();
    boolean var30 = var26.isEmpty();
    boolean var31 = var26.isEmpty();
    java.util.Iterator var32 = var26.iterator();
    boolean var33 = var26.isEmpty();
    boolean var34 = var26.isEmpty();
    exercise01.RingBuffer var36 = new exercise01.RingBuffer(0);
    java.util.Spliterator var37 = var36.spliterator();
    java.util.Spliterator var38 = var36.spliterator();
    java.util.Spliterator var39 = var36.spliterator();
    java.util.Spliterator var40 = var36.spliterator();
    java.util.Iterator var41 = var36.iterator();
    exercise01.RingBuffer.RingBufferIterator var42 = var36.new RingBufferIterator();
    java.util.Spliterator var43 = var36.spliterator();
    var26.enqueue((java.lang.Object)var43);
    exercise01.RingBuffer.RingBufferIterator var45 = var26.new RingBufferIterator();
    java.lang.Object var46 = var26.dequeue();
    exercise01.RingBuffer var48 = new exercise01.RingBuffer(0);
    java.util.Iterator var49 = var48.iterator();
    int var50 = var48.size();
    int var51 = var48.size();
    java.util.Spliterator var52 = var48.spliterator();
    java.util.Spliterator var53 = var48.spliterator();
    int var54 = var48.size();
    java.util.Iterator var55 = var48.iterator();
    boolean var56 = var48.isEmpty();
    java.util.Iterator var57 = var48.iterator();
    exercise01.RingBuffer.RingBufferIterator var58 = var48.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var59 = var48.new RingBufferIterator();
    var26.enqueue((java.lang.Object)var59);
    exercise01.RingBuffer var62 = new exercise01.RingBuffer(0);
    java.util.Iterator var63 = var62.iterator();
    int var64 = var62.size();
    exercise01.RingBuffer.RingBufferIterator var65 = var62.new RingBufferIterator();
    int var66 = var62.size();
    exercise01.RingBuffer.RingBufferIterator var67 = var62.new RingBufferIterator();
    boolean var68 = var62.isEmpty();
    var26.enqueue((java.lang.Object)var62);
    var1.enqueue((java.lang.Object)var62);
    exercise01.RingBuffer.RingBufferIterator var71 = var62.new RingBufferIterator();
    boolean var72 = var62.isEmpty();
    java.util.Spliterator var73 = var62.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test69() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test69");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    java.util.Iterator var7 = var1.iterator();
    boolean var8 = var1.isEmpty();
    boolean var9 = var1.isEmpty();
    boolean var10 = var1.isEmpty();
    java.util.Iterator var11 = var1.iterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(10);
    int var14 = var13.size();
    boolean var15 = var13.isEmpty();
    java.util.Iterator var16 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var13.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var13.new RingBufferIterator();
    var13.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var21 = var13.new RingBufferIterator();
    java.lang.Object var22 = var13.dequeue();
    boolean var23 = var13.isEmpty();
    boolean var24 = var13.isEmpty();
    int var25 = var13.size();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(100);
    java.util.Iterator var28 = var27.iterator();
    java.util.Spliterator var29 = var27.spliterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(0);
    java.util.Spliterator var32 = var31.spliterator();
    int var33 = var31.size();
    java.util.Spliterator var34 = var31.spliterator();
    java.util.Iterator var35 = var31.iterator();
    var27.enqueue((java.lang.Object)var31);
    exercise01.RingBuffer.RingBufferIterator var37 = var31.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var38 = var31.new RingBufferIterator();
    java.util.Iterator var39 = var31.iterator();
    var13.enqueue((java.lang.Object)var39);
    var1.enqueue((java.lang.Object)var13);
    java.util.Spliterator var42 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var1.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var43.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var22 + "' != '" + (-1.0f)+ "'", var22.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test70() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test70");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    int var3 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(10);
    int var8 = var7.size();
    boolean var9 = var7.isEmpty();
    java.util.Iterator var10 = var7.iterator();
    java.util.Spliterator var11 = var7.spliterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(1);
    boolean var14 = var13.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    java.util.Spliterator var16 = var13.spliterator();
    var7.enqueue((java.lang.Object)var13);
    var1.enqueue((java.lang.Object)var7);
    java.util.Iterator var19 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var1.new RingBufferIterator();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(1);
    java.util.Spliterator var24 = var23.spliterator();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(0);
    int var27 = var26.size();
    var23.enqueue((java.lang.Object)var27);
    java.lang.Object var29 = var23.dequeue();
    java.util.Spliterator var30 = var23.spliterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var23.new RingBufferIterator();
    java.util.Iterator var32 = var23.iterator();
    boolean var33 = var23.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var34 = var23.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var23.new RingBufferIterator();
    int var36 = var23.size();
    java.util.Spliterator var37 = var23.spliterator();
    int var38 = var23.size();
    java.util.Iterator var39 = var23.iterator();
    java.util.Spliterator var40 = var23.spliterator();
    var1.enqueue((java.lang.Object)var23);
    int var42 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 0+ "'", var29.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 2);

  }

  public void test71() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test71");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    int var8 = var1.size();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(100);
    java.util.Iterator var11 = var10.iterator();
    java.util.Spliterator var12 = var10.spliterator();
    java.util.Spliterator var13 = var10.spliterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(0);
    int var16 = var15.size();
    java.util.Iterator var17 = var15.iterator();
    var10.enqueue((java.lang.Object)var15);
    boolean var19 = var10.isEmpty();
    int var20 = var10.size();
    boolean var21 = var10.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var22 = var10.new RingBufferIterator();
    java.lang.Object var23 = var22.next();
    var1.enqueue(var23);
    exercise01.RingBuffer.RingBufferIterator var25 = var1.new RingBufferIterator();
    int var26 = var1.size();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(10);
    int var29 = var28.size();
    boolean var30 = var28.isEmpty();
    java.util.Iterator var31 = var28.iterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var28.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var28.new RingBufferIterator();
    java.util.Iterator var34 = var28.iterator();
    int var35 = var28.size();
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(0);
    java.util.Spliterator var38 = var37.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var37.new RingBufferIterator();
    java.util.Spliterator var40 = var37.spliterator();
    exercise01.RingBuffer.RingBufferIterator var41 = var37.new RingBufferIterator();
    boolean var42 = var41.hasNext();
    var28.enqueue((java.lang.Object)var41);
    exercise01.RingBuffer var45 = new exercise01.RingBuffer(0);
    java.util.Spliterator var46 = var45.spliterator();
    java.util.Spliterator var47 = var45.spliterator();
    java.util.Spliterator var48 = var45.spliterator();
    int var49 = var45.size();
    boolean var50 = var45.isEmpty();
    int var51 = var45.size();
    exercise01.RingBuffer.RingBufferIterator var52 = var45.new RingBufferIterator();
    var28.enqueue((java.lang.Object)var52);
    int var54 = var28.size();
    java.util.Iterator var55 = var28.iterator();
    exercise01.RingBuffer.RingBufferIterator var56 = var28.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var28);
    java.lang.Object var58 = var28.dequeue();
    java.util.Iterator var59 = var28.iterator();
    exercise01.RingBuffer.RingBufferIterator var60 = var28.new RingBufferIterator();
    boolean var61 = var28.isEmpty();
    int var62 = var28.size();
    java.util.Spliterator var63 = var28.spliterator();
    java.lang.Object var64 = var28.dequeue();
    boolean var65 = var28.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);

  }

  public void test72() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test72");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    boolean var8 = var1.isEmpty();
    int var9 = var1.size();
    boolean var10 = var1.isEmpty();
    java.util.Iterator var11 = var1.iterator();
    java.util.Spliterator var12 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test73() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test73");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    int var8 = var7.size();
    int var9 = var7.size();
    int var10 = var7.size();
    java.util.Iterator var11 = var7.iterator();
    var1.enqueue((java.lang.Object)var7);
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var1.new RingBufferIterator();
    int var16 = var1.size();
    java.util.Iterator var17 = var1.iterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    java.util.Spliterator var22 = var21.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var21.new RingBufferIterator();
    java.util.Spliterator var24 = var21.spliterator();
    var19.enqueue((java.lang.Object)var21);
    java.lang.Object var26 = var19.dequeue();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var29 = var28.new RingBufferIterator();
    var19.enqueue((java.lang.Object)var29);
    int var31 = var19.size();
    var1.enqueue((java.lang.Object)var19);
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(0);
    java.util.Spliterator var35 = var34.spliterator();
    java.util.Spliterator var36 = var34.spliterator();
    java.util.Spliterator var37 = var34.spliterator();
    java.util.Spliterator var38 = var34.spliterator();
    int var39 = var34.size();
    int var40 = var34.size();
    java.util.Iterator var41 = var34.iterator();
    java.util.Spliterator var42 = var34.spliterator();
    boolean var43 = var34.isEmpty();
    var19.enqueue((java.lang.Object)var34);
    boolean var45 = var19.isEmpty();
    int var46 = var19.size();
    boolean var47 = var19.isEmpty();
    java.util.Iterator var48 = var19.iterator();
    boolean var49 = var19.isEmpty();
    java.util.Iterator var50 = var19.iterator();
    java.lang.Object var51 = var19.dequeue();
    java.lang.Object var52 = var19.dequeue();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var53 = var19.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);

  }

  public void test74() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test74");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(0);
    int var10 = var9.size();
    java.util.Iterator var11 = var9.iterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var9.new RingBufferIterator();
    boolean var13 = var9.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var14 = var9.new RingBufferIterator();
    boolean var15 = var14.hasNext();
    var1.enqueue((java.lang.Object)var15);
    int var17 = var1.size();
    java.util.Spliterator var18 = var1.spliterator();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(100);
    java.util.Spliterator var21 = var20.spliterator();
    boolean var22 = var20.isEmpty();
    int var23 = var20.size();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(0);
    java.util.Spliterator var26 = var25.spliterator();
    int var27 = var25.size();
    var20.enqueue((java.lang.Object)var27);
    int var29 = var20.size();
    java.util.Iterator var30 = var20.iterator();
    var1.enqueue((java.lang.Object)var20);
    boolean var32 = var1.isEmpty();
    boolean var33 = var1.isEmpty();
    java.util.Iterator var34 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test75() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test75");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    boolean var9 = var1.isEmpty();
    int var10 = var1.size();
    java.util.Spliterator var11 = var1.spliterator();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    int var15 = var1.size();
    java.util.Spliterator var16 = var1.spliterator();
    int var17 = var1.size();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(10);
    int var20 = var19.size();
    java.util.Spliterator var21 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var19.new RingBufferIterator();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(0);
    java.util.Spliterator var27 = var26.spliterator();
    exercise01.RingBuffer.RingBufferIterator var28 = var26.new RingBufferIterator();
    java.util.Spliterator var29 = var26.spliterator();
    var24.enqueue((java.lang.Object)var26);
    var19.enqueue((java.lang.Object)var24);
    java.util.Spliterator var32 = var24.spliterator();
    int var33 = var24.size();
    java.util.Iterator var34 = var24.iterator();
    java.util.Spliterator var35 = var24.spliterator();
    java.util.Spliterator var36 = var24.spliterator();
    java.util.Iterator var37 = var24.iterator();
    exercise01.RingBuffer var39 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer.RingBufferIterator var40 = var39.new RingBufferIterator();
    java.util.Iterator var41 = var39.iterator();
    int var42 = var39.size();
    boolean var43 = var39.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var44 = var39.new RingBufferIterator();
    var24.enqueue((java.lang.Object)var44);
    java.util.Spliterator var46 = var24.spliterator();
    boolean var47 = var24.isEmpty();
    java.util.Iterator var48 = var24.iterator();
    var1.enqueue((java.lang.Object)var48);
    java.util.Iterator var50 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);

  }

  public void test76() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test76");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    int var2 = var1.size();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    java.util.Spliterator var5 = var4.spliterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var4.new RingBufferIterator();
    java.util.Iterator var7 = var4.iterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var4.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var4.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var4);
    java.util.Spliterator var11 = var1.spliterator();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    java.util.Iterator var14 = var1.iterator();
    boolean var15 = var1.isEmpty();
    java.util.Spliterator var16 = var1.spliterator();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(10);
    int var19 = var18.size();
    boolean var20 = var18.isEmpty();
    java.util.Iterator var21 = var18.iterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var18.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var18.new RingBufferIterator();
    java.util.Iterator var24 = var18.iterator();
    int var25 = var18.size();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    java.util.Spliterator var28 = var27.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var27.new RingBufferIterator();
    java.util.Spliterator var30 = var27.spliterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var27.new RingBufferIterator();
    boolean var32 = var31.hasNext();
    var18.enqueue((java.lang.Object)var31);
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(0);
    java.util.Spliterator var36 = var35.spliterator();
    java.util.Spliterator var37 = var35.spliterator();
    java.util.Spliterator var38 = var35.spliterator();
    int var39 = var35.size();
    boolean var40 = var35.isEmpty();
    int var41 = var35.size();
    exercise01.RingBuffer.RingBufferIterator var42 = var35.new RingBufferIterator();
    var18.enqueue((java.lang.Object)var42);
    int var44 = var18.size();
    java.util.Iterator var45 = var18.iterator();
    exercise01.RingBuffer.RingBufferIterator var46 = var18.new RingBufferIterator();
    exercise01.RingBuffer var48 = new exercise01.RingBuffer(10);
    int var49 = var48.size();
    java.util.Spliterator var50 = var48.spliterator();
    exercise01.RingBuffer.RingBufferIterator var51 = var48.new RingBufferIterator();
    exercise01.RingBuffer var53 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var55 = new exercise01.RingBuffer(0);
    java.util.Spliterator var56 = var55.spliterator();
    exercise01.RingBuffer.RingBufferIterator var57 = var55.new RingBufferIterator();
    java.util.Spliterator var58 = var55.spliterator();
    var53.enqueue((java.lang.Object)var55);
    var48.enqueue((java.lang.Object)var53);
    java.util.Iterator var61 = var48.iterator();
    exercise01.RingBuffer var63 = new exercise01.RingBuffer(0);
    java.util.Iterator var64 = var63.iterator();
    exercise01.RingBuffer.RingBufferIterator var65 = var63.new RingBufferIterator();
    int var66 = var63.size();
    exercise01.RingBuffer.RingBufferIterator var67 = var63.new RingBufferIterator();
    java.util.Spliterator var68 = var63.spliterator();
    var48.enqueue((java.lang.Object)var63);
    java.util.Iterator var70 = var63.iterator();
    var18.enqueue((java.lang.Object)var70);
    int var72 = var18.size();
    java.lang.Object var73 = var18.dequeue();
    exercise01.RingBuffer.RingBufferIterator var74 = var18.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var75 = var18.new RingBufferIterator();
    java.lang.Object var76 = var18.dequeue();
    var1.enqueue((java.lang.Object)var18);
    int var78 = var18.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 1);

  }

  public void test77() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test77");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    boolean var6 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    int var8 = var1.size();
    int var9 = var1.size();
    int var10 = var1.size();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(1);
    boolean var13 = var12.isEmpty();
    int var14 = var12.size();
    boolean var15 = var12.isEmpty();
    int var16 = var12.size();
    java.util.Iterator var17 = var12.iterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(10);
    int var20 = var19.size();
    boolean var21 = var19.isEmpty();
    java.util.Iterator var22 = var19.iterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var19.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var19.new RingBufferIterator();
    int var25 = var19.size();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(0);
    java.util.Spliterator var30 = var29.spliterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var29.new RingBufferIterator();
    java.util.Spliterator var32 = var29.spliterator();
    var27.enqueue((java.lang.Object)var29);
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(100);
    java.util.Spliterator var36 = var35.spliterator();
    var27.enqueue((java.lang.Object)var36);
    java.util.Iterator var38 = var27.iterator();
    var19.enqueue((java.lang.Object)var27);
    boolean var40 = var27.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var41 = var27.new RingBufferIterator();
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(0);
    java.util.Iterator var44 = var43.iterator();
    int var45 = var43.size();
    int var46 = var43.size();
    java.util.Spliterator var47 = var43.spliterator();
    java.util.Iterator var48 = var43.iterator();
    int var49 = var43.size();
    int var50 = var43.size();
    java.util.Iterator var51 = var43.iterator();
    java.util.Iterator var52 = var43.iterator();
    java.util.Iterator var53 = var43.iterator();
    var27.enqueue((java.lang.Object)var53);
    java.lang.Object var55 = var27.dequeue();
    java.util.Iterator var56 = var27.iterator();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(10);
    int var59 = var58.size();
    boolean var60 = var58.isEmpty();
    java.util.Iterator var61 = var58.iterator();
    exercise01.RingBuffer.RingBufferIterator var62 = var58.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var63 = var58.new RingBufferIterator();
    int var64 = var58.size();
    exercise01.RingBuffer var66 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var68 = new exercise01.RingBuffer(0);
    java.util.Spliterator var69 = var68.spliterator();
    exercise01.RingBuffer.RingBufferIterator var70 = var68.new RingBufferIterator();
    java.util.Spliterator var71 = var68.spliterator();
    var66.enqueue((java.lang.Object)var68);
    exercise01.RingBuffer var74 = new exercise01.RingBuffer(100);
    java.util.Spliterator var75 = var74.spliterator();
    var66.enqueue((java.lang.Object)var75);
    java.util.Iterator var77 = var66.iterator();
    var58.enqueue((java.lang.Object)var66);
    java.util.Iterator var79 = var66.iterator();
    boolean var80 = var66.isEmpty();
    java.util.Iterator var81 = var66.iterator();
    int var82 = var66.size();
    java.lang.Object var83 = var66.dequeue();
    var27.enqueue((java.lang.Object)var66);
    var12.enqueue((java.lang.Object)var27);
    boolean var86 = var12.isEmpty();
    var1.enqueue((java.lang.Object)var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test78() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test78");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    boolean var12 = var1.isEmpty();
    boolean var13 = var1.isEmpty();
    int var14 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var1.new RingBufferIterator();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Iterator var18 = var17.iterator();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(10);
    int var21 = var20.size();
    boolean var22 = var20.isEmpty();
    java.util.Iterator var23 = var20.iterator();
    java.util.Spliterator var24 = var20.spliterator();
    var17.enqueue((java.lang.Object)var24);
    int var26 = var17.size();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(10);
    int var29 = var28.size();
    java.util.Spliterator var30 = var28.spliterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var28.new RingBufferIterator();
    int var32 = var28.size();
    var28.enqueue((java.lang.Object)10);
    java.util.Iterator var35 = var28.iterator();
    java.util.Spliterator var36 = var28.spliterator();
    boolean var37 = var28.isEmpty();
    java.util.Spliterator var38 = var28.spliterator();
    int var39 = var28.size();
    var17.enqueue((java.lang.Object)var28);
    exercise01.RingBuffer.RingBufferIterator var41 = var28.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var28);
    exercise01.RingBuffer.RingBufferIterator var43 = var1.new RingBufferIterator();
    java.lang.Object var44 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var45 = var1.new RingBufferIterator();
    int var46 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);

  }

  public void test79() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test79");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(10);
    int var10 = var9.size();
    java.util.Spliterator var11 = var9.spliterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var9.new RingBufferIterator();
    int var13 = var9.size();
    var9.enqueue((java.lang.Object)10);
    java.util.Iterator var16 = var9.iterator();
    int var17 = var9.size();
    exercise01.RingBuffer.RingBufferIterator var18 = var9.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var18);
    int var20 = var1.size();
    java.util.Iterator var21 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var1.new RingBufferIterator();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(10);
    int var25 = var24.size();
    java.util.Spliterator var26 = var24.spliterator();
    exercise01.RingBuffer.RingBufferIterator var27 = var24.new RingBufferIterator();
    int var28 = var24.size();
    var24.enqueue((java.lang.Object)10);
    java.lang.Object var31 = var24.dequeue();
    var24.enqueue((java.lang.Object)"hi!");
    exercise01.RingBuffer.RingBufferIterator var34 = var24.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var24);
    java.lang.Object var36 = var1.dequeue();
    java.util.Spliterator var37 = var1.spliterator();
    java.util.Spliterator var38 = var1.spliterator();
    java.util.Iterator var39 = var1.iterator();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(100);
    java.util.Iterator var42 = var41.iterator();
    java.util.Spliterator var43 = var41.spliterator();
    java.util.Spliterator var44 = var41.spliterator();
    exercise01.RingBuffer var46 = new exercise01.RingBuffer(0);
    int var47 = var46.size();
    java.util.Iterator var48 = var46.iterator();
    var41.enqueue((java.lang.Object)var46);
    boolean var50 = var41.isEmpty();
    int var51 = var41.size();
    java.util.Iterator var52 = var41.iterator();
    exercise01.RingBuffer.RingBufferIterator var53 = var41.new RingBufferIterator();
    java.lang.Object var54 = var53.next();
    var1.enqueue((java.lang.Object)var53);
    boolean var56 = var53.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var31 + "' != '" + 10+ "'", var31.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == false);

  }

  public void test80() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test80");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var8 = var1.dequeue();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var11 = var10.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var11);
    int var13 = var1.size();
    int var14 = var1.size();
    int var15 = var1.size();
    java.util.Spliterator var16 = var1.spliterator();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(1);
    java.util.Spliterator var19 = var18.spliterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    int var22 = var21.size();
    var18.enqueue((java.lang.Object)var22);
    java.lang.Object var24 = var18.dequeue();
    java.util.Spliterator var25 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var18.new RingBufferIterator();
    java.util.Iterator var27 = var18.iterator();
    int var28 = var18.size();
    var1.enqueue((java.lang.Object)var18);
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(10);
    int var32 = var31.size();
    java.util.Spliterator var33 = var31.spliterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var31.new RingBufferIterator();
    exercise01.RingBuffer var36 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(0);
    java.util.Spliterator var39 = var38.spliterator();
    exercise01.RingBuffer.RingBufferIterator var40 = var38.new RingBufferIterator();
    java.util.Spliterator var41 = var38.spliterator();
    var36.enqueue((java.lang.Object)var38);
    var31.enqueue((java.lang.Object)var36);
    java.util.Spliterator var44 = var36.spliterator();
    java.util.Iterator var45 = var36.iterator();
    boolean var46 = var36.isEmpty();
    boolean var47 = var36.isEmpty();
    var1.enqueue((java.lang.Object)var36);
    int var49 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var50 = var1.new RingBufferIterator();
    java.lang.Object var51 = var50.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var24 + "' != '" + 0+ "'", var24.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var51);

  }

  public void test81() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test81");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    java.util.Spliterator var6 = var1.spliterator();
    java.util.Iterator var7 = var1.iterator();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    java.util.Iterator var10 = var9.iterator();
    java.util.Spliterator var11 = var9.spliterator();
    int var12 = var9.size();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    int var15 = var14.size();
    int var16 = var14.size();
    int var17 = var14.size();
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    boolean var19 = var18.hasNext();
    var9.enqueue((java.lang.Object)var18);
    java.util.Spliterator var21 = var9.spliterator();
    java.lang.Object var22 = var9.dequeue();
    int var23 = var9.size();
    var1.enqueue((java.lang.Object)var9);
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(10);
    int var27 = var26.size();
    boolean var28 = var26.isEmpty();
    java.util.Iterator var29 = var26.iterator();
    boolean var30 = var26.isEmpty();
    boolean var31 = var26.isEmpty();
    java.util.Iterator var32 = var26.iterator();
    boolean var33 = var26.isEmpty();
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(0);
    java.util.Iterator var36 = var35.iterator();
    int var37 = var35.size();
    int var38 = var35.size();
    java.util.Spliterator var39 = var35.spliterator();
    java.util.Spliterator var40 = var35.spliterator();
    int var41 = var35.size();
    java.util.Spliterator var42 = var35.spliterator();
    var26.enqueue((java.lang.Object)var35);
    int var44 = var26.size();
    java.util.Iterator var45 = var26.iterator();
    int var46 = var26.size();
    var1.enqueue((java.lang.Object)var26);
    int var48 = var1.size();
    boolean var49 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);

  }

  public void test82() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test82");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    java.util.Spliterator var3 = var1.spliterator();
    boolean var4 = var1.isEmpty();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Spliterator var6 = var1.spliterator();
    java.util.Spliterator var7 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    java.util.Iterator var9 = var1.iterator();
    java.util.Iterator var10 = var1.iterator();
    boolean var11 = var1.isEmpty();
    java.util.Spliterator var12 = var1.spliterator();
    boolean var13 = var1.isEmpty();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(10);
    int var16 = var15.size();
    boolean var17 = var15.isEmpty();
    java.util.Iterator var18 = var15.iterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var15.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var15.new RingBufferIterator();
    int var21 = var15.size();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(0);
    java.util.Spliterator var26 = var25.spliterator();
    exercise01.RingBuffer.RingBufferIterator var27 = var25.new RingBufferIterator();
    java.util.Spliterator var28 = var25.spliterator();
    var23.enqueue((java.lang.Object)var25);
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(100);
    java.util.Spliterator var32 = var31.spliterator();
    var23.enqueue((java.lang.Object)var32);
    java.util.Iterator var34 = var23.iterator();
    var15.enqueue((java.lang.Object)var23);
    java.util.Spliterator var36 = var23.spliterator();
    java.util.Spliterator var37 = var23.spliterator();
    int var38 = var23.size();
    exercise01.RingBuffer.RingBufferIterator var39 = var23.new RingBufferIterator();
    int var40 = var23.size();
    boolean var41 = var23.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.enqueue((java.lang.Object)var41);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test83() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test83");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    boolean var5 = var1.isEmpty();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    java.util.Spliterator var8 = var7.spliterator();
    java.util.Spliterator var9 = var7.spliterator();
    java.util.Spliterator var10 = var7.spliterator();
    java.util.Spliterator var11 = var7.spliterator();
    int var12 = var7.size();
    var1.enqueue((java.lang.Object)var12);
    java.lang.Object var14 = var1.dequeue();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(0);
    java.util.Spliterator var17 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var16.new RingBufferIterator();
    java.util.Iterator var19 = var16.iterator();
    int var20 = var16.size();
    int var21 = var16.size();
    java.util.Spliterator var22 = var16.spliterator();
    var1.enqueue((java.lang.Object)var16);
    exercise01.RingBuffer.RingBufferIterator var24 = var16.new RingBufferIterator();
    boolean var25 = var16.isEmpty();
    boolean var26 = var16.isEmpty();
    boolean var27 = var16.isEmpty();
    java.util.Spliterator var28 = var16.spliterator();
    int var29 = var16.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var14 + "' != '" + 0+ "'", var14.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);

  }

  public void test84() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test84");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    java.util.Spliterator var3 = var1.spliterator();
    java.util.Spliterator var4 = var1.spliterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(10);
    int var7 = var6.size();
    java.util.Spliterator var8 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var6.new RingBufferIterator();
    int var10 = var6.size();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(0);
    java.util.Iterator var13 = var12.iterator();
    int var14 = var12.size();
    int var15 = var12.size();
    java.util.Spliterator var16 = var12.spliterator();
    java.util.Spliterator var17 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var12.new RingBufferIterator();
    java.util.Spliterator var19 = var12.spliterator();
    var6.enqueue((java.lang.Object)var19);
    java.util.Iterator var21 = var6.iterator();
    int var22 = var6.size();
    exercise01.RingBuffer.RingBufferIterator var23 = var6.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var6.new RingBufferIterator();
    java.util.Spliterator var25 = var6.spliterator();
    boolean var26 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var27 = var6.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.enqueue((java.lang.Object)var27);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test85() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test85");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(10);
    int var10 = var9.size();
    boolean var11 = var9.isEmpty();
    java.util.Iterator var12 = var9.iterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var9.new RingBufferIterator();
    java.util.Spliterator var14 = var9.spliterator();
    int var15 = var9.size();
    var1.enqueue((java.lang.Object)var15);
    java.util.Spliterator var17 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var1.new RingBufferIterator();
    boolean var19 = var1.isEmpty();
    boolean var20 = var1.isEmpty();
    java.util.Iterator var21 = var1.iterator();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(0);
    java.util.Iterator var24 = var23.iterator();
    int var25 = var23.size();
    int var26 = var23.size();
    java.util.Spliterator var27 = var23.spliterator();
    java.util.Iterator var28 = var23.iterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var23.new RingBufferIterator();
    java.util.Spliterator var30 = var23.spliterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var23.new RingBufferIterator();
    java.util.Iterator var32 = var23.iterator();
    java.util.Iterator var33 = var23.iterator();
    int var34 = var23.size();
    int var35 = var23.size();
    var1.enqueue((java.lang.Object)var23);
    java.util.Iterator var37 = var23.iterator();
    int var38 = var23.size();
    int var39 = var23.size();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(0);
    java.util.Spliterator var42 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var41.new RingBufferIterator();
    java.util.Iterator var44 = var41.iterator();
    exercise01.RingBuffer.RingBufferIterator var45 = var41.new RingBufferIterator();
    java.util.Spliterator var46 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var41.new RingBufferIterator();
    java.util.Iterator var48 = var41.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var23.enqueue((java.lang.Object)var48);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test86() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test86");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    int var7 = var1.size();
    boolean var8 = var1.isEmpty();
    java.util.Iterator var9 = var1.iterator();
    boolean var10 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    java.util.Spliterator var12 = var1.spliterator();
    boolean var13 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);

  }

  public void test87() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test87");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Iterator var10 = var1.iterator();
    java.util.Iterator var11 = var1.iterator();
    java.util.Spliterator var12 = var1.spliterator();
    int var13 = var1.size();
    java.util.Spliterator var14 = var1.spliterator();
    java.lang.Object var15 = var1.dequeue();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    int var18 = var17.size();
    boolean var19 = var17.isEmpty();
    java.util.Iterator var20 = var17.iterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var17.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var17.new RingBufferIterator();
    var17.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var25 = var17.new RingBufferIterator();
    java.util.Spliterator var26 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var27 = var17.new RingBufferIterator();
    java.util.Spliterator var28 = var17.spliterator();
    var1.enqueue((java.lang.Object)var17);
    java.util.Iterator var30 = var1.iterator();
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    java.util.Iterator var33 = var32.iterator();
    boolean var34 = var32.isEmpty();
    java.util.Spliterator var35 = var32.spliterator();
    java.util.Iterator var36 = var32.iterator();
    int var37 = var32.size();
    exercise01.RingBuffer.RingBufferIterator var38 = var32.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var32.new RingBufferIterator();
    boolean var40 = var32.isEmpty();
    var1.enqueue((java.lang.Object)var32);
    int var42 = var32.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0f)+ "'", var15.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);

  }

  public void test88() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test88");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var3.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var9 = var1.dequeue();
    boolean var10 = var1.isEmpty();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    java.util.Spliterator var14 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    java.util.Iterator var19 = var18.iterator();
    int var20 = var18.size();
    int var21 = var18.size();
    java.util.Spliterator var22 = var18.spliterator();
    java.util.Spliterator var23 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var18.new RingBufferIterator();
    java.util.Spliterator var25 = var18.spliterator();
    var12.enqueue((java.lang.Object)var25);
    java.util.Iterator var27 = var12.iterator();
    int var28 = var12.size();
    boolean var29 = var12.isEmpty();
    java.util.Spliterator var30 = var12.spliterator();
    java.util.Iterator var31 = var12.iterator();
    java.lang.Object var32 = var12.dequeue();
    java.util.Iterator var33 = var12.iterator();
    var1.enqueue((java.lang.Object)var12);
    boolean var35 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var36 = var1.new RingBufferIterator();
    boolean var37 = var36.hasNext();
    java.lang.Object var38 = var36.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var39 = var36.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var38);

  }

  public void test89() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test89");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    java.util.Spliterator var8 = var1.spliterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    boolean var12 = var10.isEmpty();
    java.util.Iterator var13 = var10.iterator();
    java.util.Spliterator var14 = var10.spliterator();
    java.util.Iterator var15 = var10.iterator();
    boolean var16 = var10.isEmpty();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    int var19 = var18.size();
    java.util.Iterator var20 = var18.iterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var18.new RingBufferIterator();
    boolean var22 = var18.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var23 = var18.new RingBufferIterator();
    boolean var24 = var23.hasNext();
    var10.enqueue((java.lang.Object)var24);
    int var26 = var10.size();
    java.util.Spliterator var27 = var10.spliterator();
    int var28 = var10.size();
    int var29 = var10.size();
    exercise01.RingBuffer.RingBufferIterator var30 = var10.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var10);
    java.util.Iterator var32 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);

  }

  public void test90() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test90");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    boolean var2 = var1.isEmpty();
    int var3 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(10);
    int var7 = var6.size();
    boolean var8 = var6.isEmpty();
    java.util.Iterator var9 = var6.iterator();
    boolean var10 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var11 = var6.new RingBufferIterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(10);
    int var14 = var13.size();
    boolean var15 = var13.isEmpty();
    java.util.Iterator var16 = var13.iterator();
    java.util.Spliterator var17 = var13.spliterator();
    java.util.Iterator var18 = var13.iterator();
    boolean var19 = var13.isEmpty();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    int var22 = var21.size();
    java.util.Iterator var23 = var21.iterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var21.new RingBufferIterator();
    boolean var25 = var21.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var26 = var21.new RingBufferIterator();
    boolean var27 = var26.hasNext();
    var13.enqueue((java.lang.Object)var27);
    int var29 = var13.size();
    java.util.Spliterator var30 = var13.spliterator();
    var6.enqueue((java.lang.Object)var30);
    java.util.Iterator var32 = var6.iterator();
    boolean var33 = var6.isEmpty();
    java.util.Iterator var34 = var6.iterator();
    var1.enqueue((java.lang.Object)var6);
    exercise01.RingBuffer.RingBufferIterator var36 = var6.new RingBufferIterator();
    java.lang.Object var37 = var6.dequeue();
    int var38 = var6.size();
    java.util.Iterator var39 = var6.iterator();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(100);
    boolean var42 = var41.isEmpty();
    boolean var43 = var41.isEmpty();
    int var44 = var41.size();
    int var45 = var41.size();
    java.util.Spliterator var46 = var41.spliterator();
    java.util.Iterator var47 = var41.iterator();
    boolean var48 = var41.isEmpty();
    java.util.Iterator var49 = var41.iterator();
    var6.enqueue((java.lang.Object)var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);

  }

  public void test91() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test91");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    boolean var2 = var1.isEmpty();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    java.util.Iterator var7 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test92() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test92");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    boolean var12 = var10.isEmpty();
    java.util.Iterator var13 = var10.iterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var10.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var10.new RingBufferIterator();
    int var16 = var10.size();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(0);
    java.util.Spliterator var21 = var20.spliterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var20.new RingBufferIterator();
    java.util.Spliterator var23 = var20.spliterator();
    var18.enqueue((java.lang.Object)var20);
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(100);
    java.util.Spliterator var27 = var26.spliterator();
    var18.enqueue((java.lang.Object)var27);
    java.util.Iterator var29 = var18.iterator();
    var10.enqueue((java.lang.Object)var18);
    java.util.Iterator var31 = var18.iterator();
    java.util.Iterator var32 = var18.iterator();
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(10);
    int var35 = var34.size();
    boolean var36 = var34.isEmpty();
    java.util.Iterator var37 = var34.iterator();
    exercise01.RingBuffer.RingBufferIterator var38 = var34.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var34.new RingBufferIterator();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(0);
    int var42 = var41.size();
    java.util.Iterator var43 = var41.iterator();
    boolean var44 = var41.isEmpty();
    boolean var45 = var41.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var46 = var41.new RingBufferIterator();
    var34.enqueue((java.lang.Object)var41);
    exercise01.RingBuffer.RingBufferIterator var48 = var41.new RingBufferIterator();
    var18.enqueue((java.lang.Object)var41);
    java.util.Spliterator var50 = var41.spliterator();
    java.util.Iterator var51 = var41.iterator();
    java.util.Iterator var52 = var41.iterator();
    var1.enqueue((java.lang.Object)var41);
    java.util.Spliterator var54 = var1.spliterator();
    java.lang.Object var55 = var1.dequeue();
    java.util.Spliterator var56 = var1.spliterator();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(10);
    int var59 = var58.size();
    java.util.Spliterator var60 = var58.spliterator();
    exercise01.RingBuffer.RingBufferIterator var61 = var58.new RingBufferIterator();
    int var62 = var58.size();
    java.util.Spliterator var63 = var58.spliterator();
    exercise01.RingBuffer.RingBufferIterator var64 = var58.new RingBufferIterator();
    boolean var65 = var58.isEmpty();
    exercise01.RingBuffer var67 = new exercise01.RingBuffer(0);
    int var68 = var67.size();
    int var69 = var67.size();
    int var70 = var67.size();
    java.util.Iterator var71 = var67.iterator();
    java.util.Spliterator var72 = var67.spliterator();
    java.util.Spliterator var73 = var67.spliterator();
    var58.enqueue((java.lang.Object)var73);
    int var75 = var58.size();
    boolean var76 = var58.isEmpty();
    var1.enqueue((java.lang.Object)var76);
    java.util.Spliterator var78 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var79 = var1.new RingBufferIterator();
    boolean var80 = var79.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var55 + "' != '" + (-1.0f)+ "'", var55.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var75 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == true);

  }

  public void test93() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test93");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var14 = var6.spliterator();
    int var15 = var6.size();
    java.util.Iterator var16 = var6.iterator();
    int var17 = var6.size();
    boolean var18 = var6.isEmpty();
    boolean var19 = var6.isEmpty();
    java.lang.Object var20 = var6.dequeue();
    exercise01.RingBuffer.RingBufferIterator var21 = var6.new RingBufferIterator();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(100);
    boolean var24 = var23.isEmpty();
    boolean var25 = var23.isEmpty();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(10);
    int var28 = var27.size();
    boolean var29 = var27.isEmpty();
    java.util.Iterator var30 = var27.iterator();
    java.util.Spliterator var31 = var27.spliterator();
    java.util.Iterator var32 = var27.iterator();
    java.util.Iterator var33 = var27.iterator();
    java.util.Spliterator var34 = var27.spliterator();
    var23.enqueue((java.lang.Object)var27);
    exercise01.RingBuffer.RingBufferIterator var36 = var23.new RingBufferIterator();
    java.lang.Object var37 = var36.next();
    var6.enqueue(var37);
    java.util.Spliterator var39 = var6.spliterator();
    java.util.Spliterator var40 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var41 = var6.new RingBufferIterator();
    int var42 = var6.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 1);

  }

  public void test94() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test94");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    java.util.Spliterator var8 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Spliterator var10 = var1.spliterator();
    int var11 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    int var13 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);

  }

  public void test95() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test95");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    java.util.Spliterator var3 = var1.spliterator();
    boolean var4 = var1.isEmpty();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Spliterator var6 = var1.spliterator();
    java.util.Spliterator var7 = var1.spliterator();
    int var8 = var1.size();
    java.util.Iterator var9 = var1.iterator();
    int var10 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);

  }

  public void test96() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test96");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    boolean var5 = var1.isEmpty();
    int var6 = var1.size();
    boolean var7 = var1.isEmpty();
    java.util.Iterator var8 = var1.iterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    java.util.Iterator var11 = var10.iterator();
    int var12 = var10.size();
    int var13 = var10.size();
    java.util.Spliterator var14 = var10.spliterator();
    java.util.Iterator var15 = var10.iterator();
    java.util.Spliterator var16 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var10.new RingBufferIterator();
    java.util.Spliterator var18 = var10.spliterator();
    var1.enqueue((java.lang.Object)var10);
    int var20 = var1.size();
    java.util.Iterator var21 = var1.iterator();
    java.lang.Object var22 = var1.dequeue();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var23 = var1.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test97() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test97");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var8 = var1.dequeue();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var11 = var10.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var11);
    int var13 = var1.size();
    java.util.Iterator var14 = var1.iterator();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(0);
    java.util.Spliterator var17 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var16.new RingBufferIterator();
    java.util.Spliterator var19 = var16.spliterator();
    int var20 = var16.size();
    int var21 = var16.size();
    boolean var22 = var16.isEmpty();
    boolean var23 = var16.isEmpty();
    boolean var24 = var16.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var25 = var16.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var25);
    java.util.Iterator var27 = var1.iterator();
    boolean var28 = var1.isEmpty();
    java.util.Iterator var29 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var30 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var1.new RingBufferIterator();
    java.lang.Object var32 = var31.next();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var31.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var32);

  }

  public void test98() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test98");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    boolean var9 = var1.isEmpty();
    int var10 = var1.size();
    java.util.Spliterator var11 = var1.spliterator();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    int var15 = var1.size();
    java.util.Spliterator var16 = var1.spliterator();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    java.util.Spliterator var19 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var18.new RingBufferIterator();
    java.util.Iterator var21 = var18.iterator();
    boolean var22 = var18.isEmpty();
    java.util.Iterator var23 = var18.iterator();
    int var24 = var18.size();
    java.util.Spliterator var25 = var18.spliterator();
    int var26 = var18.size();
    int var27 = var18.size();
    exercise01.RingBuffer.RingBufferIterator var28 = var18.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var28);
    java.util.Spliterator var30 = var1.spliterator();
    java.util.Spliterator var31 = var1.spliterator();
    java.util.Iterator var32 = var1.iterator();
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(100);
    java.util.Spliterator var35 = var34.spliterator();
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(10);
    int var38 = var37.size();
    boolean var39 = var37.isEmpty();
    java.util.Spliterator var40 = var37.spliterator();
    exercise01.RingBuffer var42 = new exercise01.RingBuffer(0);
    int var43 = var42.size();
    java.util.Iterator var44 = var42.iterator();
    boolean var45 = var42.isEmpty();
    boolean var46 = var42.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var47 = var42.new RingBufferIterator();
    int var48 = var42.size();
    var37.enqueue((java.lang.Object)var48);
    boolean var50 = var37.isEmpty();
    var34.enqueue((java.lang.Object)var50);
    java.lang.Object var52 = var34.dequeue();
    boolean var53 = var34.isEmpty();
    int var54 = var34.size();
    int var55 = var34.size();
    var1.enqueue((java.lang.Object)var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var52 + "' != '" + false+ "'", var52.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);

  }

  public void test99() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test99");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    int var5 = var4.size();
    var1.enqueue((java.lang.Object)var5);
    java.util.Iterator var7 = var1.iterator();
    boolean var8 = var1.isEmpty();
    java.util.Spliterator var9 = var1.spliterator();
    int var10 = var1.size();
    int var11 = var1.size();
    java.util.Iterator var12 = var1.iterator();
    int var13 = var1.size();
    java.util.Iterator var14 = var1.iterator();
    java.lang.Object var15 = var1.dequeue();
    java.util.Iterator var16 = var1.iterator();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(10);
    int var19 = var18.size();
    boolean var20 = var18.isEmpty();
    java.util.Iterator var21 = var18.iterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var18.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var18.new RingBufferIterator();
    var18.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(10);
    int var28 = var27.size();
    int var29 = var27.size();
    java.util.Spliterator var30 = var27.spliterator();
    var18.enqueue((java.lang.Object)var30);
    java.lang.Object var32 = var18.dequeue();
    exercise01.RingBuffer.RingBufferIterator var33 = var18.new RingBufferIterator();
    int var34 = var18.size();
    exercise01.RingBuffer.RingBufferIterator var35 = var18.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var18);
    java.util.Iterator var37 = var18.iterator();
    boolean var38 = var18.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 0+ "'", var15.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1.0f)+ "'", var32.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);

  }

  public void test100() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test100");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    java.util.Spliterator var5 = var1.spliterator();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(100);
    java.util.Iterator var8 = var7.iterator();
    java.util.Spliterator var9 = var7.spliterator();
    java.util.Spliterator var10 = var7.spliterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(0);
    int var13 = var12.size();
    java.util.Iterator var14 = var12.iterator();
    var7.enqueue((java.lang.Object)var12);
    boolean var16 = var7.isEmpty();
    java.lang.Object var17 = var7.dequeue();
    var1.enqueue((java.lang.Object)var7);
    java.util.Iterator var19 = var1.iterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(10);
    int var22 = var21.size();
    boolean var23 = var21.isEmpty();
    java.util.Iterator var24 = var21.iterator();
    java.util.Spliterator var25 = var21.spliterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    int var28 = var27.size();
    int var29 = var27.size();
    int var30 = var27.size();
    java.util.Iterator var31 = var27.iterator();
    var21.enqueue((java.lang.Object)var27);
    java.util.Spliterator var33 = var21.spliterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var21.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var21.new RingBufferIterator();
    java.lang.Object var36 = var35.next();
    var1.enqueue(var36);
    exercise01.RingBuffer.RingBufferIterator var38 = var1.new RingBufferIterator();
    boolean var39 = var1.isEmpty();
    java.lang.Object var40 = var1.dequeue();
    boolean var41 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);

  }

  public void test101() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test101");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Spliterator var4 = var1.spliterator();
    java.util.Spliterator var5 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    boolean var10 = var9.hasNext();
    boolean var11 = var9.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var12 = var9.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);

  }

  public void test102() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test102");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    int var3 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    boolean var5 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Spliterator var7 = var1.spliterator();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(2);
    exercise01.RingBuffer.RingBufferIterator var10 = var9.new RingBufferIterator();
    java.util.Iterator var11 = var9.iterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(10);
    int var14 = var13.size();
    boolean var15 = var13.isEmpty();
    java.util.Iterator var16 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var13.new RingBufferIterator();
    java.util.Spliterator var18 = var13.spliterator();
    int var19 = var13.size();
    java.util.Iterator var20 = var13.iterator();
    var9.enqueue((java.lang.Object)var20);
    exercise01.RingBuffer.RingBufferIterator var22 = var9.new RingBufferIterator();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(0);
    java.util.Spliterator var25 = var24.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var24.new RingBufferIterator();
    java.util.Spliterator var27 = var24.spliterator();
    java.util.Spliterator var28 = var24.spliterator();
    java.util.Iterator var29 = var24.iterator();
    var9.enqueue((java.lang.Object)var24);
    var1.enqueue((java.lang.Object)var24);
    exercise01.RingBuffer.RingBufferIterator var32 = var24.new RingBufferIterator();
    java.util.Iterator var33 = var24.iterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var24.new RingBufferIterator();
    java.util.Spliterator var35 = var24.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test103() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test103");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    int var9 = var8.size();
    java.util.Iterator var10 = var8.iterator();
    boolean var11 = var8.isEmpty();
    boolean var12 = var8.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var8.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var8);
    boolean var15 = var1.isEmpty();
    java.lang.Object var16 = var1.dequeue();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(10);
    int var19 = var18.size();
    java.util.Spliterator var20 = var18.spliterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var18.new RingBufferIterator();
    boolean var22 = var18.isEmpty();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(0);
    int var25 = var24.size();
    java.util.Iterator var26 = var24.iterator();
    boolean var27 = var24.isEmpty();
    boolean var28 = var24.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var29 = var24.new RingBufferIterator();
    int var30 = var24.size();
    java.util.Spliterator var31 = var24.spliterator();
    var18.enqueue((java.lang.Object)var24);
    java.util.Spliterator var33 = var24.spliterator();
    int var34 = var24.size();
    exercise01.RingBuffer.RingBufferIterator var35 = var24.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var24);
    exercise01.RingBuffer.RingBufferIterator var37 = var24.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);

  }

  public void test104() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test104");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    int var8 = var1.size();
    java.util.Spliterator var9 = var1.spliterator();
    boolean var10 = var1.isEmpty();
    java.lang.Object var11 = var1.dequeue();
    boolean var12 = var1.isEmpty();
    java.util.Iterator var13 = var1.iterator();
    boolean var14 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var15 = var1.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var15.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 10+ "'", var11.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);

  }

  public void test105() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test105");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    int var8 = var7.size();
    java.util.Iterator var9 = var7.iterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var7.new RingBufferIterator();
    boolean var11 = var10.hasNext();
    boolean var12 = var10.hasNext();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(0);
    java.util.Iterator var16 = var15.iterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var15.new RingBufferIterator();
    int var18 = var15.size();
    exercise01.RingBuffer.RingBufferIterator var19 = var15.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var19);
    java.lang.Object var21 = var1.dequeue();
    int var22 = var1.size();
    java.lang.Object var23 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + false+ "'", var21.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);

  }

  public void test106() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test106");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var6.new RingBufferIterator();
    java.util.Spliterator var9 = var6.spliterator();
    int var10 = var6.size();
    int var11 = var6.size();
    boolean var12 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var6.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var13);
    int var15 = var1.size();
    boolean var16 = var1.isEmpty();
    int var17 = var1.size();
    boolean var18 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var19 = var1.new RingBufferIterator();
    boolean var20 = var1.isEmpty();
    java.util.Iterator var21 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);

  }

  public void test107() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test107");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Iterator var22 = var9.iterator();
    boolean var23 = var9.isEmpty();
    java.lang.Object var24 = var9.dequeue();
    exercise01.RingBuffer.RingBufferIterator var25 = var9.new RingBufferIterator();
    boolean var26 = var9.isEmpty();
    java.lang.Object var27 = var9.dequeue();
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var30 = var29.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var29.new RingBufferIterator();
    boolean var32 = var31.hasNext();
    var9.enqueue((java.lang.Object)var32);
    java.util.Iterator var34 = var9.iterator();
    int var35 = var9.size();
    java.lang.Object var36 = var9.dequeue();
    java.util.Iterator var37 = var9.iterator();
    int var38 = var9.size();
    int var39 = var9.size();
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(1);
    java.util.Spliterator var42 = var41.spliterator();
    exercise01.RingBuffer var44 = new exercise01.RingBuffer(0);
    int var45 = var44.size();
    var41.enqueue((java.lang.Object)var45);
    java.lang.Object var47 = var41.dequeue();
    java.util.Spliterator var48 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var49 = var41.new RingBufferIterator();
    java.util.Spliterator var50 = var41.spliterator();
    exercise01.RingBuffer.RingBufferIterator var51 = var41.new RingBufferIterator();
    exercise01.RingBuffer var53 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var55 = new exercise01.RingBuffer(0);
    java.util.Spliterator var56 = var55.spliterator();
    exercise01.RingBuffer.RingBufferIterator var57 = var55.new RingBufferIterator();
    java.util.Spliterator var58 = var55.spliterator();
    var53.enqueue((java.lang.Object)var55);
    java.lang.Object var60 = var53.dequeue();
    exercise01.RingBuffer.RingBufferIterator var61 = var53.new RingBufferIterator();
    int var62 = var53.size();
    var41.enqueue((java.lang.Object)var53);
    java.util.Spliterator var64 = var41.spliterator();
    int var65 = var41.size();
    boolean var66 = var41.isEmpty();
    java.util.Iterator var67 = var41.iterator();
    java.util.Spliterator var68 = var41.spliterator();
    java.util.Spliterator var69 = var41.spliterator();
    var9.enqueue((java.lang.Object)var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + false+ "'", var36.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var47 + "' != '" + 0+ "'", var47.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);

  }

  public void test108() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test108");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(0);
    int var10 = var9.size();
    java.util.Iterator var11 = var9.iterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var9.new RingBufferIterator();
    boolean var13 = var9.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var14 = var9.new RingBufferIterator();
    boolean var15 = var14.hasNext();
    var1.enqueue((java.lang.Object)var15);
    int var17 = var1.size();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    java.util.Iterator var20 = var19.iterator();
    int var21 = var19.size();
    int var22 = var19.size();
    java.util.Spliterator var23 = var19.spliterator();
    java.util.Iterator var24 = var19.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var19.new RingBufferIterator();
    java.util.Spliterator var26 = var19.spliterator();
    java.util.Iterator var27 = var19.iterator();
    var1.enqueue((java.lang.Object)var27);
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(100);
    java.util.Iterator var31 = var30.iterator();
    java.util.Spliterator var32 = var30.spliterator();
    int var33 = var30.size();
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(0);
    java.util.Spliterator var36 = var35.spliterator();
    exercise01.RingBuffer.RingBufferIterator var37 = var35.new RingBufferIterator();
    java.util.Spliterator var38 = var35.spliterator();
    int var39 = var35.size();
    int var40 = var35.size();
    boolean var41 = var35.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var42 = var35.new RingBufferIterator();
    var30.enqueue((java.lang.Object)var42);
    var1.enqueue((java.lang.Object)var42);
    java.lang.Object var45 = var1.dequeue();
    java.util.Spliterator var46 = var1.spliterator();
    java.util.Iterator var47 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var48 = var1.new RingBufferIterator();
    java.util.Spliterator var49 = var1.spliterator();
    int var50 = var1.size();
    java.util.Spliterator var51 = var1.spliterator();
    exercise01.RingBuffer var53 = new exercise01.RingBuffer(10);
    int var54 = var53.size();
    java.util.Spliterator var55 = var53.spliterator();
    exercise01.RingBuffer.RingBufferIterator var56 = var53.new RingBufferIterator();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var60 = new exercise01.RingBuffer(0);
    java.util.Spliterator var61 = var60.spliterator();
    exercise01.RingBuffer.RingBufferIterator var62 = var60.new RingBufferIterator();
    java.util.Spliterator var63 = var60.spliterator();
    var58.enqueue((java.lang.Object)var60);
    var53.enqueue((java.lang.Object)var58);
    java.util.Spliterator var66 = var58.spliterator();
    exercise01.RingBuffer.RingBufferIterator var67 = var58.new RingBufferIterator();
    int var68 = var58.size();
    exercise01.RingBuffer.RingBufferIterator var69 = var58.new RingBufferIterator();
    exercise01.RingBuffer var71 = new exercise01.RingBuffer(0);
    java.util.Iterator var72 = var71.iterator();
    int var73 = var71.size();
    int var74 = var71.size();
    java.util.Spliterator var75 = var71.spliterator();
    java.util.Spliterator var76 = var71.spliterator();
    int var77 = var71.size();
    java.util.Iterator var78 = var71.iterator();
    boolean var79 = var71.isEmpty();
    java.util.Iterator var80 = var71.iterator();
    var58.enqueue((java.lang.Object)var80);
    java.util.Spliterator var82 = var58.spliterator();
    java.util.Spliterator var83 = var58.spliterator();
    java.lang.Object var84 = var58.dequeue();
    exercise01.RingBuffer var86 = new exercise01.RingBuffer(10);
    int var87 = var86.size();
    java.util.Spliterator var88 = var86.spliterator();
    exercise01.RingBuffer.RingBufferIterator var89 = var86.new RingBufferIterator();
    int var90 = var86.size();
    var86.enqueue((java.lang.Object)10);
    int var93 = var86.size();
    boolean var94 = var86.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var95 = var86.new RingBufferIterator();
    var58.enqueue((java.lang.Object)var86);
    java.util.Iterator var97 = var86.iterator();
    var1.enqueue((java.lang.Object)var97);
    exercise01.RingBuffer.RingBufferIterator var99 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var45 + "' != '" + false+ "'", var45.equals(false));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var79 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var93 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var97);

  }

  public void test109() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test109");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    boolean var2 = var1.isEmpty();
    java.util.Spliterator var3 = var1.spliterator();
    boolean var4 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    boolean var6 = var1.isEmpty();
    int var7 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);

  }

  public void test110() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test110");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    java.util.Spliterator var4 = var1.spliterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    int var7 = var6.size();
    java.util.Iterator var8 = var6.iterator();
    var1.enqueue((java.lang.Object)var6);
    boolean var10 = var1.isEmpty();
    int var11 = var1.size();
    boolean var12 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var1.new RingBufferIterator();
    int var14 = var1.size();
    boolean var15 = var1.isEmpty();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    java.util.Spliterator var20 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var19.new RingBufferIterator();
    java.util.Spliterator var22 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var19.new RingBufferIterator();
    var17.enqueue((java.lang.Object)var19);
    exercise01.RingBuffer.RingBufferIterator var25 = var19.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var19.new RingBufferIterator();
    boolean var27 = var19.isEmpty();
    java.util.Iterator var28 = var19.iterator();
    java.util.Iterator var29 = var19.iterator();
    var1.enqueue((java.lang.Object)var29);
    java.util.Iterator var31 = var1.iterator();
    java.lang.Object var32 = var1.dequeue();
    java.util.Spliterator var33 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test111() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test111");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    int var7 = var6.size();
    int var8 = var6.size();
    int var9 = var6.size();
    exercise01.RingBuffer.RingBufferIterator var10 = var6.new RingBufferIterator();
    boolean var11 = var10.hasNext();
    var1.enqueue((java.lang.Object)var10);
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    int var15 = var14.size();
    java.util.Spliterator var16 = var14.spliterator();
    int var17 = var14.size();
    java.util.Spliterator var18 = var14.spliterator();
    java.util.Iterator var19 = var14.iterator();
    boolean var20 = var14.isEmpty();
    int var21 = var14.size();
    exercise01.RingBuffer.RingBufferIterator var22 = var14.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var14.new RingBufferIterator();
    java.util.Iterator var24 = var14.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var14.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var25);
    boolean var27 = var25.hasNext();
    boolean var28 = var25.hasNext();
    boolean var29 = var25.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var30 = var25.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);

  }

  public void test112() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test112");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    java.util.Iterator var7 = var1.iterator();
    boolean var8 = var1.isEmpty();
    boolean var9 = var1.isEmpty();
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    boolean var12 = var11.isEmpty();
    int var13 = var11.size();
    var1.enqueue((java.lang.Object)var13);
    boolean var15 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var16 = var1.new RingBufferIterator();
    boolean var17 = var16.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);

  }

  public void test113() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test113");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    boolean var9 = var1.isEmpty();
    int var10 = var1.size();
    java.util.Spliterator var11 = var1.spliterator();
    boolean var12 = var1.isEmpty();
    int var13 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    boolean var15 = var1.isEmpty();
    java.util.Spliterator var16 = var1.spliterator();
    java.util.Iterator var17 = var1.iterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var20 = var19.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var19.new RingBufferIterator();
    int var22 = var19.size();
    java.util.Iterator var23 = var19.iterator();
    java.util.Spliterator var24 = var19.spliterator();
    java.util.Spliterator var25 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var19.new RingBufferIterator();
    java.util.Spliterator var27 = var19.spliterator();
    boolean var28 = var19.isEmpty();
    boolean var29 = var19.isEmpty();
    int var30 = var19.size();
    java.util.Spliterator var31 = var19.spliterator();
    var1.enqueue((java.lang.Object)var19);
    java.lang.Object var33 = var1.dequeue();
    java.util.Iterator var34 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);

  }

  public void test114() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test114");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    int var12 = var10.size();
    java.util.Spliterator var13 = var10.spliterator();
    var1.enqueue((java.lang.Object)var13);
    java.lang.Object var15 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var16 = var1.new RingBufferIterator();
    int var17 = var1.size();
    int var18 = var1.size();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(0);
    java.util.Iterator var21 = var20.iterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var20.new RingBufferIterator();
    int var23 = var20.size();
    java.util.Iterator var24 = var20.iterator();
    java.util.Spliterator var25 = var20.spliterator();
    boolean var26 = var20.isEmpty();
    java.util.Iterator var27 = var20.iterator();
    var1.enqueue((java.lang.Object)var20);
    int var29 = var1.size();
    int var30 = var1.size();
    java.util.Spliterator var31 = var1.spliterator();
    java.util.Iterator var32 = var1.iterator();
    int var33 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var34 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var1.new RingBufferIterator();
    boolean var36 = var1.isEmpty();
    boolean var37 = var1.isEmpty();
    exercise01.RingBuffer var39 = new exercise01.RingBuffer(0);
    java.util.Iterator var40 = var39.iterator();
    int var41 = var39.size();
    int var42 = var39.size();
    java.util.Spliterator var43 = var39.spliterator();
    int var44 = var39.size();
    boolean var45 = var39.isEmpty();
    java.util.Spliterator var46 = var39.spliterator();
    var1.enqueue((java.lang.Object)var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + (-1.0f)+ "'", var15.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);

  }

  public void test115() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test115");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    java.util.Iterator var3 = var1.iterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(10);
    int var6 = var5.size();
    boolean var7 = var5.isEmpty();
    java.util.Iterator var8 = var5.iterator();
    boolean var9 = var5.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var10 = var5.new RingBufferIterator();
    boolean var11 = var10.hasNext();
    var1.enqueue((java.lang.Object)var10);
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(0);
    java.util.Spliterator var17 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var16.new RingBufferIterator();
    java.util.Spliterator var19 = var16.spliterator();
    var14.enqueue((java.lang.Object)var16);
    java.lang.Object var21 = var14.dequeue();
    exercise01.RingBuffer var23 = new exercise01.RingBuffer(0);
    java.util.Iterator var24 = var23.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var23.new RingBufferIterator();
    int var26 = var23.size();
    int var27 = var23.size();
    exercise01.RingBuffer.RingBufferIterator var28 = var23.new RingBufferIterator();
    java.util.Iterator var29 = var23.iterator();
    var14.enqueue((java.lang.Object)var23);
    var1.enqueue((java.lang.Object)var23);
    java.util.Spliterator var32 = var1.spliterator();
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(0);
    java.util.Iterator var35 = var34.iterator();
    int var36 = var34.size();
    int var37 = var34.size();
    java.util.Spliterator var38 = var34.spliterator();
    java.util.Spliterator var39 = var34.spliterator();
    var1.enqueue((java.lang.Object)var34);
    java.util.Iterator var41 = var1.iterator();
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(10);
    int var44 = var43.size();
    boolean var45 = var43.isEmpty();
    java.util.Iterator var46 = var43.iterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var43.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var48 = var43.new RingBufferIterator();
    var43.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer var52 = new exercise01.RingBuffer(10);
    int var53 = var52.size();
    int var54 = var52.size();
    java.util.Spliterator var55 = var52.spliterator();
    var43.enqueue((java.lang.Object)var55);
    java.lang.Object var57 = var43.dequeue();
    exercise01.RingBuffer.RingBufferIterator var58 = var43.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var43);
    exercise01.RingBuffer var61 = new exercise01.RingBuffer(0);
    java.util.Spliterator var62 = var61.spliterator();
    exercise01.RingBuffer.RingBufferIterator var63 = var61.new RingBufferIterator();
    java.util.Iterator var64 = var61.iterator();
    int var65 = var61.size();
    int var66 = var61.size();
    java.util.Iterator var67 = var61.iterator();
    java.util.Iterator var68 = var61.iterator();
    int var69 = var61.size();
    boolean var70 = var61.isEmpty();
    boolean var71 = var61.isEmpty();
    java.util.Iterator var72 = var61.iterator();
    int var73 = var61.size();
    boolean var74 = var61.isEmpty();
    var43.enqueue((java.lang.Object)var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var57 + "' != '" + (-1.0f)+ "'", var57.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var64);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == true);

  }

  public void test116() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test116");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    int var3 = var1.size();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Spliterator var6 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    java.util.Iterator var8 = var1.iterator();
    java.util.Spliterator var9 = var1.spliterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    java.util.Spliterator var12 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test117() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test117");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    java.util.Spliterator var12 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var10.new RingBufferIterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(0);
    java.util.Spliterator var18 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var17.new RingBufferIterator();
    java.util.Spliterator var20 = var17.spliterator();
    var15.enqueue((java.lang.Object)var17);
    var10.enqueue((java.lang.Object)var15);
    var1.enqueue((java.lang.Object)var10);
    int var24 = var10.size();
    java.util.Iterator var25 = var10.iterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer.RingBufferIterator var28 = var27.new RingBufferIterator();
    java.util.Iterator var29 = var27.iterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(10);
    int var32 = var31.size();
    boolean var33 = var31.isEmpty();
    java.util.Iterator var34 = var31.iterator();
    boolean var35 = var31.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var36 = var31.new RingBufferIterator();
    boolean var37 = var36.hasNext();
    var27.enqueue((java.lang.Object)var36);
    int var39 = var27.size();
    java.lang.Object var40 = var27.dequeue();
    var10.enqueue(var40);
    java.util.Spliterator var42 = var10.spliterator();
    java.util.Spliterator var43 = var10.spliterator();
    java.lang.Object var44 = var10.dequeue();
    java.util.Iterator var45 = var10.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);

  }

  public void test118() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test118");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    boolean var6 = var1.isEmpty();
    int var7 = var1.size();
    java.util.Iterator var8 = var1.iterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    java.util.Spliterator var11 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var10.new RingBufferIterator();
    java.util.Spliterator var13 = var10.spliterator();
    java.util.Iterator var14 = var10.iterator();
    java.util.Spliterator var15 = var10.spliterator();
    int var16 = var10.size();
    java.util.Iterator var17 = var10.iterator();
    int var18 = var10.size();
    var1.enqueue((java.lang.Object)var18);
    java.lang.Object var20 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var20 + "' != '" + 0+ "'", var20.equals(0));

  }

  public void test119() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test119");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    java.util.Spliterator var11 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var10.new RingBufferIterator();
    java.util.Spliterator var13 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var10.new RingBufferIterator();
    boolean var15 = var14.hasNext();
    var1.enqueue((java.lang.Object)var14);
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    java.util.Spliterator var19 = var18.spliterator();
    java.util.Spliterator var20 = var18.spliterator();
    java.util.Spliterator var21 = var18.spliterator();
    int var22 = var18.size();
    boolean var23 = var18.isEmpty();
    int var24 = var18.size();
    exercise01.RingBuffer.RingBufferIterator var25 = var18.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var25);
    int var27 = var1.size();
    java.util.Iterator var28 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var1.new RingBufferIterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(10);
    int var32 = var31.size();
    java.util.Spliterator var33 = var31.spliterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var31.new RingBufferIterator();
    exercise01.RingBuffer var36 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(0);
    java.util.Spliterator var39 = var38.spliterator();
    exercise01.RingBuffer.RingBufferIterator var40 = var38.new RingBufferIterator();
    java.util.Spliterator var41 = var38.spliterator();
    var36.enqueue((java.lang.Object)var38);
    var31.enqueue((java.lang.Object)var36);
    java.util.Iterator var44 = var31.iterator();
    exercise01.RingBuffer var46 = new exercise01.RingBuffer(0);
    java.util.Iterator var47 = var46.iterator();
    exercise01.RingBuffer.RingBufferIterator var48 = var46.new RingBufferIterator();
    int var49 = var46.size();
    exercise01.RingBuffer.RingBufferIterator var50 = var46.new RingBufferIterator();
    java.util.Spliterator var51 = var46.spliterator();
    var31.enqueue((java.lang.Object)var46);
    java.util.Iterator var53 = var46.iterator();
    var1.enqueue((java.lang.Object)var53);
    exercise01.RingBuffer.RingBufferIterator var55 = var1.new RingBufferIterator();
    java.lang.Object var56 = var1.dequeue();
    boolean var57 = var1.isEmpty();
    boolean var58 = var1.isEmpty();
    int var59 = var1.size();
    exercise01.RingBuffer var61 = new exercise01.RingBuffer(10);
    int var62 = var61.size();
    java.util.Spliterator var63 = var61.spliterator();
    exercise01.RingBuffer.RingBufferIterator var64 = var61.new RingBufferIterator();
    int var65 = var61.size();
    java.util.Spliterator var66 = var61.spliterator();
    exercise01.RingBuffer.RingBufferIterator var67 = var61.new RingBufferIterator();
    boolean var68 = var61.isEmpty();
    exercise01.RingBuffer var70 = new exercise01.RingBuffer(0);
    int var71 = var70.size();
    int var72 = var70.size();
    int var73 = var70.size();
    java.util.Iterator var74 = var70.iterator();
    java.util.Spliterator var75 = var70.spliterator();
    java.util.Spliterator var76 = var70.spliterator();
    var61.enqueue((java.lang.Object)var76);
    int var78 = var61.size();
    java.util.Iterator var79 = var61.iterator();
    exercise01.RingBuffer.RingBufferIterator var80 = var61.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var81 = var61.new RingBufferIterator();
    int var82 = var61.size();
    int var83 = var61.size();
    exercise01.RingBuffer var85 = new exercise01.RingBuffer(1);
    java.util.Spliterator var86 = var85.spliterator();
    exercise01.RingBuffer var88 = new exercise01.RingBuffer(0);
    int var89 = var88.size();
    var85.enqueue((java.lang.Object)var89);
    java.util.Iterator var91 = var85.iterator();
    java.util.Spliterator var92 = var85.spliterator();
    java.lang.Object var93 = var85.dequeue();
    var61.enqueue((java.lang.Object)var85);
    exercise01.RingBuffer.RingBufferIterator var95 = var61.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var96 = var61.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var97 = var61.new RingBufferIterator();
    boolean var98 = var61.isEmpty();
    var1.enqueue((java.lang.Object)var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var93 + "' != '" + 0+ "'", var93.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == false);

  }

  public void test120() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test120");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(10);
    int var9 = var8.size();
    boolean var10 = var8.isEmpty();
    java.util.Iterator var11 = var8.iterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var8.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var8.new RingBufferIterator();
    java.util.Iterator var14 = var8.iterator();
    int var15 = var8.size();
    java.util.Iterator var16 = var8.iterator();
    var1.enqueue((java.lang.Object)var8);
    int var18 = var1.size();
    exercise01.RingBuffer var20 = new exercise01.RingBuffer(10);
    int var21 = var20.size();
    boolean var22 = var20.isEmpty();
    java.util.Iterator var23 = var20.iterator();
    boolean var24 = var20.isEmpty();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(1);
    boolean var27 = var26.isEmpty();
    var20.enqueue((java.lang.Object)var26);
    java.lang.Object var29 = var20.dequeue();
    var1.enqueue(var29);
    java.util.Iterator var31 = var1.iterator();
    java.util.Spliterator var32 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var33 = var1.new RingBufferIterator();
    java.lang.Object var34 = var33.next();
    boolean var35 = var33.hasNext();
    boolean var36 = var33.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var33.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);

  }

  public void test121() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test121");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    int var8 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Iterator var12 = var11.iterator();
    int var13 = var11.size();
    int var14 = var11.size();
    java.util.Spliterator var15 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var11.new RingBufferIterator();
    int var17 = var11.size();
    java.util.Spliterator var18 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var11.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var19);
    java.lang.Object var21 = var1.dequeue();
    java.util.Iterator var22 = var1.iterator();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(0);
    java.util.Spliterator var25 = var24.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var24.new RingBufferIterator();
    java.util.Spliterator var27 = var24.spliterator();
    int var28 = var24.size();
    int var29 = var24.size();
    boolean var30 = var24.isEmpty();
    java.util.Spliterator var31 = var24.spliterator();
    java.util.Spliterator var32 = var24.spliterator();
    boolean var33 = var24.isEmpty();
    var1.enqueue((java.lang.Object)var33);
    java.util.Iterator var35 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + (short)1+ "'", var21.equals((short)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);

  }

  public void test122() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test122");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var14 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var6.new RingBufferIterator();
    int var16 = var6.size();
    exercise01.RingBuffer.RingBufferIterator var17 = var6.new RingBufferIterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    java.util.Iterator var20 = var19.iterator();
    int var21 = var19.size();
    int var22 = var19.size();
    java.util.Spliterator var23 = var19.spliterator();
    java.util.Spliterator var24 = var19.spliterator();
    int var25 = var19.size();
    java.util.Iterator var26 = var19.iterator();
    boolean var27 = var19.isEmpty();
    java.util.Iterator var28 = var19.iterator();
    var6.enqueue((java.lang.Object)var28);
    int var30 = var6.size();
    exercise01.RingBuffer.RingBufferIterator var31 = var6.new RingBufferIterator();
    java.util.Spliterator var32 = var6.spliterator();
    java.util.Spliterator var33 = var6.spliterator();
    boolean var34 = var6.isEmpty();
    java.util.Spliterator var35 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var36 = var6.new RingBufferIterator();
    java.lang.Object var37 = var36.next();
    boolean var38 = var36.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var36.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);

  }

  public void test123() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test123");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    java.util.Iterator var22 = var9.iterator();
    java.lang.Object var23 = var9.dequeue();
    exercise01.RingBuffer.RingBufferIterator var24 = var9.new RingBufferIterator();
    java.lang.Object var25 = var9.dequeue();
    java.util.Iterator var26 = var9.iterator();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var29 = var28.new RingBufferIterator();
    int var30 = var28.size();
    var9.enqueue((java.lang.Object)var30);
    java.util.Iterator var32 = var9.iterator();
    boolean var33 = var9.isEmpty();
    java.util.Spliterator var34 = var9.spliterator();
    java.util.Spliterator var35 = var9.spliterator();
    boolean var36 = var9.isEmpty();
    java.util.Iterator var37 = var9.iterator();
    java.lang.Object var38 = var9.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + 0+ "'", var38.equals(0));

  }

  public void test124() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test124");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Spliterator var10 = var1.spliterator();
    boolean var11 = var1.isEmpty();
    boolean var12 = var1.isEmpty();
    java.util.Iterator var13 = var1.iterator();
    java.util.Iterator var14 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);

  }

  public void test125() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test125");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    int var8 = var1.size();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var11 = var10.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var10.new RingBufferIterator();
    int var13 = var10.size();
    java.util.Iterator var14 = var10.iterator();
    java.util.Spliterator var15 = var10.spliterator();
    java.util.Spliterator var16 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var10.new RingBufferIterator();
    java.util.Iterator var18 = var10.iterator();
    var1.enqueue((java.lang.Object)var10);
    java.lang.Object var20 = var1.dequeue();
    boolean var21 = var1.isEmpty();
    java.util.Iterator var22 = var1.iterator();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(10);
    int var25 = var24.size();
    boolean var26 = var24.isEmpty();
    java.util.Iterator var27 = var24.iterator();
    java.util.Spliterator var28 = var24.spliterator();
    var24.enqueue((java.lang.Object)(short)1);
    int var31 = var24.size();
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(100);
    java.util.Iterator var34 = var33.iterator();
    java.util.Spliterator var35 = var33.spliterator();
    java.util.Spliterator var36 = var33.spliterator();
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(0);
    int var39 = var38.size();
    java.util.Iterator var40 = var38.iterator();
    var33.enqueue((java.lang.Object)var38);
    boolean var42 = var33.isEmpty();
    int var43 = var33.size();
    boolean var44 = var33.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var45 = var33.new RingBufferIterator();
    java.lang.Object var46 = var45.next();
    var24.enqueue(var46);
    exercise01.RingBuffer.RingBufferIterator var48 = var24.new RingBufferIterator();
    int var49 = var24.size();
    exercise01.RingBuffer var51 = new exercise01.RingBuffer(10);
    int var52 = var51.size();
    boolean var53 = var51.isEmpty();
    java.util.Iterator var54 = var51.iterator();
    exercise01.RingBuffer.RingBufferIterator var55 = var51.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var56 = var51.new RingBufferIterator();
    java.util.Iterator var57 = var51.iterator();
    int var58 = var51.size();
    exercise01.RingBuffer var60 = new exercise01.RingBuffer(0);
    java.util.Spliterator var61 = var60.spliterator();
    exercise01.RingBuffer.RingBufferIterator var62 = var60.new RingBufferIterator();
    java.util.Spliterator var63 = var60.spliterator();
    exercise01.RingBuffer.RingBufferIterator var64 = var60.new RingBufferIterator();
    boolean var65 = var64.hasNext();
    var51.enqueue((java.lang.Object)var64);
    exercise01.RingBuffer var68 = new exercise01.RingBuffer(0);
    java.util.Spliterator var69 = var68.spliterator();
    java.util.Spliterator var70 = var68.spliterator();
    java.util.Spliterator var71 = var68.spliterator();
    int var72 = var68.size();
    boolean var73 = var68.isEmpty();
    int var74 = var68.size();
    exercise01.RingBuffer.RingBufferIterator var75 = var68.new RingBufferIterator();
    var51.enqueue((java.lang.Object)var75);
    int var77 = var51.size();
    java.util.Iterator var78 = var51.iterator();
    exercise01.RingBuffer.RingBufferIterator var79 = var51.new RingBufferIterator();
    var24.enqueue((java.lang.Object)var51);
    java.lang.Object var81 = var51.dequeue();
    java.util.Iterator var82 = var51.iterator();
    exercise01.RingBuffer.RingBufferIterator var83 = var51.new RingBufferIterator();
    java.util.Iterator var84 = var51.iterator();
    var1.enqueue((java.lang.Object)var84);
    boolean var86 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == false);

  }

  public void test126() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test126");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    boolean var9 = var1.isEmpty();
    boolean var10 = var1.isEmpty();
    int var11 = var1.size();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(10);
    int var16 = var15.size();
    java.util.Spliterator var17 = var15.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var15.new RingBufferIterator();
    boolean var19 = var15.isEmpty();
    java.util.Iterator var20 = var15.iterator();
    boolean var21 = var15.isEmpty();
    java.util.Iterator var22 = var15.iterator();
    boolean var23 = var15.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var24 = var15.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var15);
    java.util.Spliterator var26 = var15.spliterator();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(1);
    java.util.Spliterator var29 = var28.spliterator();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(0);
    int var32 = var31.size();
    var28.enqueue((java.lang.Object)var32);
    java.lang.Object var34 = var28.dequeue();
    java.util.Spliterator var35 = var28.spliterator();
    exercise01.RingBuffer.RingBufferIterator var36 = var28.new RingBufferIterator();
    java.util.Iterator var37 = var28.iterator();
    boolean var38 = var28.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var39 = var28.new RingBufferIterator();
    java.util.Spliterator var40 = var28.spliterator();
    boolean var41 = var28.isEmpty();
    var15.enqueue((java.lang.Object)var41);
    java.util.Spliterator var43 = var15.spliterator();
    int var44 = var15.size();
    boolean var45 = var15.isEmpty();
    int var46 = var15.size();
    exercise01.RingBuffer var48 = new exercise01.RingBuffer(100);
    java.util.Spliterator var49 = var48.spliterator();
    boolean var50 = var48.isEmpty();
    int var51 = var48.size();
    exercise01.RingBuffer var53 = new exercise01.RingBuffer(0);
    java.util.Spliterator var54 = var53.spliterator();
    int var55 = var53.size();
    var48.enqueue((java.lang.Object)var55);
    boolean var57 = var48.isEmpty();
    java.lang.Object var58 = var48.dequeue();
    exercise01.RingBuffer var60 = new exercise01.RingBuffer(0);
    java.util.Spliterator var61 = var60.spliterator();
    exercise01.RingBuffer.RingBufferIterator var62 = var60.new RingBufferIterator();
    java.util.Spliterator var63 = var60.spliterator();
    int var64 = var60.size();
    int var65 = var60.size();
    boolean var66 = var60.isEmpty();
    int var67 = var60.size();
    java.util.Spliterator var68 = var60.spliterator();
    java.util.Iterator var69 = var60.iterator();
    exercise01.RingBuffer.RingBufferIterator var70 = var60.new RingBufferIterator();
    var48.enqueue((java.lang.Object)var70);
    boolean var72 = var48.isEmpty();
    java.util.Iterator var73 = var48.iterator();
    exercise01.RingBuffer var75 = new exercise01.RingBuffer(0);
    int var76 = var75.size();
    int var77 = var75.size();
    int var78 = var75.size();
    java.util.Iterator var79 = var75.iterator();
    java.util.Spliterator var80 = var75.spliterator();
    java.util.Spliterator var81 = var75.spliterator();
    var48.enqueue((java.lang.Object)var75);
    var15.enqueue((java.lang.Object)var48);
    boolean var84 = var48.isEmpty();
    java.util.Iterator var85 = var48.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + 0+ "'", var34.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var58 + "' != '" + 0+ "'", var58.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);

  }

  public void test127() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test127");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(100);
    java.util.Iterator var5 = var4.iterator();
    java.util.Spliterator var6 = var4.spliterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    int var10 = var8.size();
    java.util.Spliterator var11 = var8.spliterator();
    java.util.Iterator var12 = var8.iterator();
    var4.enqueue((java.lang.Object)var8);
    java.lang.Object var14 = var4.dequeue();
    exercise01.RingBuffer.RingBufferIterator var15 = var4.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var15);
    boolean var17 = var15.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var18 = var15.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);

  }

  public void test128() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test128");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(10);
    int var9 = var8.size();
    boolean var10 = var8.isEmpty();
    java.util.Iterator var11 = var8.iterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var8.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var8.new RingBufferIterator();
    java.util.Iterator var14 = var8.iterator();
    int var15 = var8.size();
    java.util.Iterator var16 = var8.iterator();
    var1.enqueue((java.lang.Object)var8);
    boolean var18 = var8.isEmpty();
    int var19 = var8.size();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var22 = var21.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var21.new RingBufferIterator();
    boolean var24 = var21.isEmpty();
    var8.enqueue((java.lang.Object)var21);
    int var26 = var21.size();
    int var27 = var21.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);

  }

  public void test129() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test129");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    int var5 = var4.size();
    var1.enqueue((java.lang.Object)var5);
    java.lang.Object var7 = var1.dequeue();
    boolean var8 = var1.isEmpty();
    java.util.Spliterator var9 = var1.spliterator();
    java.util.Iterator var10 = var1.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var11 = var1.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);

  }

  public void test130() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test130");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    java.util.Spliterator var4 = var1.spliterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    int var7 = var6.size();
    java.util.Iterator var8 = var6.iterator();
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var10 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(10);
    int var14 = var13.size();
    java.util.Spliterator var15 = var13.spliterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var13.new RingBufferIterator();
    int var17 = var13.size();
    java.util.Spliterator var18 = var13.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var13.new RingBufferIterator();
    boolean var20 = var13.isEmpty();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(0);
    int var23 = var22.size();
    int var24 = var22.size();
    int var25 = var22.size();
    java.util.Iterator var26 = var22.iterator();
    java.util.Spliterator var27 = var22.spliterator();
    java.util.Spliterator var28 = var22.spliterator();
    var13.enqueue((java.lang.Object)var28);
    int var30 = var13.size();
    java.util.Iterator var31 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var13.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var13);
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(10);
    int var36 = var35.size();
    int var37 = var35.size();
    java.util.Spliterator var38 = var35.spliterator();
    java.util.Spliterator var39 = var35.spliterator();
    java.util.Spliterator var40 = var35.spliterator();
    java.util.Spliterator var41 = var35.spliterator();
    var13.enqueue((java.lang.Object)var41);
    int var43 = var13.size();
    int var44 = var13.size();
    boolean var45 = var13.isEmpty();
    boolean var46 = var13.isEmpty();
    java.util.Iterator var47 = var13.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test131() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test131");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(1);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer var4 = new exercise01.RingBuffer(0);
    int var5 = var4.size();
    var1.enqueue((java.lang.Object)var5);
    java.lang.Object var7 = var1.dequeue();
    java.util.Spliterator var8 = var1.spliterator();
    boolean var9 = var1.isEmpty();
    java.util.Iterator var10 = var1.iterator();
    java.util.Spliterator var11 = var1.spliterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(100);
    java.util.Iterator var14 = var13.iterator();
    java.util.Spliterator var15 = var13.spliterator();
    java.util.Spliterator var16 = var13.spliterator();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(0);
    int var19 = var18.size();
    java.util.Iterator var20 = var18.iterator();
    var13.enqueue((java.lang.Object)var18);
    boolean var22 = var13.isEmpty();
    java.util.Iterator var23 = var13.iterator();
    java.util.Spliterator var24 = var13.spliterator();
    var1.enqueue((java.lang.Object)var13);
    boolean var26 = var1.isEmpty();
    exercise01.RingBuffer var28 = new exercise01.RingBuffer(10);
    boolean var29 = var28.isEmpty();
    exercise01.RingBuffer var31 = new exercise01.RingBuffer(0);
    int var32 = var31.size();
    java.util.Iterator var33 = var31.iterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var31.new RingBufferIterator();
    boolean var35 = var34.hasNext();
    boolean var36 = var34.hasNext();
    var28.enqueue((java.lang.Object)var34);
    boolean var38 = var28.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var39 = var28.new RingBufferIterator();
    boolean var40 = var28.isEmpty();
    java.util.Spliterator var41 = var28.spliterator();
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(100);
    java.util.Spliterator var44 = var43.spliterator();
    boolean var45 = var43.isEmpty();
    int var46 = var43.size();
    exercise01.RingBuffer.RingBufferIterator var47 = var43.new RingBufferIterator();
    int var48 = var43.size();
    var28.enqueue((java.lang.Object)var48);
    exercise01.RingBuffer var51 = new exercise01.RingBuffer(10);
    int var52 = var51.size();
    boolean var53 = var51.isEmpty();
    java.util.Iterator var54 = var51.iterator();
    java.util.Spliterator var55 = var51.spliterator();
    exercise01.RingBuffer var57 = new exercise01.RingBuffer(0);
    int var58 = var57.size();
    int var59 = var57.size();
    int var60 = var57.size();
    java.util.Iterator var61 = var57.iterator();
    var51.enqueue((java.lang.Object)var57);
    java.util.Spliterator var63 = var51.spliterator();
    exercise01.RingBuffer.RingBufferIterator var64 = var51.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var65 = var51.new RingBufferIterator();
    int var66 = var51.size();
    java.util.Spliterator var67 = var51.spliterator();
    exercise01.RingBuffer.RingBufferIterator var68 = var51.new RingBufferIterator();
    exercise01.RingBuffer var70 = new exercise01.RingBuffer(0);
    java.util.Spliterator var71 = var70.spliterator();
    int var72 = var70.size();
    java.util.Spliterator var73 = var70.spliterator();
    exercise01.RingBuffer.RingBufferIterator var74 = var70.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var75 = var70.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var76 = var70.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var77 = var70.new RingBufferIterator();
    java.util.Spliterator var78 = var70.spliterator();
    exercise01.RingBuffer.RingBufferIterator var79 = var70.new RingBufferIterator();
    java.util.Iterator var80 = var70.iterator();
    var51.enqueue((java.lang.Object)var70);
    java.util.Spliterator var82 = var70.spliterator();
    var28.enqueue((java.lang.Object)var70);
    java.util.Iterator var84 = var28.iterator();
    exercise01.RingBuffer var86 = new exercise01.RingBuffer(0);
    java.util.Iterator var87 = var86.iterator();
    exercise01.RingBuffer.RingBufferIterator var88 = var86.new RingBufferIterator();
    java.util.Iterator var89 = var86.iterator();
    java.util.Iterator var90 = var86.iterator();
    var28.enqueue((java.lang.Object)var86);
    java.lang.Object var92 = var28.dequeue();
    java.util.Iterator var93 = var28.iterator();
    java.util.Iterator var94 = var28.iterator();
    exercise01.RingBuffer.RingBufferIterator var95 = var28.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.enqueue((java.lang.Object)var95);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 0+ "'", var7.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var84);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var89);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

  public void test132() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest103.test132");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    java.util.Spliterator var8 = var1.spliterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    java.util.Spliterator var12 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var10.new RingBufferIterator();
    int var14 = var10.size();
    var10.enqueue((java.lang.Object)10);
    java.util.Iterator var17 = var10.iterator();
    int var18 = var10.size();
    exercise01.RingBuffer.RingBufferIterator var19 = var10.new RingBufferIterator();
    boolean var20 = var19.hasNext();
    java.lang.Object var21 = var19.next();
    var1.enqueue(var21);
    boolean var23 = var1.isEmpty();
    java.util.Spliterator var24 = var1.spliterator();
    java.util.Spliterator var25 = var1.spliterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    java.util.Spliterator var28 = var27.spliterator();
    java.util.Spliterator var29 = var27.spliterator();
    java.util.Spliterator var30 = var27.spliterator();
    java.util.Iterator var31 = var27.iterator();
    boolean var32 = var27.isEmpty();
    int var33 = var27.size();
    boolean var34 = var27.isEmpty();
    java.util.Iterator var35 = var27.iterator();
    var1.enqueue((java.lang.Object)var35);
    boolean var37 = var1.isEmpty();
    java.lang.Object var38 = var1.dequeue();
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(0);
    int var41 = var40.size();
    java.util.Iterator var42 = var40.iterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var40.new RingBufferIterator();
    int var44 = var40.size();
    java.util.Spliterator var45 = var40.spliterator();
    exercise01.RingBuffer.RingBufferIterator var46 = var40.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var40.new RingBufferIterator();
    java.util.Spliterator var48 = var40.spliterator();
    java.util.Spliterator var49 = var40.spliterator();
    var1.enqueue((java.lang.Object)var49);
    exercise01.RingBuffer var52 = new exercise01.RingBuffer(10);
    int var53 = var52.size();
    boolean var54 = var52.isEmpty();
    java.util.Iterator var55 = var52.iterator();
    java.util.Spliterator var56 = var52.spliterator();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(1);
    boolean var59 = var58.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var60 = var58.new RingBufferIterator();
    java.util.Spliterator var61 = var58.spliterator();
    var52.enqueue((java.lang.Object)var58);
    java.util.Iterator var63 = var52.iterator();
    boolean var64 = var52.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var65 = var52.new RingBufferIterator();
    exercise01.RingBuffer var67 = new exercise01.RingBuffer(10);
    int var68 = var67.size();
    boolean var69 = var67.isEmpty();
    java.util.Iterator var70 = var67.iterator();
    java.util.Spliterator var71 = var67.spliterator();
    java.util.Iterator var72 = var67.iterator();
    java.util.Iterator var73 = var67.iterator();
    exercise01.RingBuffer var75 = new exercise01.RingBuffer(100);
    java.util.Iterator var76 = var75.iterator();
    java.util.Spliterator var77 = var75.spliterator();
    java.util.Spliterator var78 = var75.spliterator();
    exercise01.RingBuffer var80 = new exercise01.RingBuffer(0);
    int var81 = var80.size();
    java.util.Iterator var82 = var80.iterator();
    var75.enqueue((java.lang.Object)var80);
    exercise01.RingBuffer.RingBufferIterator var84 = var80.new RingBufferIterator();
    java.util.Spliterator var85 = var80.spliterator();
    var67.enqueue((java.lang.Object)var85);
    exercise01.RingBuffer.RingBufferIterator var87 = var67.new RingBufferIterator();
    boolean var88 = var67.isEmpty();
    var52.enqueue((java.lang.Object)var67);
    java.util.Spliterator var90 = var52.spliterator();
    exercise01.RingBuffer.RingBufferIterator var91 = var52.new RingBufferIterator();
    java.lang.Object var92 = var91.next();
    var1.enqueue((java.lang.Object)var91);
    java.util.Spliterator var94 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var21 + "' != '" + 10+ "'", var21.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var38 + "' != '" + 10+ "'", var38.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var81 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var85);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var94);

  }

}
