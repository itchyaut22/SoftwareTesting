package exercise01_700s;

import junit.framework.*;

public class RandoopTest64 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test1");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    java.util.Spliterator var12 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var10.new RingBufferIterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(0);
    java.util.Spliterator var18 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var17.new RingBufferIterator();
    java.util.Spliterator var20 = var17.spliterator();
    var15.enqueue((java.lang.Object)var17);
    var10.enqueue((java.lang.Object)var15);
    var1.enqueue((java.lang.Object)var10);
    java.lang.Object var24 = var10.dequeue();
    int var25 = var10.size();
    java.util.Spliterator var26 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var27 = var10.new RingBufferIterator();
    boolean var28 = var10.isEmpty();
    int var29 = var10.size();
    java.util.Spliterator var30 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var10.new RingBufferIterator();
    java.util.Iterator var32 = var10.iterator();
    java.util.Spliterator var33 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var34 = var10.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test2() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test2");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var3.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var9 = var1.dequeue();
    boolean var10 = var1.isEmpty();
    boolean var11 = var1.isEmpty();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(100);
    java.util.Iterator var14 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    java.util.Spliterator var20 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var19.new RingBufferIterator();
    java.util.Spliterator var22 = var19.spliterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var19.new RingBufferIterator();
    var17.enqueue((java.lang.Object)var19);
    java.lang.Object var25 = var17.dequeue();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    java.util.Spliterator var28 = var27.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var27.new RingBufferIterator();
    java.util.Iterator var30 = var27.iterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var27.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var27.new RingBufferIterator();
    var17.enqueue((java.lang.Object)var32);
    java.util.Spliterator var34 = var17.spliterator();
    var13.enqueue((java.lang.Object)var17);
    var1.enqueue((java.lang.Object)var13);
    java.util.Spliterator var37 = var13.spliterator();
    java.util.Iterator var38 = var13.iterator();
    java.util.Iterator var39 = var13.iterator();
    boolean var40 = var13.isEmpty();
    exercise01.RingBuffer var42 = new exercise01.RingBuffer(10);
    int var43 = var42.size();
    java.util.Spliterator var44 = var42.spliterator();
    exercise01.RingBuffer.RingBufferIterator var45 = var42.new RingBufferIterator();
    int var46 = var42.size();
    exercise01.RingBuffer var48 = new exercise01.RingBuffer(0);
    java.util.Iterator var49 = var48.iterator();
    int var50 = var48.size();
    int var51 = var48.size();
    java.util.Spliterator var52 = var48.spliterator();
    java.util.Spliterator var53 = var48.spliterator();
    exercise01.RingBuffer.RingBufferIterator var54 = var48.new RingBufferIterator();
    java.util.Spliterator var55 = var48.spliterator();
    var42.enqueue((java.lang.Object)var55);
    java.util.Iterator var57 = var42.iterator();
    int var58 = var42.size();
    boolean var59 = var42.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var60 = var42.new RingBufferIterator();
    java.util.Spliterator var61 = var42.spliterator();
    java.util.Spliterator var62 = var42.spliterator();
    var42.enqueue((java.lang.Object)'4');
    exercise01.RingBuffer.RingBufferIterator var65 = var42.new RingBufferIterator();
    int var66 = var42.size();
    var13.enqueue((java.lang.Object)var42);
    exercise01.RingBuffer.RingBufferIterator var68 = var42.new RingBufferIterator();
    int var69 = var42.size();
    java.util.Iterator var70 = var42.iterator();
    exercise01.RingBuffer var72 = new exercise01.RingBuffer(10);
    int var73 = var72.size();
    java.util.Spliterator var74 = var72.spliterator();
    exercise01.RingBuffer.RingBufferIterator var75 = var72.new RingBufferIterator();
    boolean var76 = var72.isEmpty();
    exercise01.RingBuffer var78 = new exercise01.RingBuffer(0);
    java.util.Spliterator var79 = var78.spliterator();
    java.util.Spliterator var80 = var78.spliterator();
    java.util.Spliterator var81 = var78.spliterator();
    java.util.Spliterator var82 = var78.spliterator();
    int var83 = var78.size();
    var72.enqueue((java.lang.Object)var83);
    java.lang.Object var85 = var72.dequeue();
    exercise01.RingBuffer var87 = new exercise01.RingBuffer(0);
    java.util.Spliterator var88 = var87.spliterator();
    exercise01.RingBuffer.RingBufferIterator var89 = var87.new RingBufferIterator();
    java.util.Iterator var90 = var87.iterator();
    int var91 = var87.size();
    int var92 = var87.size();
    java.util.Spliterator var93 = var87.spliterator();
    var72.enqueue((java.lang.Object)var87);
    java.lang.Object var95 = var72.dequeue();
    java.util.Spliterator var96 = var72.spliterator();
    var42.enqueue((java.lang.Object)var96);
    java.lang.Object var98 = var42.dequeue();
    java.util.Iterator var99 = var42.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var69 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var74);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var83 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var85 + "' != '" + 0+ "'", var85.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var90);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var91 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var98);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test3() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test3");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    boolean var5 = var1.isEmpty();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    boolean var8 = var1.isEmpty();
    java.util.Iterator var9 = var1.iterator();
    boolean var10 = var1.isEmpty();
    java.util.Spliterator var11 = var1.spliterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(10);
    int var14 = var13.size();
    boolean var15 = var13.isEmpty();
    java.util.Iterator var16 = var13.iterator();
    java.util.Spliterator var17 = var13.spliterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    int var20 = var19.size();
    int var21 = var19.size();
    int var22 = var19.size();
    java.util.Iterator var23 = var19.iterator();
    var13.enqueue((java.lang.Object)var19);
    boolean var25 = var13.isEmpty();
    java.util.Spliterator var26 = var13.spliterator();
    java.lang.Object var27 = var13.dequeue();
    var1.enqueue((java.lang.Object)var13);
    java.util.Iterator var29 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);

  }

  public void test4() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test4");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    int var8 = var1.size();
    int var9 = var1.size();
    boolean var10 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    int var13 = var1.size();
    int var14 = var1.size();
    java.lang.Object var15 = var1.dequeue();
    java.util.Iterator var16 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var15 + "' != '" + 10+ "'", var15.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test5() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test5");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    int var6 = var1.size();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    java.util.Spliterator var9 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    int var11 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);

  }

  public void test6() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test6");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    java.util.Spliterator var8 = var1.spliterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(100);
    java.util.Iterator var11 = var10.iterator();
    java.util.Spliterator var12 = var10.spliterator();
    java.util.Spliterator var13 = var10.spliterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(0);
    int var16 = var15.size();
    java.util.Iterator var17 = var15.iterator();
    var10.enqueue((java.lang.Object)var15);
    boolean var19 = var10.isEmpty();
    java.util.Spliterator var20 = var10.spliterator();
    var1.enqueue((java.lang.Object)var20);
    java.lang.Object var22 = var1.dequeue();
    java.util.Spliterator var23 = var1.spliterator();
    java.util.Iterator var24 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);

  }

  public void test7() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test7");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    var1.enqueue((java.lang.Object)(byte)1);
    boolean var6 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(0);
    java.util.Spliterator var10 = var9.spliterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var9.new RingBufferIterator();
    java.util.Iterator var12 = var9.iterator();
    boolean var13 = var9.isEmpty();
    java.util.Iterator var14 = var9.iterator();
    java.util.Iterator var15 = var9.iterator();
    var1.enqueue((java.lang.Object)var15);
    java.util.Spliterator var17 = var1.spliterator();
    java.lang.Object var18 = var1.dequeue();
    java.util.Iterator var19 = var1.iterator();
    java.lang.Object var20 = var1.dequeue();
    java.util.Iterator var21 = var1.iterator();
    java.util.Iterator var22 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var18 + "' != '" + (byte)1+ "'", var18.equals((byte)1));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test8() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test8");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(2);
    exercise01.RingBuffer.RingBufferIterator var2 = var1.new RingBufferIterator();
    java.util.Iterator var3 = var1.iterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(10);
    int var6 = var5.size();
    boolean var7 = var5.isEmpty();
    java.util.Iterator var8 = var5.iterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var5.new RingBufferIterator();
    java.util.Spliterator var10 = var5.spliterator();
    int var11 = var5.size();
    java.util.Iterator var12 = var5.iterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    java.util.Spliterator var15 = var1.spliterator();
    int var16 = var1.size();
    java.util.Spliterator var17 = var1.spliterator();
    boolean var18 = var1.isEmpty();
    java.util.Spliterator var19 = var1.spliterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(10);
    int var22 = var21.size();
    java.util.Spliterator var23 = var21.spliterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var21.new RingBufferIterator();
    java.util.Spliterator var25 = var21.spliterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(100);
    java.util.Iterator var28 = var27.iterator();
    java.util.Spliterator var29 = var27.spliterator();
    java.util.Spliterator var30 = var27.spliterator();
    exercise01.RingBuffer var32 = new exercise01.RingBuffer(0);
    int var33 = var32.size();
    java.util.Iterator var34 = var32.iterator();
    var27.enqueue((java.lang.Object)var32);
    boolean var36 = var27.isEmpty();
    java.lang.Object var37 = var27.dequeue();
    var21.enqueue((java.lang.Object)var27);
    var1.enqueue((java.lang.Object)var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);

  }

  public void test9() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test9");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    java.lang.Object var11 = var1.dequeue();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(0);
    java.util.Spliterator var14 = var13.spliterator();
    java.util.Spliterator var15 = var13.spliterator();
    java.util.Spliterator var16 = var13.spliterator();
    java.util.Iterator var17 = var13.iterator();
    boolean var18 = var13.isEmpty();
    int var19 = var13.size();
    boolean var20 = var13.isEmpty();
    java.util.Iterator var21 = var13.iterator();
    java.util.Iterator var22 = var13.iterator();
    var1.enqueue((java.lang.Object)var22);
    java.lang.Object var24 = var1.dequeue();
    java.util.Spliterator var25 = var1.spliterator();
    java.util.Iterator var26 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var27 = var1.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var27.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (-1.0f)+ "'", var11.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test10() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test10");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    int var3 = var1.size();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    java.util.Spliterator var7 = var1.spliterator();
    int var8 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    boolean var10 = var9.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test11() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test11");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    int var3 = var1.size();
    java.util.Spliterator var4 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    java.util.Spliterator var9 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    int var11 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    boolean var13 = var12.hasNext();
    boolean var14 = var12.hasNext();
    boolean var15 = var12.hasNext();
    boolean var16 = var12.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var17 = var12.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);

  }

  public void test12() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test12");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    int var22 = var9.size();
    exercise01.RingBuffer.RingBufferIterator var23 = var9.new RingBufferIterator();
    java.lang.Object var24 = var23.next();
    boolean var25 = var23.hasNext();
    java.lang.Object var26 = var23.next();
    boolean var27 = var23.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);

  }

  public void test13() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test13");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    int var5 = var1.size();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    java.util.Iterator var8 = var7.iterator();
    int var9 = var7.size();
    int var10 = var7.size();
    int var11 = var7.size();
    java.util.Spliterator var12 = var7.spliterator();
    int var13 = var7.size();
    var1.enqueue((java.lang.Object)var13);
    java.util.Spliterator var15 = var1.spliterator();
    java.util.Iterator var16 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test14() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test14");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    java.util.Spliterator var5 = var1.spliterator();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    int var8 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    java.util.Spliterator var11 = var1.spliterator();
    int var12 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var13 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var14 = var1.new RingBufferIterator();
    java.util.Iterator var15 = var1.iterator();
    java.util.Spliterator var16 = var1.spliterator();
    exercise01.RingBuffer var18 = new exercise01.RingBuffer(10);
    int var19 = var18.size();
    boolean var20 = var18.isEmpty();
    java.util.Iterator var21 = var18.iterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var18.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var18.new RingBufferIterator();
    var18.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(10);
    int var28 = var27.size();
    int var29 = var27.size();
    java.util.Spliterator var30 = var27.spliterator();
    var18.enqueue((java.lang.Object)var30);
    java.lang.Object var32 = var18.dequeue();
    exercise01.RingBuffer.RingBufferIterator var33 = var18.new RingBufferIterator();
    java.util.Spliterator var34 = var18.spliterator();
    java.util.Spliterator var35 = var18.spliterator();
    java.util.Iterator var36 = var18.iterator();
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(10);
    int var39 = var38.size();
    java.util.Spliterator var40 = var38.spliterator();
    exercise01.RingBuffer.RingBufferIterator var41 = var38.new RingBufferIterator();
    int var42 = var38.size();
    java.util.Spliterator var43 = var38.spliterator();
    exercise01.RingBuffer.RingBufferIterator var44 = var38.new RingBufferIterator();
    boolean var45 = var38.isEmpty();
    exercise01.RingBuffer var47 = new exercise01.RingBuffer(0);
    java.util.Spliterator var48 = var47.spliterator();
    java.util.Spliterator var49 = var47.spliterator();
    java.util.Spliterator var50 = var47.spliterator();
    java.util.Spliterator var51 = var47.spliterator();
    exercise01.RingBuffer.RingBufferIterator var52 = var47.new RingBufferIterator();
    boolean var53 = var52.hasNext();
    boolean var54 = var52.hasNext();
    var38.enqueue((java.lang.Object)var52);
    java.lang.Object var56 = var38.dequeue();
    exercise01.RingBuffer.RingBufferIterator var57 = var38.new RingBufferIterator();
    exercise01.RingBuffer var59 = new exercise01.RingBuffer(2);
    exercise01.RingBuffer.RingBufferIterator var60 = var59.new RingBufferIterator();
    java.util.Iterator var61 = var59.iterator();
    java.util.Iterator var62 = var59.iterator();
    var38.enqueue((java.lang.Object)var62);
    exercise01.RingBuffer var65 = new exercise01.RingBuffer(0);
    int var66 = var65.size();
    java.util.Spliterator var67 = var65.spliterator();
    int var68 = var65.size();
    java.util.Spliterator var69 = var65.spliterator();
    java.util.Iterator var70 = var65.iterator();
    boolean var71 = var65.isEmpty();
    int var72 = var65.size();
    exercise01.RingBuffer.RingBufferIterator var73 = var65.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var74 = var65.new RingBufferIterator();
    java.util.Spliterator var75 = var65.spliterator();
    java.util.Iterator var76 = var65.iterator();
    java.util.Spliterator var77 = var65.spliterator();
    var38.enqueue((java.lang.Object)var77);
    var18.enqueue((java.lang.Object)var77);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.enqueue((java.lang.Object)var18);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var32 + "' != '" + (-1.0f)+ "'", var32.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var76);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);

  }

  public void test15() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test15");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    int var8 = var1.size();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(100);
    java.util.Iterator var11 = var10.iterator();
    java.util.Spliterator var12 = var10.spliterator();
    java.util.Spliterator var13 = var10.spliterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(0);
    int var16 = var15.size();
    java.util.Iterator var17 = var15.iterator();
    var10.enqueue((java.lang.Object)var15);
    boolean var19 = var10.isEmpty();
    int var20 = var10.size();
    boolean var21 = var10.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var22 = var10.new RingBufferIterator();
    java.lang.Object var23 = var22.next();
    var1.enqueue(var23);
    boolean var25 = var1.isEmpty();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    java.util.Spliterator var28 = var27.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var27.new RingBufferIterator();
    java.util.Iterator var30 = var27.iterator();
    boolean var31 = var27.isEmpty();
    int var32 = var27.size();
    int var33 = var27.size();
    java.util.Iterator var34 = var27.iterator();
    java.util.Iterator var35 = var27.iterator();
    var1.enqueue((java.lang.Object)var35);
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(10);
    int var39 = var38.size();
    boolean var40 = var38.isEmpty();
    java.util.Iterator var41 = var38.iterator();
    java.util.Spliterator var42 = var38.spliterator();
    exercise01.RingBuffer var44 = new exercise01.RingBuffer(0);
    int var45 = var44.size();
    int var46 = var44.size();
    int var47 = var44.size();
    java.util.Iterator var48 = var44.iterator();
    var38.enqueue((java.lang.Object)var44);
    boolean var50 = var38.isEmpty();
    var1.enqueue((java.lang.Object)var38);
    boolean var52 = var38.isEmpty();
    java.util.Spliterator var53 = var38.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);

  }

  public void test16() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test16");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    exercise01.RingBuffer.RingBufferIterator var8 = var6.new RingBufferIterator();
    java.util.Spliterator var9 = var6.spliterator();
    int var10 = var6.size();
    int var11 = var6.size();
    boolean var12 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var13 = var6.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var13);
    int var15 = var1.size();
    boolean var16 = var1.isEmpty();
    int var17 = var1.size();
    boolean var18 = var1.isEmpty();
    int var19 = var1.size();
    java.lang.Object var20 = var1.dequeue();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(10);
    int var23 = var22.size();
    boolean var24 = var22.isEmpty();
    java.util.Iterator var25 = var22.iterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var22.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var27 = var22.new RingBufferIterator();
    exercise01.RingBuffer var29 = new exercise01.RingBuffer(10);
    int var30 = var29.size();
    boolean var31 = var29.isEmpty();
    java.util.Iterator var32 = var29.iterator();
    boolean var33 = var29.isEmpty();
    boolean var34 = var29.isEmpty();
    java.util.Iterator var35 = var29.iterator();
    var22.enqueue((java.lang.Object)var35);
    exercise01.RingBuffer var38 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(0);
    java.util.Spliterator var41 = var40.spliterator();
    exercise01.RingBuffer.RingBufferIterator var42 = var40.new RingBufferIterator();
    java.util.Spliterator var43 = var40.spliterator();
    int var44 = var40.size();
    exercise01.RingBuffer.RingBufferIterator var45 = var40.new RingBufferIterator();
    java.util.Iterator var46 = var40.iterator();
    var38.enqueue((java.lang.Object)var46);
    exercise01.RingBuffer.RingBufferIterator var48 = var38.new RingBufferIterator();
    var22.enqueue((java.lang.Object)var38);
    java.util.Spliterator var50 = var22.spliterator();
    java.lang.Object var51 = var22.dequeue();
    int var52 = var22.size();
    var1.enqueue((java.lang.Object)var22);
    java.util.Spliterator var54 = var22.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);

  }

  public void test17() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test17");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    java.util.Spliterator var3 = var1.spliterator();
    boolean var4 = var1.isEmpty();
    int var5 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    boolean var7 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    java.util.Spliterator var12 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var10.new RingBufferIterator();
    boolean var14 = var10.isEmpty();
    java.util.Iterator var15 = var10.iterator();
    boolean var16 = var10.isEmpty();
    java.util.Iterator var17 = var10.iterator();
    boolean var18 = var10.isEmpty();
    int var19 = var10.size();
    java.util.Spliterator var20 = var10.spliterator();
    java.util.Iterator var21 = var10.iterator();
    var1.enqueue((java.lang.Object)var10);
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(10);
    int var25 = var24.size();
    boolean var26 = var24.isEmpty();
    java.util.Iterator var27 = var24.iterator();
    exercise01.RingBuffer.RingBufferIterator var28 = var24.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var24.new RingBufferIterator();
    java.util.Iterator var30 = var24.iterator();
    int var31 = var24.size();
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(0);
    java.util.Spliterator var34 = var33.spliterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var33.new RingBufferIterator();
    java.util.Spliterator var36 = var33.spliterator();
    exercise01.RingBuffer.RingBufferIterator var37 = var33.new RingBufferIterator();
    boolean var38 = var37.hasNext();
    var24.enqueue((java.lang.Object)var37);
    java.util.Spliterator var40 = var24.spliterator();
    exercise01.RingBuffer.RingBufferIterator var41 = var24.new RingBufferIterator();
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(0);
    int var44 = var43.size();
    java.util.Spliterator var45 = var43.spliterator();
    int var46 = var43.size();
    java.util.Spliterator var47 = var43.spliterator();
    java.util.Iterator var48 = var43.iterator();
    boolean var49 = var43.isEmpty();
    java.util.Spliterator var50 = var43.spliterator();
    boolean var51 = var43.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var52 = var43.new RingBufferIterator();
    var24.enqueue((java.lang.Object)var52);
    exercise01.RingBuffer.RingBufferIterator var54 = var24.new RingBufferIterator();
    java.lang.Object var55 = var24.dequeue();
    int var56 = var24.size();
    java.util.Spliterator var57 = var24.spliterator();
    var10.enqueue((java.lang.Object)var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);

  }

  public void test18() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test18");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Iterator var4 = var1.iterator();
    int var5 = var1.size();
    int var6 = var1.size();
    java.util.Iterator var7 = var1.iterator();
    java.util.Iterator var8 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Spliterator var10 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    boolean var12 = var11.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == false);

  }

  public void test19() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test19");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Iterator var2 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    exercise01.RingBuffer var5 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(0);
    java.util.Spliterator var8 = var7.spliterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var7.new RingBufferIterator();
    java.util.Spliterator var10 = var7.spliterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var7.new RingBufferIterator();
    var5.enqueue((java.lang.Object)var7);
    java.lang.Object var13 = var5.dequeue();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(0);
    java.util.Spliterator var16 = var15.spliterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var15.new RingBufferIterator();
    java.util.Iterator var18 = var15.iterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var15.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var15.new RingBufferIterator();
    var5.enqueue((java.lang.Object)var20);
    java.util.Spliterator var22 = var5.spliterator();
    var1.enqueue((java.lang.Object)var5);
    java.lang.Object var24 = var1.dequeue();
    boolean var25 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var26 = var1.new RingBufferIterator();
    int var27 = var1.size();
    int var28 = var1.size();
    java.util.Iterator var29 = var1.iterator();
    java.util.Spliterator var30 = var1.spliterator();
    boolean var31 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == true);

  }

  public void test20() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test20");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    java.util.Spliterator var2 = var1.spliterator();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(0);
    java.util.Spliterator var7 = var6.spliterator();
    int var8 = var6.size();
    var1.enqueue((java.lang.Object)var8);
    boolean var10 = var1.isEmpty();
    java.lang.Object var11 = var1.dequeue();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(0);
    java.util.Spliterator var14 = var13.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var13.new RingBufferIterator();
    java.util.Spliterator var16 = var13.spliterator();
    int var17 = var13.size();
    int var18 = var13.size();
    boolean var19 = var13.isEmpty();
    int var20 = var13.size();
    java.util.Spliterator var21 = var13.spliterator();
    java.util.Iterator var22 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var23 = var13.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var23);
    boolean var25 = var1.isEmpty();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(10);
    int var28 = var27.size();
    boolean var29 = var27.isEmpty();
    java.util.Iterator var30 = var27.iterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var27.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var32 = var27.new RingBufferIterator();
    int var33 = var27.size();
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(0);
    java.util.Spliterator var38 = var37.spliterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var37.new RingBufferIterator();
    java.util.Spliterator var40 = var37.spliterator();
    var35.enqueue((java.lang.Object)var37);
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(100);
    java.util.Spliterator var44 = var43.spliterator();
    var35.enqueue((java.lang.Object)var44);
    java.util.Iterator var46 = var35.iterator();
    var27.enqueue((java.lang.Object)var35);
    boolean var48 = var35.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var49 = var35.new RingBufferIterator();
    java.util.Iterator var50 = var35.iterator();
    int var51 = var35.size();
    exercise01.RingBuffer.RingBufferIterator var52 = var35.new RingBufferIterator();
    exercise01.RingBuffer var54 = new exercise01.RingBuffer(0);
    java.util.Spliterator var55 = var54.spliterator();
    exercise01.RingBuffer.RingBufferIterator var56 = var54.new RingBufferIterator();
    java.util.Spliterator var57 = var54.spliterator();
    int var58 = var54.size();
    int var59 = var54.size();
    boolean var60 = var54.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var61 = var54.new RingBufferIterator();
    boolean var62 = var61.hasNext();
    boolean var63 = var61.hasNext();
    var35.enqueue((java.lang.Object)var61);
    var1.enqueue((java.lang.Object)var61);
    int var66 = var1.size();
    boolean var67 = var1.isEmpty();
    exercise01.RingBuffer var69 = new exercise01.RingBuffer(10);
    int var70 = var69.size();
    boolean var71 = var69.isEmpty();
    java.util.Iterator var72 = var69.iterator();
    boolean var73 = var69.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var74 = var69.new RingBufferIterator();
    exercise01.RingBuffer var76 = new exercise01.RingBuffer(10);
    int var77 = var76.size();
    boolean var78 = var76.isEmpty();
    java.util.Iterator var79 = var76.iterator();
    java.util.Spliterator var80 = var76.spliterator();
    java.util.Iterator var81 = var76.iterator();
    boolean var82 = var76.isEmpty();
    exercise01.RingBuffer var84 = new exercise01.RingBuffer(0);
    int var85 = var84.size();
    java.util.Iterator var86 = var84.iterator();
    exercise01.RingBuffer.RingBufferIterator var87 = var84.new RingBufferIterator();
    boolean var88 = var84.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var89 = var84.new RingBufferIterator();
    boolean var90 = var89.hasNext();
    var76.enqueue((java.lang.Object)var90);
    int var92 = var76.size();
    java.util.Spliterator var93 = var76.spliterator();
    var69.enqueue((java.lang.Object)var93);
    java.util.Spliterator var95 = var69.spliterator();
    java.lang.Object var96 = var69.dequeue();
    var1.enqueue(var96);
    boolean var98 = var1.isEmpty();
    java.lang.Object var99 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + 0+ "'", var11.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var77 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var78 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var80);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var82 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var85 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var90 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var98 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var99);

  }

  public void test21() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test21");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    java.util.Iterator var9 = var1.iterator();
    java.util.Iterator var10 = var1.iterator();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    int var14 = var12.size();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    int var16 = var12.size();
    java.util.Spliterator var17 = var12.spliterator();
    var1.enqueue((java.lang.Object)var12);
    exercise01.RingBuffer.RingBufferIterator var19 = var12.new RingBufferIterator();
    java.util.Iterator var20 = var12.iterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var12.new RingBufferIterator();
    boolean var22 = var12.isEmpty();
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(1);
    java.util.Spliterator var25 = var24.spliterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    int var28 = var27.size();
    var24.enqueue((java.lang.Object)var28);
    java.util.Iterator var30 = var24.iterator();
    boolean var31 = var24.isEmpty();
    java.util.Spliterator var32 = var24.spliterator();
    int var33 = var24.size();
    java.util.Iterator var34 = var24.iterator();
    boolean var35 = var24.isEmpty();
    java.lang.Object var36 = var24.dequeue();
    exercise01.RingBuffer.RingBufferIterator var37 = var24.new RingBufferIterator();
    var12.enqueue((java.lang.Object)var24);
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(10);
    int var41 = var40.size();
    java.util.Spliterator var42 = var40.spliterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var40.new RingBufferIterator();
    boolean var44 = var40.isEmpty();
    exercise01.RingBuffer var46 = new exercise01.RingBuffer(0);
    java.util.Spliterator var47 = var46.spliterator();
    java.util.Spliterator var48 = var46.spliterator();
    java.util.Spliterator var49 = var46.spliterator();
    java.util.Spliterator var50 = var46.spliterator();
    int var51 = var46.size();
    var40.enqueue((java.lang.Object)var51);
    java.lang.Object var53 = var40.dequeue();
    boolean var54 = var40.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var55 = var40.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var56 = var40.new RingBufferIterator();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(0);
    java.util.Spliterator var59 = var58.spliterator();
    exercise01.RingBuffer.RingBufferIterator var60 = var58.new RingBufferIterator();
    java.util.Iterator var61 = var58.iterator();
    int var62 = var58.size();
    int var63 = var58.size();
    int var64 = var58.size();
    boolean var65 = var58.isEmpty();
    java.util.Iterator var66 = var58.iterator();
    boolean var67 = var58.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var68 = var58.new RingBufferIterator();
    var40.enqueue((java.lang.Object)var68);
    var12.enqueue((java.lang.Object)var68);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var36 + "' != '" + 0+ "'", var36.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var49);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var53 + "' != '" + 0+ "'", var53.equals(0));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var54 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var62 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var63 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var67 == true);

  }

  public void test22() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test22");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    boolean var2 = var1.isEmpty();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    int var5 = var1.size();
    java.util.Spliterator var6 = var1.spliterator();
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    int var12 = var8.size();
    int var13 = var8.size();
    boolean var14 = var8.isEmpty();
    boolean var15 = var8.isEmpty();
    int var16 = var8.size();
    java.util.Spliterator var17 = var8.spliterator();
    int var18 = var8.size();
    boolean var19 = var8.isEmpty();
    java.util.Spliterator var20 = var8.spliterator();
    var1.enqueue((java.lang.Object)var8);
    java.lang.Object var22 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var23 = var1.new RingBufferIterator();
    boolean var24 = var23.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var25 = var23.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);

  }

  public void test23() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test23");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Spliterator var4 = var1.spliterator();
    int var5 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    boolean var8 = var1.isEmpty();
    java.util.Spliterator var9 = var1.spliterator();
    java.util.Iterator var10 = var1.iterator();
    java.util.Spliterator var11 = var1.spliterator();
    java.util.Iterator var12 = var1.iterator();
    int var13 = var1.size();
    boolean var14 = var1.isEmpty();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(10);
    int var17 = var16.size();
    java.util.Spliterator var18 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var16.new RingBufferIterator();
    java.util.Spliterator var20 = var16.spliterator();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(100);
    java.util.Iterator var23 = var22.iterator();
    java.util.Spliterator var24 = var22.spliterator();
    java.util.Spliterator var25 = var22.spliterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    int var28 = var27.size();
    java.util.Iterator var29 = var27.iterator();
    var22.enqueue((java.lang.Object)var27);
    boolean var31 = var22.isEmpty();
    java.lang.Object var32 = var22.dequeue();
    var16.enqueue((java.lang.Object)var22);
    java.util.Iterator var34 = var16.iterator();
    boolean var35 = var16.isEmpty();
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var39 = new exercise01.RingBuffer(0);
    java.util.Spliterator var40 = var39.spliterator();
    exercise01.RingBuffer.RingBufferIterator var41 = var39.new RingBufferIterator();
    java.util.Spliterator var42 = var39.spliterator();
    var37.enqueue((java.lang.Object)var39);
    boolean var44 = var37.isEmpty();
    int var45 = var37.size();
    var16.enqueue((java.lang.Object)var45);
    boolean var47 = var16.isEmpty();
    java.util.Spliterator var48 = var16.spliterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.enqueue((java.lang.Object)var48);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test24() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test24");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    int var2 = var1.size();
    int var3 = var1.size();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    java.util.Spliterator var6 = var1.spliterator();
    java.util.Iterator var7 = var1.iterator();
    java.util.Iterator var8 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    boolean var10 = var9.hasNext();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var9.remove();
      fail("Expected exception of type java.lang.UnsupportedOperationException");
    } catch (java.lang.UnsupportedOperationException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test25() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test25");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    java.util.Spliterator var3 = var1.spliterator();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var6 = var5.next();
      fail("Expected exception of type java.util.NoSuchElementException");
    } catch (java.util.NoSuchElementException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test26() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test26");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    int var22 = var9.size();
    int var23 = var9.size();
    int var24 = var9.size();
    java.util.Spliterator var25 = var9.spliterator();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    exercise01.RingBuffer.RingBufferIterator var28 = var27.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var27.new RingBufferIterator();
    java.util.Spliterator var30 = var27.spliterator();
    var9.enqueue((java.lang.Object)var27);
    boolean var32 = var9.isEmpty();
    java.util.Iterator var33 = var9.iterator();
    boolean var34 = var9.isEmpty();
    java.lang.Object var35 = var9.dequeue();
    java.util.Spliterator var36 = var9.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);

  }

  public void test27() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test27");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    java.util.Spliterator var5 = var1.spliterator();
    boolean var6 = var1.isEmpty();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    java.util.Iterator var10 = var9.iterator();
    java.util.Spliterator var11 = var9.spliterator();
    java.util.Spliterator var12 = var9.spliterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    int var15 = var14.size();
    java.util.Iterator var16 = var14.iterator();
    var9.enqueue((java.lang.Object)var14);
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var14.new RingBufferIterator();
    int var20 = var14.size();
    java.util.Iterator var21 = var14.iterator();
    var1.enqueue((java.lang.Object)var21);
    boolean var23 = var1.isEmpty();
    java.util.Iterator var24 = var1.iterator();
    java.util.Iterator var25 = var1.iterator();
    java.util.Spliterator var26 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test28() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test28");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    int var5 = var1.size();
    var1.enqueue((java.lang.Object)10);
    java.lang.Object var8 = var1.dequeue();
    var1.enqueue((java.lang.Object)"hi!");
    java.lang.Object var11 = var1.dequeue();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(10);
    int var15 = var14.size();
    boolean var16 = var14.isEmpty();
    java.util.Iterator var17 = var14.iterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var14.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var14.new RingBufferIterator();
    int var20 = var14.size();
    exercise01.RingBuffer var22 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var24 = new exercise01.RingBuffer(0);
    java.util.Spliterator var25 = var24.spliterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var24.new RingBufferIterator();
    java.util.Spliterator var27 = var24.spliterator();
    var22.enqueue((java.lang.Object)var24);
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(100);
    java.util.Spliterator var31 = var30.spliterator();
    var22.enqueue((java.lang.Object)var31);
    java.util.Iterator var33 = var22.iterator();
    var14.enqueue((java.lang.Object)var22);
    int var35 = var22.size();
    int var36 = var22.size();
    int var37 = var22.size();
    java.lang.Object var38 = var22.dequeue();
    var1.enqueue(var38);
    java.util.Iterator var40 = var1.iterator();
    exercise01.RingBuffer var42 = new exercise01.RingBuffer(10);
    int var43 = var42.size();
    boolean var44 = var42.isEmpty();
    java.util.Iterator var45 = var42.iterator();
    exercise01.RingBuffer.RingBufferIterator var46 = var42.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var42.new RingBufferIterator();
    var42.enqueue((java.lang.Object)(-1.0f));
    java.lang.Object var50 = var42.dequeue();
    java.util.Iterator var51 = var42.iterator();
    exercise01.RingBuffer.RingBufferIterator var52 = var42.new RingBufferIterator();
    exercise01.RingBuffer var54 = new exercise01.RingBuffer(10);
    int var55 = var54.size();
    boolean var56 = var54.isEmpty();
    java.util.Iterator var57 = var54.iterator();
    java.util.Spliterator var58 = var54.spliterator();
    exercise01.RingBuffer var60 = new exercise01.RingBuffer(1);
    boolean var61 = var60.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var62 = var60.new RingBufferIterator();
    java.util.Spliterator var63 = var60.spliterator();
    var54.enqueue((java.lang.Object)var60);
    boolean var65 = var60.isEmpty();
    java.util.Spliterator var66 = var60.spliterator();
    var42.enqueue((java.lang.Object)var66);
    int var68 = var42.size();
    var1.enqueue((java.lang.Object)var42);
    boolean var70 = var1.isEmpty();
    int var71 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var72 = var1.new RingBufferIterator();
    java.util.Spliterator var73 = var1.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10+ "'", var8.equals(10));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + "hi!"+ "'", var11.equals("hi!"));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var50 + "' != '" + (-1.0f)+ "'", var50.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var56 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var70 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var73);

  }

  public void test29() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test29");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    java.util.Iterator var6 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    java.util.Spliterator var8 = var1.spliterator();
    boolean var9 = var1.isEmpty();
    int var10 = var1.size();
    java.util.Spliterator var11 = var1.spliterator();
    java.util.Iterator var12 = var1.iterator();
    java.util.Iterator var13 = var1.iterator();
    int var14 = var1.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);

  }

  public void test30() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test30");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    int var3 = var1.size();
    java.util.Spliterator var4 = var1.spliterator();
    java.util.Iterator var5 = var1.iterator();
    boolean var6 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var7 = var1.new RingBufferIterator();
    int var8 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    boolean var10 = var9.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test31() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test31");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var8 = new exercise01.RingBuffer(0);
    java.util.Spliterator var9 = var8.spliterator();
    exercise01.RingBuffer.RingBufferIterator var10 = var8.new RingBufferIterator();
    java.util.Spliterator var11 = var8.spliterator();
    var6.enqueue((java.lang.Object)var8);
    var1.enqueue((java.lang.Object)var6);
    java.util.Spliterator var14 = var6.spliterator();
    boolean var15 = var6.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var16 = var6.new RingBufferIterator();
    java.util.Spliterator var17 = var6.spliterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);

  }

  public void test32() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test32");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var3 = new exercise01.RingBuffer(0);
    java.util.Spliterator var4 = var3.spliterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var3.new RingBufferIterator();
    java.util.Spliterator var6 = var3.spliterator();
    var1.enqueue((java.lang.Object)var3);
    java.lang.Object var8 = var1.dequeue();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(1);
    exercise01.RingBuffer.RingBufferIterator var11 = var10.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var11);
    java.util.Spliterator var13 = var1.spliterator();
    java.util.Iterator var14 = var1.iterator();
    java.util.Iterator var15 = var1.iterator();
    java.lang.Object var16 = var1.dequeue();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var17 = var1.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test33() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test33");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    boolean var2 = var1.isEmpty();
    int var3 = var1.size();
    java.util.Spliterator var4 = var1.spliterator();
    boolean var5 = var1.isEmpty();
    java.util.Spliterator var6 = var1.spliterator();
    boolean var7 = var1.isEmpty();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var8 = var1.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);

  }

  public void test34() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test34");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    boolean var22 = var9.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var23 = var9.new RingBufferIterator();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(0);
    int var26 = var25.size();
    java.util.Iterator var27 = var25.iterator();
    var9.enqueue((java.lang.Object)var25);
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(0);
    int var31 = var30.size();
    java.util.Spliterator var32 = var30.spliterator();
    int var33 = var30.size();
    java.util.Spliterator var34 = var30.spliterator();
    java.util.Iterator var35 = var30.iterator();
    boolean var36 = var30.isEmpty();
    int var37 = var30.size();
    exercise01.RingBuffer.RingBufferIterator var38 = var30.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var30.new RingBufferIterator();
    int var40 = var30.size();
    java.util.Iterator var41 = var30.iterator();
    var9.enqueue((java.lang.Object)var30);
    exercise01.RingBuffer.RingBufferIterator var43 = var30.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var44 = var30.new RingBufferIterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.Object var45 = var30.dequeue();
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);

  }

  public void test35() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test35");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Spliterator var2 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var3 = var1.new RingBufferIterator();
    java.util.Spliterator var4 = var1.spliterator();
    int var5 = var1.size();
    int var6 = var1.size();
    boolean var7 = var1.isEmpty();
    int var8 = var1.size();
    java.util.Spliterator var9 = var1.spliterator();
    java.util.Iterator var10 = var1.iterator();
    boolean var11 = var1.isEmpty();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    java.util.Iterator var14 = var1.iterator();
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(10);
    int var17 = var16.size();
    java.util.Spliterator var18 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var16.new RingBufferIterator();
    boolean var20 = var16.isEmpty();
    java.util.Iterator var21 = var16.iterator();
    boolean var22 = var16.isEmpty();
    boolean var23 = var16.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var24 = var16.new RingBufferIterator();
    boolean var25 = var16.isEmpty();
    int var26 = var16.size();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var1.enqueue((java.lang.Object)var16);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);

  }

  public void test36() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test36");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    boolean var5 = var1.isEmpty();
    exercise01.RingBuffer var7 = new exercise01.RingBuffer(1);
    boolean var8 = var7.isEmpty();
    var1.enqueue((java.lang.Object)var7);
    java.lang.Object var10 = var1.dequeue();
    boolean var11 = var1.isEmpty();
    java.util.Spliterator var12 = var1.spliterator();
    java.util.Spliterator var13 = var1.spliterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(10);
    int var16 = var15.size();
    boolean var17 = var15.isEmpty();
    java.util.Iterator var18 = var15.iterator();
    boolean var19 = var15.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var20 = var15.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var15.new RingBufferIterator();
    int var22 = var15.size();
    exercise01.RingBuffer.RingBufferIterator var23 = var15.new RingBufferIterator();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(10);
    int var26 = var25.size();
    boolean var27 = var25.isEmpty();
    java.util.Iterator var28 = var25.iterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var25.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var30 = var25.new RingBufferIterator();
    int var31 = var25.size();
    exercise01.RingBuffer var33 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(0);
    java.util.Spliterator var36 = var35.spliterator();
    exercise01.RingBuffer.RingBufferIterator var37 = var35.new RingBufferIterator();
    java.util.Spliterator var38 = var35.spliterator();
    var33.enqueue((java.lang.Object)var35);
    exercise01.RingBuffer var41 = new exercise01.RingBuffer(100);
    java.util.Spliterator var42 = var41.spliterator();
    var33.enqueue((java.lang.Object)var42);
    java.util.Iterator var44 = var33.iterator();
    var25.enqueue((java.lang.Object)var33);
    exercise01.RingBuffer.RingBufferIterator var46 = var25.new RingBufferIterator();
    boolean var47 = var46.hasNext();
    var15.enqueue((java.lang.Object)var46);
    exercise01.RingBuffer.RingBufferIterator var49 = var15.new RingBufferIterator();
    boolean var50 = var49.hasNext();
    var1.enqueue((java.lang.Object)var49);
    java.lang.Object var52 = var49.next();
    boolean var53 = var49.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == false);

  }

  public void test37() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test37");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var8 = var1.new RingBufferIterator();
    exercise01.RingBuffer var10 = new exercise01.RingBuffer(10);
    int var11 = var10.size();
    java.util.Spliterator var12 = var10.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var10.new RingBufferIterator();
    exercise01.RingBuffer var15 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(0);
    java.util.Spliterator var18 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var17.new RingBufferIterator();
    java.util.Spliterator var20 = var17.spliterator();
    var15.enqueue((java.lang.Object)var17);
    var10.enqueue((java.lang.Object)var15);
    var1.enqueue((java.lang.Object)var10);
    int var24 = var10.size();
    boolean var25 = var10.isEmpty();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    java.util.Spliterator var28 = var27.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var27.new RingBufferIterator();
    java.util.Iterator var30 = var27.iterator();
    int var31 = var27.size();
    int var32 = var27.size();
    java.util.Iterator var33 = var27.iterator();
    boolean var34 = var27.isEmpty();
    boolean var35 = var27.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var36 = var27.new RingBufferIterator();
    java.util.Spliterator var37 = var27.spliterator();
    java.util.Iterator var38 = var27.iterator();
    int var39 = var27.size();
    java.util.Spliterator var40 = var27.spliterator();
    var10.enqueue((java.lang.Object)var27);
    exercise01.RingBuffer var43 = new exercise01.RingBuffer(10);
    int var44 = var43.size();
    boolean var45 = var43.isEmpty();
    java.util.Iterator var46 = var43.iterator();
    exercise01.RingBuffer.RingBufferIterator var47 = var43.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var48 = var43.new RingBufferIterator();
    int var49 = var43.size();
    exercise01.RingBuffer.RingBufferIterator var50 = var43.new RingBufferIterator();
    exercise01.RingBuffer var52 = new exercise01.RingBuffer(10);
    int var53 = var52.size();
    java.util.Spliterator var54 = var52.spliterator();
    exercise01.RingBuffer.RingBufferIterator var55 = var52.new RingBufferIterator();
    exercise01.RingBuffer var57 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var59 = new exercise01.RingBuffer(0);
    java.util.Spliterator var60 = var59.spliterator();
    exercise01.RingBuffer.RingBufferIterator var61 = var59.new RingBufferIterator();
    java.util.Spliterator var62 = var59.spliterator();
    var57.enqueue((java.lang.Object)var59);
    var52.enqueue((java.lang.Object)var57);
    var43.enqueue((java.lang.Object)var52);
    int var66 = var52.size();
    exercise01.RingBuffer var68 = new exercise01.RingBuffer(100);
    java.util.Iterator var69 = var68.iterator();
    java.util.Spliterator var70 = var68.spliterator();
    int var71 = var68.size();
    java.util.Iterator var72 = var68.iterator();
    exercise01.RingBuffer.RingBufferIterator var73 = var68.new RingBufferIterator();
    int var74 = var68.size();
    var52.enqueue((java.lang.Object)var68);
    boolean var76 = var68.isEmpty();
    exercise01.RingBuffer var78 = new exercise01.RingBuffer(0);
    java.util.Spliterator var79 = var78.spliterator();
    exercise01.RingBuffer.RingBufferIterator var80 = var78.new RingBufferIterator();
    java.util.Iterator var81 = var78.iterator();
    var68.enqueue((java.lang.Object)var81);
    exercise01.RingBuffer.RingBufferIterator var83 = var68.new RingBufferIterator();
    int var84 = var68.size();
    var10.enqueue((java.lang.Object)var84);
    java.lang.Object var86 = var10.dequeue();
    exercise01.RingBuffer.RingBufferIterator var87 = var10.new RingBufferIterator();
    boolean var88 = var87.hasNext();
    java.lang.Object var89 = var87.next();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var53 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var71 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var72);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var76 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var81);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var84 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var86);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var88 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var89);

  }

  public void test38() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test38");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    java.util.Spliterator var3 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var4 = var1.new RingBufferIterator();
    boolean var5 = var1.isEmpty();
    java.util.Iterator var6 = var1.iterator();
    boolean var7 = var1.isEmpty();
    boolean var8 = var1.isEmpty();
    java.util.Iterator var9 = var1.iterator();
    boolean var10 = var1.isEmpty();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(10);
    int var13 = var12.size();
    java.util.Spliterator var14 = var12.spliterator();
    exercise01.RingBuffer.RingBufferIterator var15 = var12.new RingBufferIterator();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(0);
    java.util.Spliterator var18 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var19 = var17.new RingBufferIterator();
    java.util.Iterator var20 = var17.iterator();
    int var21 = var17.size();
    int var22 = var17.size();
    java.util.Iterator var23 = var17.iterator();
    boolean var24 = var17.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var25 = var17.new RingBufferIterator();
    boolean var26 = var17.isEmpty();
    java.util.Iterator var27 = var17.iterator();
    java.util.Spliterator var28 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var29 = var17.new RingBufferIterator();
    boolean var30 = var17.isEmpty();
    var12.enqueue((java.lang.Object)var17);
    var1.enqueue((java.lang.Object)var17);
    exercise01.RingBuffer var34 = new exercise01.RingBuffer(1);
    java.util.Spliterator var35 = var34.spliterator();
    exercise01.RingBuffer var37 = new exercise01.RingBuffer(0);
    java.util.Iterator var38 = var37.iterator();
    int var39 = var37.size();
    int var40 = var37.size();
    int var41 = var37.size();
    java.util.Spliterator var42 = var37.spliterator();
    var34.enqueue((java.lang.Object)var37);
    int var44 = var34.size();
    exercise01.RingBuffer.RingBufferIterator var45 = var34.new RingBufferIterator();
    boolean var46 = var34.isEmpty();
    java.util.Iterator var47 = var34.iterator();
    java.util.Iterator var48 = var34.iterator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var17.enqueue((java.lang.Object)var34);
      fail("Expected exception of type exercise01.RingBufferException");
    } catch (exercise01.RingBufferException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);

  }

  public void test39() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test39");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer.RingBufferIterator var9 = var1.new RingBufferIterator();
    java.util.Iterator var10 = var1.iterator();
    java.util.Iterator var11 = var1.iterator();
    java.util.Spliterator var12 = var1.spliterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(10);
    int var15 = var14.size();
    boolean var16 = var14.isEmpty();
    java.util.Iterator var17 = var14.iterator();
    java.util.Spliterator var18 = var14.spliterator();
    java.util.Iterator var19 = var14.iterator();
    exercise01.RingBuffer var21 = new exercise01.RingBuffer(10);
    int var22 = var21.size();
    boolean var23 = var21.isEmpty();
    java.util.Iterator var24 = var21.iterator();
    exercise01.RingBuffer.RingBufferIterator var25 = var21.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var26 = var21.new RingBufferIterator();
    java.util.Iterator var27 = var21.iterator();
    int var28 = var21.size();
    java.util.Iterator var29 = var21.iterator();
    var14.enqueue((java.lang.Object)var21);
    boolean var31 = var14.isEmpty();
    var1.enqueue((java.lang.Object)var31);
    java.util.Spliterator var33 = var1.spliterator();
    exercise01.RingBuffer var35 = new exercise01.RingBuffer(10);
    int var36 = var35.size();
    boolean var37 = var35.isEmpty();
    java.util.Iterator var38 = var35.iterator();
    exercise01.RingBuffer.RingBufferIterator var39 = var35.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var40 = var35.new RingBufferIterator();
    var35.enqueue((java.lang.Object)(-1.0f));
    exercise01.RingBuffer var44 = new exercise01.RingBuffer(10);
    int var45 = var44.size();
    int var46 = var44.size();
    java.util.Spliterator var47 = var44.spliterator();
    var35.enqueue((java.lang.Object)var47);
    java.lang.Object var49 = var35.dequeue();
    exercise01.RingBuffer.RingBufferIterator var50 = var35.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var51 = var35.new RingBufferIterator();
    var1.enqueue((java.lang.Object)var51);
    exercise01.RingBuffer.RingBufferIterator var53 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var54 = var1.new RingBufferIterator();
    boolean var55 = var54.hasNext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var49 + "' != '" + (-1.0f)+ "'", var49.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == true);

  }

  public void test40() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test40");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(0);
    java.util.Iterator var2 = var1.iterator();
    int var3 = var1.size();
    int var4 = var1.size();
    int var5 = var1.size();
    java.util.Spliterator var6 = var1.spliterator();
    int var7 = var1.size();
    int var8 = var1.size();
    boolean var9 = var1.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    boolean var11 = var1.isEmpty();
    java.util.Iterator var12 = var1.iterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);

  }

  public void test41() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test41");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(100);
    boolean var2 = var1.isEmpty();
    boolean var3 = var1.isEmpty();
    int var4 = var1.size();
    java.util.Iterator var5 = var1.iterator();
    java.util.Iterator var6 = var1.iterator();
    java.util.Spliterator var7 = var1.spliterator();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    java.util.Iterator var10 = var9.iterator();
    java.util.Spliterator var11 = var9.spliterator();
    int var12 = var9.size();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(0);
    java.util.Spliterator var15 = var14.spliterator();
    exercise01.RingBuffer.RingBufferIterator var16 = var14.new RingBufferIterator();
    java.util.Spliterator var17 = var14.spliterator();
    int var18 = var14.size();
    int var19 = var14.size();
    boolean var20 = var14.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var21 = var14.new RingBufferIterator();
    var9.enqueue((java.lang.Object)var21);
    int var23 = var9.size();
    boolean var24 = var9.isEmpty();
    int var25 = var9.size();
    boolean var26 = var9.isEmpty();
    int var27 = var9.size();
    java.lang.Object var28 = var9.dequeue();
    var1.enqueue((java.lang.Object)var9);
    exercise01.RingBuffer.RingBufferIterator var30 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);

  }

  public void test42() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test42");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    java.util.Spliterator var5 = var1.spliterator();
    var1.enqueue((java.lang.Object)(short)1);
    java.util.Spliterator var8 = var1.spliterator();
    int var9 = var1.size();
    java.util.Iterator var10 = var1.iterator();
    java.util.Spliterator var11 = var1.spliterator();
    exercise01.RingBuffer.RingBufferIterator var12 = var1.new RingBufferIterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(10);
    exercise01.RingBuffer var16 = new exercise01.RingBuffer(0);
    java.util.Spliterator var17 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var16.new RingBufferIterator();
    java.util.Spliterator var19 = var16.spliterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var16.new RingBufferIterator();
    var14.enqueue((java.lang.Object)var16);
    java.lang.Object var22 = var14.dequeue();
    boolean var23 = var14.isEmpty();
    int var24 = var14.size();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(10);
    int var27 = var26.size();
    boolean var28 = var26.isEmpty();
    java.util.Iterator var29 = var26.iterator();
    exercise01.RingBuffer.RingBufferIterator var30 = var26.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var31 = var26.new RingBufferIterator();
    var26.enqueue((java.lang.Object)(-1.0f));
    java.lang.Object var34 = var26.dequeue();
    java.util.Iterator var35 = var26.iterator();
    boolean var36 = var26.isEmpty();
    java.util.Spliterator var37 = var26.spliterator();
    exercise01.RingBuffer.RingBufferIterator var38 = var26.new RingBufferIterator();
    var14.enqueue((java.lang.Object)var38);
    int var40 = var14.size();
    java.util.Spliterator var41 = var14.spliterator();
    var1.enqueue((java.lang.Object)var14);
    boolean var43 = var1.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var34 + "' != '" + (-1.0f)+ "'", var34.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test43() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test43");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    var1.enqueue((java.lang.Object)(-1.0f));
    java.util.Iterator var9 = var1.iterator();
    java.lang.Object var10 = var1.dequeue();
    exercise01.RingBuffer var12 = new exercise01.RingBuffer(100);
    java.util.Iterator var13 = var12.iterator();
    java.util.Spliterator var14 = var12.spliterator();
    java.util.Spliterator var15 = var12.spliterator();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(0);
    int var18 = var17.size();
    java.util.Iterator var19 = var17.iterator();
    var12.enqueue((java.lang.Object)var17);
    exercise01.RingBuffer.RingBufferIterator var21 = var17.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var22 = var17.new RingBufferIterator();
    java.util.Spliterator var23 = var17.spliterator();
    var1.enqueue((java.lang.Object)var17);
    boolean var25 = var1.isEmpty();
    exercise01.RingBuffer var27 = new exercise01.RingBuffer(0);
    int var28 = var27.size();
    int var29 = var27.size();
    int var30 = var27.size();
    exercise01.RingBuffer.RingBufferIterator var31 = var27.new RingBufferIterator();
    boolean var32 = var27.isEmpty();
    int var33 = var27.size();
    var1.enqueue((java.lang.Object)var27);
    int var35 = var27.size();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (-1.0f)+ "'", var10.equals((-1.0f)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var33 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == 0);

  }

  public void test44() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test44");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    java.util.Iterator var7 = var1.iterator();
    int var8 = var1.size();
    int var9 = var1.size();
    exercise01.RingBuffer.RingBufferIterator var10 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var11 = var1.new RingBufferIterator();
    boolean var12 = var1.isEmpty();
    java.util.Spliterator var13 = var1.spliterator();
    int var14 = var1.size();
    boolean var15 = var1.isEmpty();
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(10);
    int var18 = var17.size();
    java.util.Spliterator var19 = var17.spliterator();
    exercise01.RingBuffer.RingBufferIterator var20 = var17.new RingBufferIterator();
    java.util.Spliterator var21 = var17.spliterator();
    boolean var22 = var17.isEmpty();
    int var23 = var17.size();
    exercise01.RingBuffer var25 = new exercise01.RingBuffer(100);
    java.util.Iterator var26 = var25.iterator();
    java.util.Spliterator var27 = var25.spliterator();
    java.util.Spliterator var28 = var25.spliterator();
    exercise01.RingBuffer var30 = new exercise01.RingBuffer(0);
    int var31 = var30.size();
    java.util.Iterator var32 = var30.iterator();
    var25.enqueue((java.lang.Object)var30);
    exercise01.RingBuffer.RingBufferIterator var34 = var30.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var35 = var30.new RingBufferIterator();
    int var36 = var30.size();
    java.util.Iterator var37 = var30.iterator();
    var17.enqueue((java.lang.Object)var37);
    boolean var39 = var17.isEmpty();
    java.util.Spliterator var40 = var17.spliterator();
    java.util.Spliterator var41 = var17.spliterator();
    java.util.Spliterator var42 = var17.spliterator();
    java.lang.Object var43 = var17.dequeue();
    var1.enqueue((java.lang.Object)var17);
    exercise01.RingBuffer.RingBufferIterator var45 = var1.new RingBufferIterator();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);

  }

  public void test45() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test45");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    java.util.Spliterator var6 = var1.spliterator();
    int var7 = var1.size();
    java.util.Iterator var8 = var1.iterator();
    boolean var9 = var1.isEmpty();
    boolean var10 = var1.isEmpty();
    java.util.Spliterator var11 = var1.spliterator();
    exercise01.RingBuffer var13 = new exercise01.RingBuffer(10);
    int var14 = var13.size();
    boolean var15 = var13.isEmpty();
    java.util.Iterator var16 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var17 = var13.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var18 = var13.new RingBufferIterator();
    int var19 = var13.size();
    exercise01.RingBuffer.RingBufferIterator var20 = var13.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var21 = var13.new RingBufferIterator();
    boolean var22 = var13.isEmpty();
    java.util.Iterator var23 = var13.iterator();
    exercise01.RingBuffer.RingBufferIterator var24 = var13.new RingBufferIterator();
    boolean var25 = var13.isEmpty();
    int var26 = var13.size();
    var1.enqueue((java.lang.Object)var26);
    boolean var28 = var1.isEmpty();
    java.lang.Object var29 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var29 + "' != '" + 0+ "'", var29.equals(0));

  }

  public void test46() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test46");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Spliterator var4 = var1.spliterator();
    exercise01.RingBuffer var6 = new exercise01.RingBuffer(10);
    int var7 = var6.size();
    boolean var8 = var6.isEmpty();
    java.util.Iterator var9 = var6.iterator();
    java.util.Spliterator var10 = var6.spliterator();
    java.util.Iterator var11 = var6.iterator();
    java.util.Iterator var12 = var6.iterator();
    exercise01.RingBuffer var14 = new exercise01.RingBuffer(100);
    java.util.Iterator var15 = var14.iterator();
    java.util.Spliterator var16 = var14.spliterator();
    java.util.Spliterator var17 = var14.spliterator();
    exercise01.RingBuffer var19 = new exercise01.RingBuffer(0);
    int var20 = var19.size();
    java.util.Iterator var21 = var19.iterator();
    var14.enqueue((java.lang.Object)var19);
    exercise01.RingBuffer.RingBufferIterator var23 = var19.new RingBufferIterator();
    java.util.Spliterator var24 = var19.spliterator();
    var6.enqueue((java.lang.Object)var24);
    exercise01.RingBuffer.RingBufferIterator var26 = var6.new RingBufferIterator();
    java.lang.Object var27 = var6.dequeue();
    java.util.Iterator var28 = var6.iterator();
    int var29 = var6.size();
    java.util.Spliterator var30 = var6.spliterator();
    var1.enqueue((java.lang.Object)var30);
    int var32 = var1.size();
    java.lang.Object var33 = var1.dequeue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var21);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);

  }

  public void test47() throws Throwable {

    if (debug) System.out.printf("%nRandoopTest64.test47");


    exercise01.RingBuffer var1 = new exercise01.RingBuffer(10);
    int var2 = var1.size();
    boolean var3 = var1.isEmpty();
    java.util.Iterator var4 = var1.iterator();
    exercise01.RingBuffer.RingBufferIterator var5 = var1.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var6 = var1.new RingBufferIterator();
    int var7 = var1.size();
    exercise01.RingBuffer var9 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var11 = new exercise01.RingBuffer(0);
    java.util.Spliterator var12 = var11.spliterator();
    exercise01.RingBuffer.RingBufferIterator var13 = var11.new RingBufferIterator();
    java.util.Spliterator var14 = var11.spliterator();
    var9.enqueue((java.lang.Object)var11);
    exercise01.RingBuffer var17 = new exercise01.RingBuffer(100);
    java.util.Spliterator var18 = var17.spliterator();
    var9.enqueue((java.lang.Object)var18);
    java.util.Iterator var20 = var9.iterator();
    var1.enqueue((java.lang.Object)var9);
    int var22 = var9.size();
    java.lang.Object var23 = var9.dequeue();
    exercise01.RingBuffer.RingBufferIterator var24 = var9.new RingBufferIterator();
    exercise01.RingBuffer var26 = new exercise01.RingBuffer(0);
    int var27 = var26.size();
    java.util.Iterator var28 = var26.iterator();
    boolean var29 = var26.isEmpty();
    boolean var30 = var26.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var31 = var26.new RingBufferIterator();
    int var32 = var26.size();
    exercise01.RingBuffer.RingBufferIterator var33 = var26.new RingBufferIterator();
    int var34 = var26.size();
    exercise01.RingBuffer.RingBufferIterator var35 = var26.new RingBufferIterator();
    java.util.Spliterator var36 = var26.spliterator();
    var9.enqueue((java.lang.Object)var26);
    java.util.Spliterator var38 = var9.spliterator();
    exercise01.RingBuffer var40 = new exercise01.RingBuffer(10);
    int var41 = var40.size();
    java.util.Spliterator var42 = var40.spliterator();
    exercise01.RingBuffer.RingBufferIterator var43 = var40.new RingBufferIterator();
    exercise01.RingBuffer var45 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var47 = new exercise01.RingBuffer(0);
    java.util.Spliterator var48 = var47.spliterator();
    exercise01.RingBuffer.RingBufferIterator var49 = var47.new RingBufferIterator();
    java.util.Spliterator var50 = var47.spliterator();
    var45.enqueue((java.lang.Object)var47);
    var40.enqueue((java.lang.Object)var45);
    java.util.Spliterator var53 = var45.spliterator();
    java.util.Iterator var54 = var45.iterator();
    java.util.Iterator var55 = var45.iterator();
    java.lang.Object var56 = var45.dequeue();
    exercise01.RingBuffer var58 = new exercise01.RingBuffer(10);
    int var59 = var58.size();
    boolean var60 = var58.isEmpty();
    java.util.Iterator var61 = var58.iterator();
    exercise01.RingBuffer.RingBufferIterator var62 = var58.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var63 = var58.new RingBufferIterator();
    int var64 = var58.size();
    exercise01.RingBuffer var66 = new exercise01.RingBuffer(100);
    exercise01.RingBuffer var68 = new exercise01.RingBuffer(0);
    java.util.Spliterator var69 = var68.spliterator();
    exercise01.RingBuffer.RingBufferIterator var70 = var68.new RingBufferIterator();
    java.util.Spliterator var71 = var68.spliterator();
    var66.enqueue((java.lang.Object)var68);
    exercise01.RingBuffer var74 = new exercise01.RingBuffer(100);
    java.util.Spliterator var75 = var74.spliterator();
    var66.enqueue((java.lang.Object)var75);
    java.util.Iterator var77 = var66.iterator();
    var58.enqueue((java.lang.Object)var66);
    java.lang.Object var79 = var58.dequeue();
    int var80 = var58.size();
    var45.enqueue((java.lang.Object)var58);
    exercise01.RingBuffer.RingBufferIterator var82 = var58.new RingBufferIterator();
    java.util.Iterator var83 = var58.iterator();
    exercise01.RingBuffer var85 = new exercise01.RingBuffer(10);
    int var86 = var85.size();
    boolean var87 = var85.isEmpty();
    java.util.Iterator var88 = var85.iterator();
    boolean var89 = var85.isEmpty();
    exercise01.RingBuffer.RingBufferIterator var90 = var85.new RingBufferIterator();
    exercise01.RingBuffer.RingBufferIterator var91 = var85.new RingBufferIterator();
    int var92 = var85.size();
    exercise01.RingBuffer.RingBufferIterator var93 = var85.new RingBufferIterator();
    var58.enqueue((java.lang.Object)var85);
    var9.enqueue((java.lang.Object)var58);
    exercise01.RingBuffer.RingBufferIterator var96 = var9.new RingBufferIterator();
    boolean var97 = var9.isEmpty();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var22 == 2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var59 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var69);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var75);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var77);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var79);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var80 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var86 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var87 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var89 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var92 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var97 == false);

  }

}
